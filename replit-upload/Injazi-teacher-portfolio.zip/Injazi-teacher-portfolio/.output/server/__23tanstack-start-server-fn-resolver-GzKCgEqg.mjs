//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-GzKCgEqg.js
var manifest = { "2bb7aff7342fd60fd4f7943caed2156ded7116efab646ed8df1ba4e005ebe62b": {
	functionName: "getAdminAccounts_createServerFn_handler",
	importer: () => import("./_ssr/admin.functions-DLBdpm4K.mjs")
} };
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ??= await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
