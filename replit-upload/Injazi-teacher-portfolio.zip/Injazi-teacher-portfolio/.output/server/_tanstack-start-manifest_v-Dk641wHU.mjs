//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dk641wHU.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/runner/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/auth",
			"/reset-password"
		],
		preloads: [
			"/assets/index-ngkUDMOF.js",
			"/assets/link-S7LRuTfm.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/lazyRouteComponent-Dvz47dYR.js",
			"/assets/matchContext-D3U4xTeB.js",
			"/assets/client-dsls-g9e.js",
			"/assets/queries-LB0VSyRm.js",
			"/assets/preload-helper-COzTzGja.js",
			"/assets/catalog-zUvGSIuf.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-ngkUDMOF.js"
		} }]
	},
	"/": {
		filePath: "/home/runner/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DnRS8IAB.js",
			"/assets/button-Cwo-uN_R.js",
			"/assets/createLucideIcon-Du-YDaxx.js",
			"/assets/list-checks-DZwalknY.js",
			"/assets/printer-BdT2qWG6.js",
			"/assets/user-round-Cy5ZTf5t.js",
			"/assets/Logo-phx1wo1o.js"
		]
	},
	"/_authenticated": {
		filePath: "/home/runner/workspace/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/admin",
			"/_authenticated/dashboard",
			"/_authenticated/onboarding",
			"/_authenticated/portfolio",
			"/_authenticated/profile",
			"/_authenticated/standards/$standardId",
			"/_authenticated/standards/"
		],
		preloads: [
			"/assets/route-_m0CY3TQ.js",
			"/assets/useNavigate-C4JRKnuN.js",
			"/assets/useQuery-BOKsq7k9.js",
			"/assets/button-Cwo-uN_R.js",
			"/assets/createLucideIcon-Du-YDaxx.js",
			"/assets/list-checks-DZwalknY.js",
			"/assets/user-round-Cy5ZTf5t.js",
			"/assets/Logo-phx1wo1o.js"
		]
	},
	"/auth": {
		filePath: "/home/runner/workspace/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-C21R00vU.js",
			"/assets/useNavigate-C4JRKnuN.js",
			"/assets/button-Cwo-uN_R.js",
			"/assets/createLucideIcon-Du-YDaxx.js",
			"/assets/input-qfGqzyqk.js",
			"/assets/label-F3SlY1Em.js",
			"/assets/loader-circle-DFv2ZBGo.js",
			"/assets/Logo-phx1wo1o.js"
		]
	},
	"/reset-password": {
		filePath: "/home/runner/workspace/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-x75JG0Uc.js",
			"/assets/useNavigate-C4JRKnuN.js",
			"/assets/button-Cwo-uN_R.js",
			"/assets/input-qfGqzyqk.js",
			"/assets/label-F3SlY1Em.js",
			"/assets/loader-circle-DFv2ZBGo.js",
			"/assets/Logo-phx1wo1o.js"
		]
	},
	"/_authenticated/admin": {
		filePath: "/home/runner/workspace/src/routes/_authenticated/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-B_Rf0On3.js",
			"/assets/useSuspenseQuery-BBLnwZ_N.js",
			"/assets/input-qfGqzyqk.js",
			"/assets/label-F3SlY1Em.js",
			"/assets/select-Doc0d-e8.js",
			"/assets/dist-DvKzJgwZ.js",
			"/assets/check-C8l47DR6.js",
			"/assets/dist-CRhRf-lK.js"
		]
	},
	"/_authenticated/dashboard": {
		filePath: "/home/runner/workspace/src/routes/_authenticated/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-B5aMi9SJ.js",
			"/assets/useSuspenseQuery-BBLnwZ_N.js",
			"/assets/PlaceholderNotice-Yn6d9UqP.js",
			"/assets/printer-BdT2qWG6.js",
			"/assets/progress-BhTG4hyj.js",
			"/assets/StatusBadge-BfjiXNgF.js"
		]
	},
	"/_authenticated/onboarding": {
		filePath: "/home/runner/workspace/src/routes/_authenticated/onboarding.tsx",
		children: void 0,
		preloads: [
			"/assets/onboarding-DVv1i5Rp.js",
			"/assets/useSuspenseQuery-BBLnwZ_N.js",
			"/assets/input-qfGqzyqk.js",
			"/assets/label-F3SlY1Em.js",
			"/assets/select-Doc0d-e8.js"
		]
	},
	"/_authenticated/portfolio": {
		filePath: "/home/runner/workspace/src/routes/_authenticated/portfolio.tsx",
		children: void 0,
		preloads: [
			"/assets/portfolio-BrzszHu-.js",
			"/assets/useSuspenseQuery-BBLnwZ_N.js",
			"/assets/label-F3SlY1Em.js",
			"/assets/dist-DvKzJgwZ.js",
			"/assets/dist-CRhRf-lK.js",
			"/assets/evidence-files-pse0st6I.js",
			"/assets/loader-circle-DFv2ZBGo.js",
			"/assets/printer-BdT2qWG6.js",
			"/assets/progress-BhTG4hyj.js"
		]
	},
	"/_authenticated/profile": {
		filePath: "/home/runner/workspace/src/routes/_authenticated/profile.tsx",
		children: void 0,
		preloads: [
			"/assets/profile-DX2_X7un.js",
			"/assets/useSuspenseQuery-BBLnwZ_N.js",
			"/assets/input-qfGqzyqk.js",
			"/assets/label-F3SlY1Em.js",
			"/assets/loader-circle-DFv2ZBGo.js",
			"/assets/textarea-DO8fvIke.js"
		]
	},
	"/_authenticated/standards/$standardId": {
		filePath: "/home/runner/workspace/src/routes/_authenticated/standards.$standardId.tsx",
		children: void 0,
		preloads: [
			"/assets/standards._standardId-BKZRLq4l.js",
			"/assets/useSuspenseQuery-BBLnwZ_N.js",
			"/assets/input-qfGqzyqk.js",
			"/assets/label-F3SlY1Em.js",
			"/assets/dist-DvKzJgwZ.js",
			"/assets/check-C8l47DR6.js",
			"/assets/evidence-files-pse0st6I.js",
			"/assets/loader-circle-DFv2ZBGo.js",
			"/assets/progress-BhTG4hyj.js",
			"/assets/StatusBadge-BfjiXNgF.js",
			"/assets/textarea-DO8fvIke.js",
			"/assets/standards._standardId-qT6nSpz9.js"
		]
	},
	"/_authenticated/standards/": {
		filePath: "/home/runner/workspace/src/routes/_authenticated/standards.index.tsx",
		children: void 0,
		preloads: [
			"/assets/standards.index-CGzBqYe0.js",
			"/assets/useSuspenseQuery-BBLnwZ_N.js",
			"/assets/PlaceholderNotice-Yn6d9UqP.js",
			"/assets/progress-BhTG4hyj.js",
			"/assets/StatusBadge-BfjiXNgF.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
