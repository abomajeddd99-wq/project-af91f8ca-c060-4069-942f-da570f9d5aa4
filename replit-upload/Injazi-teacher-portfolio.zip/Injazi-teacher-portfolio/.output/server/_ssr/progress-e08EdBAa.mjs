//#region node_modules/.nitro/vite/services/ssr/assets/progress-e08EdBAa.js
function computeEvidenceCoverage(standards, evidences) {
	const ids = new Set(standards.map((s) => s.id));
	const withEvidence = /* @__PURE__ */ new Set();
	let evidenceCount = 0;
	for (const e of evidences) {
		if (!ids.has(e.standard_id)) continue;
		evidenceCount += 1;
		withEvidence.add(e.standard_id);
	}
	const total = ids.size;
	const documented = withEvidence.size;
	const percent = total === 0 ? 0 : Math.round(documented / total * 100);
	return {
		total,
		documented,
		empty: total - documented,
		percent,
		evidenceCount
	};
}
var STATUS_LABELS = {
	not_started: "لم يبدأ",
	in_progress: "قيد الإنجاز",
	completed: "مكتمل"
};
var STATUS_ORDER = [
	"not_started",
	"in_progress",
	"completed"
];
function statusFor(standardId, progress) {
	const s = progress.find((p) => p.standard_id === standardId)?.status;
	return s === "completed" || s === "in_progress" ? s : "not_started";
}
function computeManualProgress(standards, progress) {
	const total = standards.length;
	let completed = 0;
	let inProgress = 0;
	let weightAll = 0;
	let weightDone = 0;
	for (const s of standards) {
		const w = Number(s.weight ?? 0) || 0;
		weightAll += w;
		const st = statusFor(s.id, progress);
		if (st === "completed") {
			completed += 1;
			weightDone += w;
		} else if (st === "in_progress") inProgress += 1;
	}
	const percent = total === 0 ? 0 : Math.round(completed / total * 100);
	const weightedPercent = weightAll > 0 ? Math.round(weightDone / weightAll * 100) : percent;
	return {
		total,
		completed,
		inProgress,
		notStarted: total - completed - inProgress,
		percent,
		weightedPercent
	};
}
//#endregion
export { statusFor as a, computeManualProgress as i, STATUS_ORDER as n, computeEvidenceCoverage as r, STATUS_LABELS as t };
