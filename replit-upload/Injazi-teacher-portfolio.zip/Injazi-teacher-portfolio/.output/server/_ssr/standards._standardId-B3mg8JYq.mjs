import { Y as notFound, _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as progressQuery, n as evidencesQuery, s as standardsQuery, t as allStandardsQuery } from "./queries-DI_WVmjo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/standards._standardId-B3mg8JYq.js
var $$splitComponentImporter = () => import("./standards._standardId-CynL3zC-.mjs");
var $$splitNotFoundComponentImporter = () => import("./standards._standardId-BimnVASk.mjs");
var Route = createFileRoute("/_authenticated/standards/$standardId")({
	head: () => ({ meta: [
		{ title: "تفاصيل المعيار — إنجازي" },
		{
			name: "description",
			content: "مؤشرات المعيار وشواهدك المرفقة وحالة الإنجاز."
		},
		{
			property: "og:title",
			content: "تفاصيل المعيار — إنجازي"
		},
		{
			property: "og:description",
			content: "مؤشرات المعيار وشواهدك المرفقة وحالة الإنجاز."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	loader: async ({ context, params }) => {
		const [standards] = await Promise.all([
			context.queryClient.ensureQueryData(allStandardsQuery()),
			context.queryClient.ensureQueryData(standardsQuery()),
			context.queryClient.ensureQueryData(progressQuery()),
			context.queryClient.ensureQueryData(evidencesQuery())
		]);
		if (!standards.some((s) => s.id === params.standardId)) throw notFound();
	},
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
