import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D6YTns3_.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useSuspenseQuery, r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as progressQuery, i as profileQuery, n as evidencesQuery, s as standardsQuery, t as allStandardsQuery } from "./queries-DI_WVmjo.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Button } from "./button-B4IWnrg7.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { T as Download, b as FileText, f as LockKeyhole, h as LayoutGrid, l as PanelsTopLeft, p as LoaderCircle, s as Printer } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as LogoMark } from "./Logo-B61h93Nc.mjs";
import { a as statusFor, i as computeManualProgress, r as computeEvidenceCoverage, t as STATUS_LABELS } from "./progress-e08EdBAa.mjs";
import { t as Route } from "./portfolio-WryRiM5y.mjs";
import { a as formatBytes, c as isPdf, i as compareEvidenceChronological, o as formatEvidenceDate, s as isImage } from "./evidence-files-BLvMoTwE.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
import { n as rgb, t as PDFDocument } from "../_libs/pdf-lib+tslib.mjs";
import { t as toPng } from "../_libs/html-to-image.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/portfolio-DtzK8ePP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Switch = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
	className: cn("peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input", className),
	...props,
	ref,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: cn("pointer-events-none block h-4 w-4 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-4 data-[state=unchecked]:translate-x-0") })
}));
Switch.displayName = Switch$1.displayName;
function downloadBlob(blob, filename) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	document.body.appendChild(a);
	a.click();
	a.remove();
	setTimeout(() => URL.revokeObjectURL(url), 3e4);
}
/** Only generated pages are inspected. Original evidence pages must remain untouched. */
function assertPortfolioRasterVisible(pixels) {
	const count = pixels.length / 4;
	if (!count) throw new Error("تعذر قراءة صورة صفحة ملف الإنجاز.");
	let black = 0;
	let ink = 0;
	let transparent = 0;
	for (let index = 0; index < pixels.length; index += 4) {
		const r = pixels[index];
		const g = pixels[index + 1];
		const b = pixels[index + 2];
		if (pixels[index + 3] < 250) transparent++;
		if (r < 18 && g < 18 && b < 18) black++;
		if (r < 175 && g < 190 && b < 190) ink++;
	}
	if (black / count > .98) throw new Error("ظهرت صفحة مولدة سوداء أثناء التصدير. لم يُحذف أي شاهد؛ يرجى إعادة المحاولة.");
	if (transparent / count > .02 || ink < Math.max(12, count * 1e-4)) throw new Error("ظهرت صفحة مولدة فارغة أثناء التصدير. لم يُحذف أي شاهد؛ يرجى إعادة المحاولة.");
}
async function validatePortfolioRaster(dataUrl) {
	if (typeof CanvasRenderingContext2D === "undefined") return;
	const image = new Image();
	image.src = dataUrl;
	await image.decode();
	if (image.naturalWidth < 794 || image.naturalHeight < 1123) throw new Error("تعذر التقاط صفحة ملف الإنجاز بالمقاس الصحيح. لم يُحذف أي محتوى؛ يرجى إعادة المحاولة.");
	const canvas = document.createElement("canvas");
	canvas.width = 400;
	canvas.height = Math.round(400 * image.naturalHeight / image.naturalWidth);
	try {
		const context = canvas.getContext("2d", { willReadFrequently: true });
		if (!context || !image.naturalWidth) throw new Error("تعذر التحقق من صفحة ملف الإنجاز.");
		context.drawImage(image, 0, 0, canvas.width, canvas.height);
		assertPortfolioRasterVisible(context.getImageData(0, 0, canvas.width, canvas.height).data);
	} finally {
		canvas.width = 0;
		canvas.height = 0;
		image.src = "";
	}
}
/** Normalize legacy brand paints, never teacher text or original evidence bytes. */
function applyPortfolioPalette(markup) {
	const paints = {
		"#07594F": "#07584F",
		"#C5A15B": "#C5A46D",
		"#F7F3EA": "#F8F5EC",
		"#202B2A": "#252A28",
		"#183331": "#252A28"
	};
	return markup.replace(/\b(style|fill|stroke|stop-color)="([^"]*)"/g, (_attribute, name, value) => `${name}="${value.replace(/#[0-9a-f]{6}\b/gi, (color) => paints[color.toUpperCase()] ?? color)}"`);
}
function portfolioPageMarkup(content, heading, frame) {
	return applyPortfolioPalette(pageMarkup(content, heading, frame));
}
function pageMarkup(content, heading, frame) {
	if (content.includes("data-standard-cover=\"true\"") || content.includes("data-royal-page=\"true\"")) return `<div style="height:100%;position:relative;background:#F8F5EC">${content}
      ${frame ? `<span dir="ltr" style="position:absolute;bottom:44px;left:64px;font-family:monospace;background:#07584F;padding:3px 8px;color:#F8F5EC;font-size:11px;letter-spacing:.04em">${frame.pageNumber} / ${frame.totalPages}</span>` : ""}
    </div>`;
	return `
    <div style="height:100%;box-sizing:border-box;display:flex;flex-direction:column;background:#F8F5EC;padding:50px 53px;position:relative">
      <span aria-hidden="true" style="position:absolute;inset:24px;border:1px solid #C5A46D;opacity:.4;pointer-events:none"></span>
      <span aria-hidden="true" style="position:absolute;top:18px;right:18px;width:20px;height:20px;border-top:1px solid #C5A15B;border-right:1px solid #C5A15B"></span>
      <span aria-hidden="true" style="position:absolute;bottom:18px;left:18px;width:20px;height:20px;border-bottom:1px solid #C5A15B;border-left:1px solid #C5A15B"></span>
      <header style="display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #D8C9AA;padding:0 0 8px;flex-shrink:0">
        <div style="display:flex;align-items:center;gap:8px;font-family:'Readex Pro','IBM Plex Sans Arabic',sans-serif;font-size:16px;font-weight:700;color:#07594F">
          <span style="display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border:1px solid #C5A15B;border-radius:50%;font-size:11px;color:#C5A15B">إ</span>
          إنجازي
        </div>
        <div style="font-size:11px;color:#586A66;letter-spacing:.02em">ملف الإنجاز الوظيفي</div>
      </header>
      ${heading ? `<div style="margin:16px 0 20px;display:flex;align-items:center;gap:12px">
        <span style="display:block;width:3px;height:31px;background:#C5A15B;flex-shrink:0"></span>
        <h1 style="margin:0;color:#07594F;font-size:25px;line-height:1.4;font-weight:700;overflow-wrap:anywhere">${escapeHtml$3(heading)}</h1>
      </div>` : ""}
      <main style="flex:1;min-height:0;overflow:visible;box-sizing:border-box;color:#202B2A">${content}</main>
      <footer style="display:flex;align-items:center;justify-content:space-between;border-top:1px solid #D8C9AA;margin-top:11px;padding-top:7px;color:#697773;font-size:9px;line-height:1.4;flex-shrink:0">
        <span>منصة إنجازي · ملف مهني للعرض والمراجعة</span>${frame ? `<span dir="ltr" style="font-family:monospace;color:#07594F;font-size:10px;letter-spacing:.04em">${frame.pageNumber} / ${frame.totalPages}</span>` : ""}
      </footer>
    </div>
  `;
}
/** Keep each standard on one page without silently cutting off any supplied text. */
function fitStandardCover(element) {
	const viewport = element.querySelector("[data-standard-viewport]");
	const body = element.querySelector("[data-standard-body]");
	if (!viewport || !body) return;
	const bounds = {
		width: viewport.clientWidth,
		height: viewport.clientHeight
	};
	if (!bounds.width || !bounds.height) return;
	body.style.transformOrigin = "top right";
	body.style.position = "absolute";
	body.style.top = "0";
	body.style.right = "0";
	body.style.flexShrink = "0";
	for (let percentage = 100; percentage >= 80; percentage -= 2) {
		const scale = percentage / 100;
		body.style.width = `${bounds.width / scale}px`;
		body.style.transform = `scale(${scale})`;
		if (body.offsetHeight * scale <= bounds.height + .5) {
			body.dataset["standardScale"] = String(scale);
			return;
		}
	}
	const number = element.querySelector("[data-standard-number]")?.dataset["standardNumber"] ?? "";
	throw new Error(`محتوى المعيار ${number} يتجاوز المساحة المقروءة لصفحة واحدة. يُرجى تقليل الملاحظات المطولة قبل التصدير.`);
}
/** Fail explicitly rather than exporting text outside the printable content surface. */
function assertGeneratedTextFits(element) {
	if (!element.getBoundingClientRect().width) return;
	const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
	while (walker.nextNode()) {
		const text = walker.currentNode;
		if (!text.textContent?.trim() || text.parentElement?.closest("svg,[aria-hidden='true']")) continue;
		const range = document.createRange();
		range.selectNodeContents(text);
		for (const bounds of Array.from(range.getClientRects())) if (bounds.left < -1 || bounds.right > 795 || bounds.top < -1 || bounds.bottom > 1091) throw new Error(`يتجاوز نص الصفحة ${element.dataset["portfolioPageNumber"] ?? ""} مساحة الطباعة الآمنة. لم يُقتطع أي نص؛ يُرجى مراجعة طول المحتوى.`);
	}
}
function escapeHtml$3(value) {
	return String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;").replaceAll("'", "&#39;");
}
async function renderPortfolioPage(content, heading, frame) {
	if (typeof document === "undefined") throw new Error("PDF export is only available in a browser.");
	await document.fonts?.ready;
	const element = document.createElement("div");
	element.lang = "ar";
	element.dir = "rtl";
	if (frame) {
		element.dataset["portfolioPageNumber"] = String(frame.pageNumber);
		element.dataset["portfolioTotalPages"] = String(frame.totalPages);
	}
	element.style.cssText = [
		"position:fixed",
		"left:0",
		"top:0",
		"z-index:2147483647",
		"opacity:0",
		"pointer-events:none",
		"box-sizing:border-box",
		"width:794px",
		"height:1123px",
		"overflow:hidden",
		"background:#F8F5EC",
		"color:#252A28",
		"font-family:'IBM Plex Sans Arabic',system-ui,sans-serif",
		"font-size:18px",
		"line-height:1.75",
		"direction:rtl"
	].join(";");
	element.innerHTML = portfolioPageMarkup(content, heading, frame);
	document.body.appendChild(element);
	try {
		await document.fonts?.ready;
		await Promise.all(Array.from(element.querySelectorAll("img"), (image) => image.decode()));
		fitStandardCover(element);
		assertGeneratedTextFits(element);
		let dataUrl = "";
		for (const pixelRatio of [3, 2]) try {
			dataUrl = await toPng(element, {
				pixelRatio,
				width: 794,
				height: 1123,
				canvasWidth: 794,
				canvasHeight: 1123,
				backgroundColor: "#F8F5EC",
				cacheBust: true,
				skipFonts: true,
				style: {
					left: "0px",
					top: "0px",
					position: "fixed",
					zIndex: "2147483647",
					opacity: "1",
					pointerEvents: "none"
				}
			});
			await validatePortfolioRaster(dataUrl);
			break;
		} catch (error) {
			if (pixelRatio === 2) throw error;
		}
		const encoded = dataUrl.slice(dataUrl.indexOf(",") + 1);
		const binary = atob(encoded);
		return Uint8Array.from(binary, (character) => character.charCodeAt(0));
	} finally {
		element.remove();
	}
}
var PORTFOLIO_A4 = [595.28, 841.89];
/** All coordinates use PDF points; top offsets are measured down from the page top. */
function layoutEvidenceImage(width, height, metadataHeight) {
	if (![
		width,
		height,
		metadataHeight
	].every(Number.isFinite) || width <= 0 || height <= 0 || metadataHeight < 0) throw new Error("Invalid evidence layout dimensions.");
	const [pageWidth, pageHeight] = PORTFOLIO_A4;
	const margin = 40;
	const top = 88;
	const bottom = 64;
	const gap = 12;
	const availableHeight = pageHeight - top - bottom - metadataHeight - gap;
	if (availableHeight < 220) throw new Error("Evidence metadata requires a continuation page.");
	const scale = Math.min((pageWidth - 80) / width, Math.min(pageHeight / 3, availableHeight) / height);
	const imageWidth = width * scale;
	const imageHeight = height * scale;
	const imageTop = top;
	return {
		x: (pageWidth - imageWidth) / 2,
		y: pageHeight - imageTop - imageHeight,
		width: imageWidth,
		height: imageHeight,
		imageTop,
		metadataTop: imageTop + imageHeight + gap,
		metadataHeight,
		metadataWidth: pageWidth - 80,
		margin
	};
}
function evidenceLayoutFor(preferences, standardId) {
	const value = preferences?.byStandard?.[standardId] ?? preferences?.defaultItemsPerPage ?? 2;
	return value === 1 || value === 3 || value === 4 ? value : 2;
}
/** A teacher's choice is a maximum, never permission to clip captions or distort images. */
function layoutEvidenceGroup(originals, target) {
	if (!originals.length || originals.length > target) return null;
	if (originals.length === 1) return [{ ...originals[0] }];
	if (target <= 2) return layoutEvidencePair(originals[0], originals[1]);
	const [pageWidth, pageHeight] = PORTFOLIO_A4;
	const columns = target === 4 ? 2 : 1;
	const gap = 22;
	const margin = 40;
	const top = 88;
	const cellWidth = (pageWidth - 80 - gap * (columns - 1)) / columns;
	const rows = Math.ceil(originals.length / columns);
	const rowHeight = (pageHeight - top - 64 - gap * (rows - 1)) / rows;
	const result = [];
	for (const [index, original] of originals.entries()) {
		const imageSpace = rowHeight - original.metadataHeight - 12;
		const scale = Math.min(1, cellWidth / original.width, imageSpace / original.height);
		const shortest = Math.min(original.width, original.height);
		if (scale < .42 || shortest * scale < Math.min(72, shortest * .8)) return null;
		const width = original.width * scale;
		const height = original.height * scale;
		const cellLeft = margin + (columns - 1 - index % columns) * (cellWidth + gap);
		const imageTop = top + Math.floor(index / columns) * (rowHeight + gap);
		result.push({
			...original,
			width,
			height,
			x: cellLeft + (cellWidth - width) / 2,
			y: pageHeight - imageTop - height,
			imageTop,
			metadataTop: imageTop + height + 12,
			margin: cellLeft,
			metadataWidth: cellWidth
		});
	}
	return result;
}
/** Pair only when each image retains at least 80% of its single-item display size. */
function layoutEvidencePair(first, second) {
	const [pageWidth, pageHeight] = PORTFOLIO_A4;
	const top = 88;
	const bottom = 64;
	const captionGap = 12;
	const itemGap = 22;
	const availableImages = pageHeight - top - bottom - first.metadataHeight - second.metadataHeight - 24 - itemGap;
	const scale = Math.min(1, availableImages / (first.height + second.height));
	if (scale < .8) return null;
	let nextTop = top;
	const place = (original) => {
		const width = original.width * scale;
		const height = original.height * scale;
		const imageTop = nextTop;
		const metadataTop = imageTop + height + captionGap;
		nextTop = metadataTop + original.metadataHeight + itemGap;
		return {
			...original,
			x: (pageWidth - width) / 2,
			y: pageHeight - imageTop - height,
			width,
			height,
			imageTop,
			metadataTop
		};
	};
	return [place(first), place(second)];
}
/** Count hard line breaks as lines too, so newline-heavy descriptions cannot escape their page budget. */
function splitImageDescription(value) {
	if (!value) return [];
	const result = [];
	let chunk = "";
	let cost = 0;
	let limit = 240;
	for (const character of Array.from(value)) {
		const nextCost = character === "\n" ? 65 : 1;
		if (chunk && cost + nextCost > limit) {
			const boundary = chunk.lastIndexOf(" ") + 1;
			if (boundary > chunk.length * .7) {
				result.push(chunk.slice(0, boundary));
				chunk = chunk.slice(boundary);
				cost = Array.from(chunk).reduce((sum, value) => sum + (value === "\n" ? 65 : 1), 0);
			} else {
				result.push(chunk);
				chunk = "";
				cost = 0;
			}
			limit = 1600;
		}
		chunk += character;
		cost += nextCost;
	}
	if (chunk) result.push(chunk);
	return result;
}
function escapeHtml$2(value) {
	return String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;").replaceAll("'", "&#39;");
}
function formatStandardNumber(value) {
	return String(Math.max(0, Number.isFinite(value) ? Math.trunc(value) : 0)).padStart(2, "0");
}
function buildStandardCover(input) {
	const number = formatStandardNumber(input.number);
	const indicatorMarkup = input.indicators.map((indicator) => `
        <li style="position:relative;margin:0;padding:11px 21px 11px 5px;border-bottom:1px solid rgba(7,88,79,.13);color:#344A45;font-size:16px;line-height:1.78;overflow-wrap:anywhere;word-break:break-word">
          <span aria-hidden="true" style="position:absolute;right:0;top:22px;width:7px;height:7px;transform:rotate(45deg);border:1px solid #C5A46D;box-sizing:border-box"></span>
          <span style="white-space:pre-wrap">${escapeHtml$2(indicator)}</span>
        </li>`).join("");
	const descriptionMarkup = input.description ? `<p style="margin:14px 0 0;color:#53635C;font-size:16px;line-height:1.85;white-space:pre-wrap;overflow-wrap:anywhere;word-break:break-word">${escapeHtml$2(input.description)}</p>` : "";
	const notesMarkup = input.notes ? `<section aria-label="ملاحظات" style="margin-top:21px;padding:13px 16px 14px;border-right:2px solid #C5A46D;background:rgba(237,231,217,.68)">
        <div style="margin-bottom:5px;color:#8A7041;font-size:12px;letter-spacing:.04em">ملاحظات</div>
        <div style="color:#465650;font-size:14px;line-height:1.75;white-space:pre-wrap;overflow-wrap:anywhere;word-break:break-word">${escapeHtml$2(input.notes)}</div>
      </section>` : "";
	const weightMarkup = input.weight === null || input.weight === "" ? "" : `<div><div style="color:#7C7768;font-size:11px;white-space:nowrap">الوزن</div><strong dir="auto" style="display:block;margin-top:4px;color:#07584F;font-size:13px;font-weight:600;overflow-wrap:anywhere">${escapeHtml$2(input.weight)}</strong></div>`;
	return `
    <section data-standard-cover="true" data-standard-number="${escapeHtml$2(number)}" style="position:absolute;inset:0;box-sizing:border-box;width:794px;height:1123px;overflow:hidden;background:#F8F5EC;color:#252A28;direction:rtl;text-align:right;font-family:'IBM Plex Sans Arabic','Readex Pro',system-ui,sans-serif">
      <svg aria-hidden="true" width="794" height="1123" viewBox="0 0 794 1123" style="position:absolute;inset:0;width:794px;height:1123px;pointer-events:none">
        <defs>
          <pattern id="standard-geometry" width="42" height="42" patternUnits="userSpaceOnUse">
            <path d="M21 1 41 21 21 41 1 21Z M21 11 31 21 21 31 11 21Z" fill="none" stroke="#07584F" stroke-width=".65" opacity=".16"/>
            <circle cx="21" cy="21" r="2" fill="#C5A46D" opacity=".31"/>
          </pattern>
          <linearGradient id="standard-wave-gold" x1="0" x2="1" y1="0" y2="0">
            <stop offset="0" stop-color="#C5A46D" stop-opacity=".42"/>
            <stop offset=".48" stop-color="#E0C98F" stop-opacity=".78"/>
            <stop offset="1" stop-color="#C5A46D" stop-opacity=".36"/>
          </linearGradient>
        </defs>
        <path d="M0 0H794V270H0Z" fill="url(#standard-geometry)" opacity=".43"/>
        <path d="M0 0H794V11H0Z" fill="#07584F"/>
        <path d="M24 24H770V1099H24Z" fill="none" stroke="#C5A46D" stroke-width="1"/>
        <path d="M32 32H762V1091H32Z" fill="none" stroke="#07584F" stroke-width=".55" opacity=".3"/>
        <path d="M0 1052 C139 1009 234 1087 378 1051 C525 1014 629 1028 794 986 V1123 H0Z" fill="#07584F"/>
        <path d="M0 1040 C139 997 234 1075 378 1039 C525 1002 629 1016 794 974" fill="none" stroke="url(#standard-wave-gold)" stroke-width="4"/>
        <path d="M0 1061 C148 1025 246 1098 389 1061 C540 1023 648 1042 794 1002" fill="none" stroke="#F8F5EC" stroke-width="1" opacity=".42"/>
        <path d="M0 1090 C158 1057 259 1120 405 1089 C548 1059 650 1070 794 1041" fill="none" stroke="#C5A46D" stroke-width="1" opacity=".6"/>
        <path d="M39 42h31M54 27v31M724 42h31M739 27v31M39 1081h31M54 1066v31M724 1081h31M739 1066v31" fill="none" stroke="#C5A46D" stroke-width="1"/>
      </svg>

      <div aria-hidden="true" style="position:absolute;top:50px;left:64px;right:64px;display:flex;align-items:center;justify-content:space-between;color:#07584F">
        <div style="display:flex;align-items:center;gap:10px">
          <span style="display:inline-block;width:22px;height:22px;box-sizing:border-box;border:1px solid #C5A46D;transform:rotate(45deg)"></span>
          <span style="display:inline-block;width:7px;height:7px;margin-right:-19px;background:#07584F;border:1px solid #F8F5EC;border-radius:50%"></span>
          <span style="margin-right:9px;color:#8A7041;font-size:11px;letter-spacing:.16em">ENJAZI</span>
        </div>
        <span dir="ltr" style="font-family:Georgia,serif;font-size:12px;letter-spacing:.17em;color:#8A7041">${escapeHtml$2(input.code)}</span>
      </div>

      <div aria-hidden="true" dir="ltr" style="position:absolute;top:91px;left:54px;color:rgba(7,88,79,.075);font-family:Georgia,'Times New Roman',serif;font-size:210px;font-weight:400;line-height:1;letter-spacing:-.085em">${escapeHtml$2(number)}</div>
      <div aria-hidden="true" style="position:absolute;top:118px;left:64px;width:238px;height:1px;background:linear-gradient(to right,rgba(197,164,109,0),rgba(197,164,109,.72),rgba(197,164,109,0))"></div>
      <div aria-hidden="true" style="position:absolute;top:241px;left:64px;width:34px;height:1px;background:#C5A46D"></div>

      <div data-standard-viewport="true" style="position:absolute;top:273px;bottom:153px;left:64px;right:64px;box-sizing:border-box;display:flex;align-items:flex-start;justify-content:center">
        <div data-standard-body="true" data-standard-density="${input.indicators.length > 7 || (input.description?.length ?? 0) > 700 || (input.notes?.length ?? 0) > 350 ? "dense" : "standard"}" style="position:relative;box-sizing:border-box;width:100%;height:auto;min-height:548px;padding:0 0 2px;display:flex;flex-direction:column">
          <div>
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;color:#8A7041;font-size:12px;line-height:1.6">
              <span aria-hidden="true" style="width:5px;height:18px;background:#07584F"></span>
              <span>المعايير المهنية</span>
              <span aria-hidden="true" style="flex:1;height:1px;background:rgba(197,164,109,.72)"></span>
            </div>
            <h1 style="margin:0;color:#07584F;font-size:36px;font-weight:700;line-height:1.55;letter-spacing:-.025em;overflow-wrap:anywhere;word-break:break-word;white-space:pre-wrap">${escapeHtml$2(input.title)}</h1>
            ${descriptionMarkup}

            ${input.indicators.length ? `
              <section aria-label="المؤشرات" style="margin-top:23px">
                <div style="display:flex;align-items:center;gap:10px;padding-bottom:8px;border-bottom:1px solid #C5A46D">
                  <span aria-hidden="true" style="width:5px;height:17px;background:#07584F"></span>
                  <h2 style="margin:0;color:#07584F;font-size:15px;font-weight:600;letter-spacing:.015em">المؤشرات</h2>
                  <span aria-hidden="true" style="flex:1;height:1px;background:rgba(7,88,79,.13)"></span>
                </div>
                <ol style="list-style:none;margin:0;padding:0">${indicatorMarkup}</ol>
              </section>
            ` : ""}

            ${notesMarkup}
          </div>

          <div aria-label="بيانات المعيار" style="display:grid;grid-template-columns:${weightMarkup ? "1.6fr 1fr 1fr" : "1.6fr 1fr"};gap:14px;margin-top:auto;padding:15px 14px 12px;border-top:1px solid rgba(7,88,79,.18);background:rgba(255,255,255,.55);color:#65736B;font-size:12px;line-height:1.65">
            <div><div style="color:#7C7768;font-size:11px;white-space:nowrap">الحالة اليدوية</div><div style="margin-top:4px;color:#52635C;font-size:13px;overflow-wrap:anywhere">${escapeHtml$2(input.status)}</div></div>
            ${weightMarkup}
            <div><div style="color:#7C7768;font-size:11px;white-space:nowrap">الشواهد</div><strong dir="ltr" style="display:block;margin-top:4px;color:#07584F;font-family:Georgia,serif;font-size:14px;font-weight:400">${escapeHtml$2(input.evidenceCount)}</strong></div>
          </div>
      </div>
      </div>
    </section>
  `;
}
var EMERALD = "#07584F";
var GOLD = "#C5A46D";
var IVORY = "#F8F5EC";
var CHARCOAL = "#252A28";
function escapeHtml$1(value) {
	return String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;").replaceAll("'", "&#39;");
}
function detailMarkup(details) {
	return details.filter((detail) => detail !== "").map((detail) => `
        <div style="position:relative;padding:8px 18px 8px 0;border-bottom:1px solid rgba(7,88,79,.14);color:#4E5B56;font-size:15px;line-height:1.75;overflow-wrap:anywhere;word-break:break-word">
          <span aria-hidden="true" style="position:absolute;right:1px;top:19px;width:6px;height:6px;border:1px solid ${GOLD};transform:rotate(45deg);box-sizing:border-box"></span>
          <span style="white-space:pre-wrap">${escapeHtml$1(detail)}</span>
        </div>`).join("");
}
function buildRoyalCover(input) {
	const accent = input.accent === "emerald" ? EMERALD : GOLD;
	const isClassic = input.layout === "classic";
	const school = input.school ? `<div style="margin-top:9px;color:#4E5B56;font-size:17px;line-height:1.75;overflow-wrap:anywhere;word-break:break-word">${escapeHtml$1(input.school)}</div>` : "";
	const year = input.year ? `<div style="display:inline-block;max-width:100%;box-sizing:border-box;margin-top:14px;padding:7px 14px;border:1px solid ${accent};color:${EMERALD};font-size:13px;line-height:1.65;overflow-wrap:anywhere;word-break:break-word">${escapeHtml$1(input.year)}</div>` : "";
	const details = input.details.length ? `<div style="margin-top:18px">${detailMarkup(input.details)}</div>` : "";
	return `
    <section data-royal-page="true" data-royal-layout="${input.layout}" data-royal-accent="${input.accent}" style="position:absolute;inset:0;box-sizing:border-box;width:794px;height:1123px;overflow:hidden;background:${IVORY};color:${CHARCOAL};direction:rtl;text-align:right;font-family:'IBM Plex Sans Arabic','Readex Pro',system-ui,sans-serif">
      <svg aria-hidden="true" width="794" height="1123" viewBox="0 0 794 1123" style="position:absolute;inset:0;width:794px;height:1123px;pointer-events:none">
        <defs>
          <pattern id="royal-cover-geometry" width="48" height="48" patternUnits="userSpaceOnUse">
            <path d="M24 2 46 24 24 46 2 24Z M24 12 36 24 24 36 12 24Z" fill="none" stroke="${EMERALD}" stroke-width=".65" opacity=".14"/>
            <circle cx="24" cy="24" r="1.8" fill="${GOLD}" opacity=".34"/>
          </pattern>
          <linearGradient id="royal-cover-rule" x1="0" x2="1">
            <stop offset="0" stop-color="${GOLD}" stop-opacity=".12"/>
            <stop offset=".5" stop-color="${GOLD}" stop-opacity=".88"/>
            <stop offset="1" stop-color="${GOLD}" stop-opacity=".12"/>
          </linearGradient>
        </defs>
        <path d="M0 0H794V252H0Z" fill="url(#royal-cover-geometry)" opacity=".52"/>
        ${isClassic ? `<path d="M28 28H766V1095H28Z" fill="none" stroke="${accent}" stroke-width="1.2"/>
             <path d="M38 38H756V1085H38Z" fill="none" stroke="${EMERALD}" stroke-width=".55" opacity=".36"/>
             <path d="M28 28h38M28 28v38M766 28h-38M766 28v38M28 1095h38M28 1095v-38M766 1095h-38M766 1095v-38" fill="none" stroke="${GOLD}" stroke-width="2"/>` : `<path d="M0 0H794V10H0Z" fill="${EMERALD}"/>
             <path d="M0 10H794V12H0Z" fill="${GOLD}" opacity=".9"/>
             <path d="M0 858C154 833 250 878 387 855C532 831 653 850 794 817V1123H0Z" fill="${EMERALD}"/>
             <path d="M0 846C155 821 249 866 387 843C533 819 653 838 794 805" fill="none" stroke="url(#royal-cover-rule)" stroke-width="3"/>
             <path d="M0 869C156 847 257 891 394 868C535 845 659 863 794 834" fill="none" stroke="${IVORY}" stroke-width="1" opacity=".38"/>`}
      </svg>

      <div aria-hidden="true" style="position:absolute;top:53px;left:64px;right:64px;display:flex;align-items:center;justify-content:space-between">
        <div style="display:flex;align-items:center;gap:12px;color:${EMERALD}">
          <span style="width:25px;height:25px;border:1px solid ${GOLD};transform:rotate(45deg);box-sizing:border-box"></span>
          <span style="margin-right:-25px;width:7px;height:7px;border-radius:50%;background:${EMERALD};border:1px solid ${IVORY};box-sizing:border-box"></span>
          <span style="margin-right:8px;font-family:Georgia,serif;font-size:12px;letter-spacing:.2em;color:#8C7146">ENJAZI</span>
        </div>
        <span style="font-size:11px;letter-spacing:.08em;color:#8C7146">إنجازي للمعلم</span>
      </div>

      <div aria-hidden="true" style="position:absolute;top:124px;left:64px;width:120px;height:1px;background:${GOLD};opacity:.72"></div>
      <div style="position:absolute;top:166px;left:64px;right:64px;max-width:666px;box-sizing:border-box">
        <div style="display:flex;align-items:center;gap:11px;color:#8C7146;font-size:12px;line-height:1.7;letter-spacing:.08em">
          <span aria-hidden="true" style="display:inline-block;width:24px;height:1px;background:${accent}"></span>
          <span>ملف مهني للعرض والمراجعة</span>
        </div>
        <h1 style="max-width:620px;margin:18px 0 0;color:${EMERALD};font-size:43px;font-weight:700;line-height:1.55;letter-spacing:-.025em;overflow-wrap:anywhere;word-break:break-word">ملف الإنجاز الوظيفي</h1>
        <div style="display:flex;align-items:center;gap:9px;margin-top:14px">
          <span style="width:54px;height:2px;background:${accent}"></span>
          <span style="width:20px;height:1px;background:#D9C9A9"></span>
        </div>
        <p style="max-width:610px;margin:21px 0 0;color:#53615B;font-size:17px;line-height:1.9;overflow-wrap:anywhere;word-break:break-word;white-space:pre-wrap">${escapeHtml$1(input.subtitle)}</p>

        <div style="margin-top:35px;padding:18px 21px 20px;border-right:3px solid ${accent};background:rgba(255,255,255,.66);box-shadow:0 8px 22px rgba(37,42,40,.045);box-sizing:border-box">
          <div style="color:#8C7146;font-size:11px;letter-spacing:.04em">صاحب الملف</div>
          <div style="margin-top:5px;color:${CHARCOAL};font-size:27px;font-weight:700;line-height:1.6;overflow-wrap:anywhere;word-break:break-word">${escapeHtml$1(input.name)}</div>
          ${school}
          ${year}
          ${details}
        </div>
      </div>

      ${isClassic ? `<div style="position:absolute;bottom:91px;left:64px;right:64px;display:flex;align-items:center;justify-content:space-between;gap:24px;border-top:1px solid rgba(197,164,109,.7);padding-top:13px;color:#6A746E;font-size:11px;line-height:1.7">
             <span>إنجازي · ملف الإنجاز الوظيفي</span><span style="overflow-wrap:anywhere">${escapeHtml$1(input.date)}</span>
           </div>` : `<div style="position:absolute;bottom:94px;left:64px;right:64px;display:flex;align-items:center;justify-content:space-between;gap:24px;color:${IVORY};font-size:11px;line-height:1.7">
             <span style="letter-spacing:.1em;color:#E4D5B6">ENJAZI · TEACHER PORTFOLIO</span><span style="overflow-wrap:anywhere;text-align:left">${escapeHtml$1(input.date)}</span>
           </div>`}
    </section>`;
}
function buildRoyalClosing() {
	return `
    <section data-royal-page="true" data-royal-layout="closing" style="position:absolute;inset:0;box-sizing:border-box;width:794px;height:1123px;overflow:hidden;background:${IVORY};color:${CHARCOAL};direction:rtl;text-align:right;font-family:'IBM Plex Sans Arabic','Readex Pro',system-ui,sans-serif">
      <svg aria-hidden="true" width="794" height="1123" viewBox="0 0 794 1123" style="position:absolute;inset:0;width:794px;height:1123px;pointer-events:none">
        <defs>
          <pattern id="royal-closing-geometry" width="48" height="48" patternUnits="userSpaceOnUse">
            <path d="M24 2 46 24 24 46 2 24Z M24 12 36 24 24 36 12 24Z" fill="none" stroke="${EMERALD}" stroke-width=".65" opacity=".14"/>
            <circle cx="24" cy="24" r="1.8" fill="${GOLD}" opacity=".34"/>
          </pattern>
        </defs>
        <path d="M0 0H794V250H0Z" fill="url(#royal-closing-geometry)" opacity=".5"/>
        <path d="M0 0H794V10H0Z" fill="${EMERALD}"/>
        <path d="M0 10H794V12H0Z" fill="${GOLD}"/>
        <path d="M0 818C150 794 265 841 401 816C539 791 659 812 794 780V1123H0Z" fill="${EMERALD}"/>
        <path d="M0 807C152 783 263 830 401 805C540 780 659 801 794 769" fill="none" stroke="${GOLD}" stroke-width="3"/>
        <path d="M0 836C154 815 271 860 409 835C548 810 661 830 794 801" fill="none" stroke="${IVORY}" stroke-width="1" opacity=".38"/>
        <path d="M28 28H766V1095H28Z" fill="none" stroke="${GOLD}" stroke-width="1"/>
      </svg>
      <div aria-hidden="true" style="position:absolute;top:53px;left:64px;right:64px;display:flex;align-items:center;justify-content:space-between">
        <div style="display:flex;align-items:center;gap:12px;color:${EMERALD}">
          <span style="width:25px;height:25px;border:1px solid ${GOLD};transform:rotate(45deg);box-sizing:border-box"></span>
          <span style="margin-right:-25px;width:7px;height:7px;border-radius:50%;background:${EMERALD};border:1px solid ${IVORY};box-sizing:border-box"></span>
          <span style="margin-right:8px;font-family:Georgia,serif;font-size:12px;letter-spacing:.2em;color:#8C7146">ENJAZI</span>
        </div>
        <span style="font-size:11px;color:#8C7146">ملف الإنجاز الوظيفي</span>
      </div>
      <div style="position:absolute;top:350px;left:76px;right:76px;text-align:center">
        <div aria-hidden="true" style="width:54px;height:54px;margin:0 auto 25px;border:1px solid ${GOLD};transform:rotate(45deg);box-sizing:border-box;position:relative">
          <span style="position:absolute;inset:11px;border:1px solid ${EMERALD}"></span>
        </div>
        <div style="color:#8C7146;font-size:12px;letter-spacing:.12em">ختام الملف</div>
        <h1 style="margin:12px 0 0;color:${EMERALD};font-size:35px;font-weight:700;line-height:1.6">شكرًا لاهتمامكم</h1>
        <div style="width:76px;height:2px;margin:17px auto 18px;background:${GOLD}"></div>
        <p style="max-width:530px;margin:0 auto;color:#53615B;font-size:17px;line-height:1.95;overflow-wrap:anywhere">يوثّق هذا الملف الممارسة المهنية ويهيئ مرجعًا واضحًا للعرض والمراجعة.</p>
      </div>
      <div style="position:absolute;bottom:94px;left:64px;right:64px;display:flex;align-items:center;justify-content:space-between;color:${IVORY};font-size:11px;letter-spacing:.1em">
        <span>ENJAZI</span><span>ملف مهني للمعلم</span>
      </div>
    </section>`;
}
var PAGE_A4 = [595.28, 841.89];
var TOC_ROWS_PER_PAGE = 17;
function escapeHtml(value) {
	return String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;").replaceAll("'", "&#39;");
}
function formatDate(value, calendar) {
	return new Intl.DateTimeFormat(`ar-SA-u-ca-${calendar}`, {
		day: "numeric",
		month: "long",
		year: "numeric"
	}).format(value);
}
async function addRasterPage(documentPdf, pngBytes) {
	const image = await documentPdf.embedPng(pngBytes);
	documentPdf.addPage(PAGE_A4).drawImage(image, {
		x: 0,
		y: 0,
		width: PAGE_A4[0],
		height: PAGE_A4[1]
	});
}
function addPageFrame(pageNumber, totalPages) {
	return {
		pageNumber,
		totalPages
	};
}
function bytesToBlob(bytes, type) {
	return new Blob([bytes.slice().buffer], { type });
}
async function normalizeImage(bytes, mimeType) {
	if (typeof createImageBitmap !== "function") throw new Error("Image decoding is unavailable.");
	const bitmap = await createImageBitmap(bytesToBlob(bytes, mimeType));
	const width = bitmap.width;
	const height = bitmap.height;
	if (width < 1 || height < 1) {
		bitmap.close();
		throw new Error("Image dimensions are invalid.");
	}
	if (mimeType === "image/png" || mimeType === "image/jpeg") {
		bitmap.close();
		return {
			bytes,
			mimeType,
			width,
			height
		};
	}
	const canvas = document.createElement("canvas");
	canvas.width = width;
	canvas.height = height;
	const context = canvas.getContext("2d");
	if (!context) {
		bitmap.close();
		throw new Error("Image conversion is unavailable.");
	}
	context.drawImage(bitmap, 0, 0);
	bitmap.close();
	const blob = await new Promise((resolve, reject) => {
		canvas.toBlob((value) => value ? resolve(value) : reject(/* @__PURE__ */ new Error("Image conversion failed.")), "image/png");
	});
	canvas.width = 0;
	canvas.height = 0;
	return {
		bytes: new Uint8Array(await blob.arrayBuffer()),
		mimeType: "image/png",
		width,
		height
	};
}
async function prepareAttachment(input) {
	const unavailable = (reason) => ({
		evidence: input.evidence,
		kind: "unavailable",
		reason
	});
	if (input.error || !input.bytes) return unavailable(input.error || "تعذر الوصول إلى المرفق.");
	if (isPdf(input.evidence.mime_type)) try {
		const source = await PDFDocument.load(input.bytes);
		const pageCount = source.getPageCount();
		if (pageCount === 0) return unavailable("ملف PDF لا يحتوي على صفحات.");
		await (await PDFDocument.create()).copyPages(source, source.getPageIndices());
		return {
			evidence: input.evidence,
			kind: "pdf",
			source,
			pageCount,
			bytes: input.bytes
		};
	} catch {
		return unavailable("تعذر قراءة صفحات ملف PDF أو استيرادها.");
	}
	if (isImage(input.evidence.mime_type)) try {
		const image = await normalizeImage(input.bytes, input.evidence.mime_type);
		const validationDocument = await PDFDocument.create();
		if (image.mimeType === "image/png") await validationDocument.embedPng(image.bytes);
		else await validationDocument.embedJpg(image.bytes);
		return {
			...image,
			kind: "image",
			evidence: input.evidence
		};
	} catch {
		return unavailable("تعذر قراءة ملف الصورة أو تضمينه.");
	}
	return unavailable("نوع الملف غير مدعوم في ملف الإنجاز.");
}
function imagePageMarkup(items) {
	const cssScale = 794 / PAGE_A4[0];
	return `<section data-evidence-image-page="true" data-evidence-item-count="${items.length}">${items.map(({ evidence, layout }) => {
		if (!evidence.pagePlan) throw new Error("Image evidence layout was not prepared.");
		return `<article data-evidence-item="${escapeHtml(evidence.evidence.id)}" data-image-aspect="${evidence.width / evidence.height}">
    <div data-evidence-image-slot="true" style="position:absolute;left:${layout.x * cssScale}px;top:${layout.imageTop * cssScale}px;width:${layout.width * cssScale}px;height:${layout.height * cssScale}px"></div>
    <div data-evidence-caption="true" style="position:absolute;left:${layout.margin * cssScale}px;top:${layout.metadataTop * cssScale}px;width:${layout.metadataWidth * cssScale}px">${evidence.pagePlan.metadata}</div>
    </article>`;
	}).join("")}</section>`;
}
async function embedEvidenceImages(documentPdf, items) {
	const page = documentPdf.getPage(documentPdf.getPageCount() - 1);
	for (const { evidence, layout } of items) {
		const image = evidence.mimeType === "image/png" ? await documentPdf.embedPng(evidence.bytes) : await documentPdf.embedJpg(evidence.bytes);
		page.drawImage(image, {
			x: layout.x,
			y: layout.y,
			width: layout.width,
			height: layout.height
		});
		page.drawRectangle({
			x: layout.x - .5,
			y: layout.y - .5,
			width: layout.width + 1,
			height: layout.height + 1,
			borderColor: rgb(197 / 255, 164 / 255, 109 / 255),
			borderWidth: .6
		});
	}
}
function buildCover(profile, generatedAt, cover = {}) {
	const title = cover.title?.trim().slice(0, 100) || "توثيق الممارسة ومسيرة الأثر";
	const profileDetails = [profile?.subject ? `التخصص: ${profile.subject}` : null, profile?.education_office ? `إدارة التعليم: ${profile.education_office}` : null].filter((value) => Boolean(value));
	return buildRoyalCover({
		name: profile?.full_name || "المعلم",
		...profile?.school ? { school: profile.school } : {},
		...profile?.academic_year ? { year: profile.academic_year } : {},
		details: profileDetails,
		subtitle: title === "ملف الإنجاز الوظيفي" ? "" : title,
		date: formatDate(generatedAt, "gregory"),
		layout: cover.layout === "classic" ? "classic" : "royal",
		accent: cover.accent === "emerald" ? "emerald" : "gold"
	});
}
function teacherInformationPageCount(profile) {
	return Math.max(1, splitEvidenceDescription(profile?.bio ?? "", 520, 900).length);
}
function buildTeacherInformation(profile, pageIndex = 0, pageCount = 1) {
	const fields = [
		["المسمى الوظيفي", profile?.job_title],
		["التخصص", profile?.subject],
		["المرحلة الدراسية", profile?.stage],
		["المدرسة", profile?.school],
		["إدارة التعليم", profile?.education_office],
		["العام الدراسي", profile?.academic_year]
	];
	const bio = splitEvidenceDescription(profile?.bio ?? "", 520, 900)[pageIndex];
	const rows = fields.filter(([, value]) => value !== null && value !== void 0 && value !== "").map(([label, value]) => `
      <div style="padding:16px 18px;border:1px solid #E5DFD2;border-right:2px solid #C5A15B;background:#FFFFFF">
        <div style="font-size:12px;color:#75817D">${escapeHtml(label)}</div>
        <div style="margin-top:7px;font-size:17px;line-height:1.7;color:#202B2A;font-weight:600;overflow-wrap:anywhere">${escapeHtml(value)}</div>
      </div>`);
	const experience = profile?.years_experience;
	return `
    <div style="margin-top:6px">
      ${pageIndex === 0 ? `
        <div style="padding:23px 24px;background:#07594F;position:relative;overflow-wrap:anywhere">
          <div style="font-size:11px;color:#E8DDC7">المعلومات الشخصية والمهنية</div>
          <div style="margin-top:7px;font-size:28px;line-height:1.65;font-weight:700;color:#FFFFFF">${escapeHtml(profile?.full_name || "غير محدد")}</div>
          <div style="position:absolute;left:0;top:0;bottom:0;width:3px;background:#C5A15B"></div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:20px">
          ${rows.join("") || `<p style="grid-column:1/-1;color:#71837d">لا تتوفر بيانات مهنية إضافية في الملف الشخصي.</p>`}
        </div>
        ${experience !== null && experience !== void 0 ? `<div style="margin-top:14px;padding:13px 16px;background:#FFFFFF;border-right:2px solid #07594F"><div style="font-size:11px;color:#75817D">الخبرة المهنية</div><div style="margin-top:4px;color:#202B2A;font-weight:700">${escapeHtml(experience)} سنة</div></div>` : ""}
      ` : `<div style="margin-bottom:14px;border-right:2px solid #C5A15B;padding:8px 12px;color:#6B5B3D;font-size:13px">نبذة مهنية · تكملة ${pageIndex + 1} من ${pageCount}</div>`}
      ${bio ? `<div style="margin-top:16px;padding:14px 17px;background:#F0ECE2;border-right:2px solid #C5A15B"><div style="font-size:11px;color:#765F35;font-weight:700">نبذة مهنية</div><div style="margin-top:6px;white-space:pre-wrap;overflow-wrap:anywhere;color:#40514E;font-size:15px;line-height:1.65">${escapeHtml(bio)}</div></div>` : ""}
      ${pageIndex > 0 && !bio ? `<p style="margin-top:12px;color:#71837d">لا توجد بيانات مهنية إضافية في هذه الصفحة.</p>` : ""}
    </div>`;
}
function buildIntroduction() {
	return `
    <div style="margin-top:24px;border-right:1px solid #D8C9AA;padding-right:24px">
      <div style="border-right:2px solid #C5A15B;background:#F0ECE2;padding:14px 18px">
        <div style="font-size:11px;color:#765F35;font-weight:700">ملاحظة تحريرية</div>
        <p style="margin:5px 0 0;color:#5D5B51;font-size:13px;line-height:1.7">النص الآتي عام وقابل للتحرير، وليس وصفًا لتجربة المعلم أو إنجازاته. يُستحسن استبداله بمقدمة شخصية قبل اعتماد النسخة النهائية.</p>
      </div>
      <h2 style="margin-top:35px;color:#07594F;font-size:24px;border-bottom:1px solid #D8C9AA;padding-bottom:12px">مقدمة عامة قابلة للتحرير</h2>
      <p style="margin-top:10px;line-height:1.85;color:#465956;font-size:15px">يُعد هذا الملف إطارًا لتنظيم توثيق الممارسات المهنية والشواهد المرتبطة بمعايير العمل التعليمي. وتُعرض البيانات الواردة فيه كما أُدخلت في الملف، لتيسير الاطلاع والمراجعة.</p>
      <h2 style="margin-top:35px;color:#07594F;font-size:24px;border-bottom:1px solid #D8C9AA;padding-bottom:12px">أهداف الملف</h2>
      <ul style="padding-right:23px;margin-top:9px;color:#465956;font-size:15px">
        <li style="margin-top:8px">تنظيم الشواهد وربطها بالمعايير المختارة.</li>
        <li style="margin-top:8px">عرض حالة الإنجاز اليدوية وتغطية الشواهد كمؤشرين منفصلين.</li>
        <li style="margin-top:8px">توفير مرجع واضح يسهل مراجعته وتحديثه.</li>
      </ul>
    </div>`;
}
function buildOverview(summaryStandards, progress, evidences) {
	const summary = computeManualProgress(summaryStandards, progress);
	const evidenceCoverage = computeEvidenceCoverage(summaryStandards, evidences);
	const manualProgressWidth = Math.max(0, Math.min(100, summary.weightedPercent));
	const evidenceCoverageWidth = evidenceCoverage.total > 0 ? Math.round(evidenceCoverage.documented / evidenceCoverage.total * 100) : 0;
	const manualMetrics = [["الإنجاز الموزون", `${summary.weightedPercent}٪`], ["مكتمل يدويًا", `${summary.completed} من ${summary.total}`]];
	const evidenceMetrics = [["معايير لها شواهد", `${evidenceCoverage.documented} من ${evidenceCoverage.total}`], ["إجمالي الشواهد المرتبطة", String(evidenceCoverage.evidenceCount)]];
	const evidenceCounts = /* @__PURE__ */ new Map();
	for (const evidence of evidences) evidenceCounts.set(evidence.standard_id, (evidenceCounts.get(evidence.standard_id) ?? 0) + 1);
	const maximumEvidenceCount = Math.max(1, ...evidenceCounts.values());
	const distribution = summaryStandards.map((standard) => {
		const count = evidenceCounts.get(standard.id) ?? 0;
		return {
			standard,
			count,
			width: Math.round(count / maximumEvidenceCount * 100)
		};
	});
	return `
    <div style="margin-top:25px">
      <div style="border-bottom:1px solid #D8C9AA;border-right:3px solid #07594F;padding:0 12px 12px;color:#07594F;font-size:18px;font-weight:700">الحالة اليدوية</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:13px">
        ${manualMetrics.map(([label, value], index) => `<div style="padding:15px 18px;background:#FFFFFF;border-top:2px solid #07594F;box-shadow:0 2px 8px rgba(40,54,53,.04)"><div style="font-size:12px;color:#65736F">${escapeHtml(label)}</div><div style="margin-top:6px;font-size:23px;font-weight:700;color:#07594F">${escapeHtml(value)}</div>${index === 0 ? `<div style="margin-top:10px;height:4px;background:#E5DFD2"><span style="display:block;width:${manualProgressWidth}%;height:100%;background:#07594F"></span></div>` : ""}</div>`).join("")}
      </div>
      <div style="margin-top:25px;border-bottom:1px solid #D8C9AA;border-right:3px solid #C5A15B;padding:0 12px 12px;color:#765F35;font-size:18px;font-weight:700">تغطية الشواهد — مؤشر مستقل</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:13px">
        ${evidenceMetrics.map(([label, value], index) => `<div style="padding:15px 18px;background:#F0ECE2;border-top:2px solid #C5A15B"><div style="font-size:12px;color:#756C56">${escapeHtml(label)}</div><div style="margin-top:6px;font-size:23px;font-weight:700;color:#765F35">${escapeHtml(value)}</div>${index === 0 ? `<div style="margin-top:10px;height:4px;background:#E0D8C7"><span style="display:block;width:${evidenceCoverageWidth}%;height:100%;background:#C5A15B"></span></div>` : ""}</div>`).join("")}
      </div>
      <div style="margin-top:20px">
        <h3 style="margin:0 0 9px;color:#07594F;font-size:14px;font-weight:700">توزيع الشواهد على المعايير</h3>
        <div style="display:grid;gap:5px">
          ${distribution.map(({ standard, count, width }) => `
            <div style="display:grid;grid-template-columns:minmax(0,1fr) 28px;align-items:center;gap:8px;min-height:23px">
              <div style="min-width:0">
                <div style="display:flex;justify-content:space-between;gap:8px;color:#465956;font-size:11px;line-height:1.45">
                  <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escapeHtml(standard.code)} · ${escapeHtml(standard.title)}</span>
                  <span dir="ltr">${count}</span>
                </div>
                <div style="margin-top:3px;height:3px;background:#E0D8C7"><span style="display:block;width:${width}%;height:100%;background:#C5A15B"></span></div>
              </div>
            </div>`).join("")}
        </div>
      </div>
    </div>
    <p style="margin-top:20px;padding-right:12px;border-right:2px solid #C5A15B;color:#65736F;font-size:12px;line-height:1.7">الحالة تُسجّل يدويًا، أما تغطية الشواهد فتُحتسب من المرفقات المرتبطة؛ ولا يدل أحد المؤشرين بالضرورة على الآخر.</p>`;
}
/** Shared by counting and rendering: never skip across PDFs, unavailable files, or standards. */
function evidenceBatches(section) {
	const batches = [];
	for (let index = 0; index < section.evidences.length; index++) {
		const evidence = section.evidences[index];
		if (evidence.kind !== "image") {
			batches.push({
				kind: "attachment",
				evidence
			});
			continue;
		}
		if (!evidence.pagePlan) throw new Error("Image evidence layout was not prepared.");
		const candidates = [evidence];
		if (evidence.pagePlan.descriptionChunks.length === 1) for (let offset = 1; offset < section.target; offset++) {
			const next = section.evidences[index + offset];
			if (next?.kind !== "image" || !next.pagePlan || next.pagePlan.descriptionChunks.length !== 1) break;
			candidates.push(next);
		}
		let layouts = null;
		while (!layouts) {
			layouts = layoutEvidenceGroup(candidates.map((candidate) => ({
				...candidate.pagePlan.layout,
				metadataHeight: section.target === 4 && candidates.length > 1 ? candidate.pagePlan.narrowMetadataHeight : candidate.pagePlan.layout.metadataHeight
			})), section.target);
			if (!layouts) candidates.pop();
		}
		const items = candidates.map((candidate, offset) => ({
			evidence: candidate,
			layout: layouts[offset]
		}));
		index += candidates.length - 1;
		batches.push({
			kind: "images",
			items
		});
	}
	return batches;
}
function buildContentsPage(sections, pageIndex, pageCount) {
	return `
    <div style="margin-top:8px;background:#FFFFFF;padding:4px 15px">
      <div style="display:grid;grid-template-columns:64px 1fr 54px;gap:10px;padding:9px 3px;border-bottom:1px solid #C5A15B;color:#765F35;font-size:11px;font-weight:700">
        <span>الرمز</span><span>المعيار</span><span style="text-align:left">الصفحة</span>
      </div>
      ${sections.slice(pageIndex * TOC_ROWS_PER_PAGE, (pageIndex + 1) * TOC_ROWS_PER_PAGE).map((section) => `
            <div data-toc-standard="${escapeHtml(section.standard?.code || "")}" data-toc-page="${section.startPage}" style="display:grid;grid-template-columns:64px 1fr 54px;gap:10px;align-items:center;border-bottom:1px solid #EEE9DE;padding:9px 3px">
              <span style="color:#765F35;font-size:12px">${escapeHtml(section.standard?.code || "—")}</span>
              <span style="font-weight:600;color:#202B2A;font-size:14px;line-height:1.5;overflow-wrap:anywhere">${escapeHtml(section.title)}</span>
              <span style="text-align:left;color:#07594F;font-family:monospace;font-weight:700">${escapeHtml(section.startPage)}</span>
            </div>`).join("") || `<p style="color:#697773">لا توجد معايير لعرضها.</p>`}
      <p style="margin-top:15px;text-align:center;font-size:11px;color:#697773">فهرس ${pageIndex + 1} من ${pageCount}</p>
    </div>`;
}
function buildStandardPage(section, progress, number) {
	const status = section.standard ? statusFor(section.standard.id, progress) : "not_started";
	const notes = section.standard ? progress.find((p) => p.standard_id === section.standard?.id)?.notes : null;
	const numericCode = Number(section.standard?.code);
	return buildStandardCover({
		number: Number.isInteger(numericCode) && numericCode > 0 ? numericCode : number,
		code: section.standard?.code ?? "—",
		title: section.title,
		description: section.standard?.description ?? null,
		indicators: section.standard?.indicators ?? [],
		status: STATUS_LABELS[status],
		weight: section.standard?.weight ?? null,
		evidenceCount: section.evidences.length,
		notes: notes ?? null
	});
}
function splitEvidenceDescription(description, firstPageLimit = 450, continuationLimit = 1e3) {
	if (!description) return [];
	const characters = Array.from(description);
	const chunks = [];
	let offset = 0;
	let limit = firstPageLimit;
	while (offset < characters.length) {
		let end = Math.min(offset + limit, characters.length);
		if (end < characters.length) {
			const wordBoundary = characters.lastIndexOf(" ", end);
			if (wordBoundary > offset + Math.floor(limit * .7)) end = wordBoundary;
		}
		chunks.push(characters.slice(offset, end).join(""));
		offset = end;
		limit = continuationLimit;
	}
	return chunks;
}
function evidenceMetadataPageCount(evidence) {
	if (evidence.kind === "image") {
		if (!evidence.pagePlan) throw new Error("Image evidence layout was not prepared.");
		return Math.max(0, evidence.pagePlan.descriptionChunks.length - 1);
	}
	return Math.max(1, splitEvidenceDescription(evidence.evidence.description).length);
}
function buildImageCaption(section, file, description) {
	return `<div style="direction:rtl;text-align:right;border-top:1px solid #C5A15B;padding-top:8px;color:#202B2A">
    <h2 style="margin:0;font-size:18px;line-height:1.6;font-weight:700;color:#07594F;overflow-wrap:anywhere">${escapeHtml(file.title)}</h2>
    ${description ? `<div style="margin-top:7px;font-size:14px;line-height:1.8;white-space:pre-wrap;overflow-wrap:anywhere">${escapeHtml(description)}</div>` : ""}
    <div style="margin-top:4px;font-size:12px;line-height:1.8;color:#765F35;overflow-wrap:anywhere">المعيار ${escapeHtml(section.standard?.code || "—")}${file.evidence_date ? ` · ${escapeHtml(formatEvidenceDate(file.evidence_date))}` : ""}</div>
  </div>`;
}
async function prepareImagePage(section, evidence) {
	const chunks = splitImageDescription(evidence.evidence.description);
	const descriptionChunks = chunks.length ? chunks : [""];
	let metadata = buildImageCaption(section, evidence.evidence, descriptionChunks[0] ?? "");
	const measure = (html, width = 687.3) => {
		const container = document.createElement("div");
		container.dir = "rtl";
		container.style.cssText = `position:fixed;left:0;top:0;visibility:hidden;width:${width}px;font-family:'IBM Plex Sans Arabic',system-ui,sans-serif;font-size:18px;line-height:1.75;box-sizing:border-box`;
		container.innerHTML = html;
		document.body.appendChild(container);
		try {
			return container.getBoundingClientRect().height * PAGE_A4[0] / 794;
		} finally {
			container.remove();
		}
	};
	await document.fonts?.ready;
	let height = measure(metadata) || 88;
	if (height > 240 && descriptionChunks[0]) {
		descriptionChunks.unshift("");
		metadata = buildImageCaption(section, evidence.evidence, "");
		height = measure(metadata) || 130;
	}
	evidence.pagePlan = {
		descriptionChunks,
		metadata,
		layout: layoutEvidenceImage(evidence.width, evidence.height, height + 6),
		narrowMetadataHeight: (measure(metadata, (PAGE_A4[0] - 80 - 22) / 2 * 794 / PAGE_A4[0]) || height * 1.8) + 6
	};
}
function buildEvidenceMetadata(section, evidence, description, continuationPage, totalDescriptionPages) {
	const file = evidence.evidence;
	return `
    <div style="margin-top:5px">
       <div style="color:#765F35;font-size:12px;border-right:2px solid #C5A15B;padding-right:9px">المعيار ${escapeHtml(section.standard?.code || "—")} · ${escapeHtml(section.title)}</div>
        <h2 style="margin-top:9px;color:#07594F;font-size:24px;line-height:1.45;overflow-wrap:anywhere">${escapeHtml(file.title)}</h2>
      ${continuationPage === 0 ? `
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:20px">
            ${file.evidence_date ? `<div style="background:#FFFFFF;border-bottom:1px solid #D8C9AA;padding:10px 12px"><span style="color:#697773;font-size:11px">تاريخ الشاهد</span><div style="margin-top:4px;font-size:13px;color:#202B2A">${escapeHtml(formatEvidenceDate(file.evidence_date))}</div></div>` : ""}
            <div style="background:#FFFFFF;border-bottom:1px solid #D8C9AA;padding:10px 12px"><span style="color:#697773;font-size:11px">نوع الملف</span><div style="margin-top:4px;font-size:13px;color:#202B2A;overflow-wrap:anywhere">${escapeHtml(file.mime_type)}</div></div>
            <div style="background:#FFFFFF;border-bottom:1px solid #D8C9AA;padding:10px 12px"><span style="color:#697773;font-size:11px">حجم الملف</span><div style="margin-top:4px;font-size:13px;color:#202B2A">${escapeHtml(formatBytes(file.file_size))}</div></div>
        </div>` : `<p style="margin-top:22px;color:#54716c">تكملة وصف الشاهد (${continuationPage + 1} من ${totalDescriptionPages})</p>`}
       ${description ? `<div style="margin-top:19px;padding:13px 15px;background:#F0ECE2;white-space:pre-wrap;overflow-wrap:anywhere"><strong style="color:#07594F;font-size:13px">وصف الشاهد</strong><p style="margin-top:6px;color:#465956;font-size:14px;line-height:1.75">${escapeHtml(description)}</p></div>` : ""}
       ${evidence.kind === "pdf" && continuationPage === 0 ? `<div style="margin-top:17px;color:#465956;font-size:13px">عدد صفحات المرفق: <strong style="color:#07594F">${evidence.pageCount}</strong></div>` : ""}
    </div>`;
}
function buildUnavailablePage(section, evidence) {
	const file = evidence.evidence;
	return `
    <div style="margin-top:7px;padding:21px;background:#F0ECE2;border-right:3px solid #C5A15B">
      <div style="font-size:11px;color:#765F35">بيان حالة المرفق</div>
      <h2 style="margin-top:6px;color:#07594F;font-size:23px">تعذر تضمين هذا المرفق</h2>
      <div style="margin-top:14px;color:#202B2A;overflow-wrap:anywhere"><strong>الشاهد:</strong> ${escapeHtml(file.title)}</div>
      <div style="margin-top:7px;color:#465956;overflow-wrap:anywhere"><strong>المعيار:</strong> ${escapeHtml(section.standard?.code || "—")} · ${escapeHtml(section.title)}</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:16px">
        <div style="padding:9px;background:#FFFFFF"><span style="font-size:11px;color:#697773">التاريخ</span><div style="font-size:13px">${escapeHtml(formatEvidenceDate(file.evidence_date ?? file.created_at))}</div></div>
        <div style="padding:9px;background:#FFFFFF"><span style="font-size:11px;color:#697773">النوع</span><div style="font-size:13px">${escapeHtml(file.mime_type)}</div></div>
        <div style="padding:9px;background:#FFFFFF"><span style="font-size:11px;color:#697773">الحجم</span><div style="font-size:13px">${escapeHtml(formatBytes(file.file_size))}</div></div>
      </div>
      ${file.description ? `<p style="margin-top:14px;white-space:pre-wrap;overflow-wrap:anywhere;font-size:13px"><strong>الوصف:</strong> ${escapeHtml(file.description)}</p>` : ""}
      <p style="margin-top:14px;color:#765F35;font-size:13px;overflow-wrap:anywhere"><strong>السبب:</strong> ${escapeHtml(evidence.reason)}</p>
      <p style="margin-top:14px;color:#586A66;font-size:12px;line-height:1.7">أُدرج هذا التقرير لإظهار المرفق الذي تعذر الوصول إليه أو قراءته. لم تُستبدل صفحاته بمحتوى آخر.</p>
    </div>`;
}
function buildPageMap(sections, tocPageCount, teacherPageCount) {
	let nextPage = 4 + teacherPageCount + tocPageCount;
	for (const section of sections) {
		section.startPage = nextPage;
		nextPage++;
		for (const batch of evidenceBatches(section)) {
			if (batch.kind === "images") {
				nextPage += 1 + batch.items.reduce((count, { evidence }) => count + evidenceMetadataPageCount(evidence), 0);
				continue;
			}
			const evidence = batch.evidence;
			if (evidence.kind === "unavailable") nextPage++;
			else {
				nextPage += evidenceMetadataPageCount(evidence);
				nextPage += evidence.kind === "pdf" ? evidence.pageCount : 1;
			}
		}
	}
	return { closingPage: nextPage };
}
/**
* Creates a self-contained portfolio PDF in the browser. Evidence files are supplied by
* the caller so tests can use local synthetic fixtures without contacting Supabase.
*/
async function planPortfolioPages(input) {
	const generatedAt = input.generatedAt ?? /* @__PURE__ */ new Date();
	const prepared = [];
	for (const attachment of input.attachments) prepared.push(await prepareAttachment(attachment));
	const evidenceByStandard = /* @__PURE__ */ new Map();
	for (const evidence of prepared) {
		const rows = evidenceByStandard.get(evidence.evidence.standard_id) ?? [];
		rows.push(evidence);
		evidenceByStandard.set(evidence.evidence.standard_id, rows);
	}
	const standardById = new Map(input.standards.map((standard) => [standard.id, standard]));
	const sections = [.../* @__PURE__ */ new Set([...input.standards.map((standard) => standard.id), ...evidenceByStandard.keys()])].map((id) => {
		const standard = standardById.get(id) ?? null;
		return {
			id,
			standard,
			title: standard?.title ?? "معيار غير متاح",
			evidences: evidenceByStandard.get(id) ?? [],
			startPage: 0,
			target: evidenceLayoutFor(input.evidenceLayout, id)
		};
	});
	sections.sort((a, b) => {
		return (a.standard ? input.standards.findIndex((standard) => standard.id === a.id) : Number.MAX_SAFE_INTEGER) - (b.standard ? input.standards.findIndex((standard) => standard.id === b.id) : Number.MAX_SAFE_INTEGER) || a.title.localeCompare(b.title, "ar");
	});
	for (const section of sections) for (const evidence of section.evidences) if (evidence.kind === "image") await prepareImagePage(section, evidence);
	const tocPageCount = Math.max(1, Math.ceil(sections.length / TOC_ROWS_PER_PAGE));
	const teacherPageCount = teacherInformationPageCount(input.profile);
	const closingPage = buildPageMap(sections, tocPageCount, teacherPageCount).closingPage;
	const finalPageCount = closingPage;
	const pages = [];
	const generated = (content, heading, frame) => {
		pages.push({
			kind: "generated",
			content,
			heading,
			frame,
			images: []
		});
	};
	generated(buildCover(input.profile, generatedAt, input.cover), void 0, addPageFrame(1, finalPageCount));
	for (let pageIndex = 0; pageIndex < teacherPageCount; pageIndex++) generated(buildTeacherInformation(input.profile, pageIndex, teacherPageCount), pageIndex === 0 ? "الملف المهني" : "الملف المهني · تكملة", addPageFrame(2 + pageIndex, finalPageCount));
	const introductionPage = 2 + teacherPageCount;
	generated(buildIntroduction(), "مقدمة وأهداف الملف", addPageFrame(introductionPage, finalPageCount));
	const summaryStandards = input.summaryStandards ?? input.standards;
	const overviewPage = introductionPage + 1;
	generated(buildOverview(summaryStandards, input.progress, prepared.map((item) => ({ standard_id: item.evidence.standard_id }))), "ملخص الإنجاز", addPageFrame(overviewPage, finalPageCount));
	for (let index = 0; index < tocPageCount; index++) {
		const pageNumber = overviewPage + 1 + index;
		generated(buildContentsPage(sections, index, tocPageCount), "فهرس المعايير", addPageFrame(pageNumber, finalPageCount));
	}
	const warnings = [];
	let completed = 0;
	const total = prepared.length;
	let pageNumber = overviewPage + 1 + tocPageCount;
	const appendSectionEvidence = async (section) => {
		for (const batch of evidenceBatches(section)) {
			if (batch.kind === "images") {
				pages.push({
					kind: "generated",
					content: imagePageMarkup(batch.items),
					heading: void 0,
					frame: addPageFrame(pageNumber++, finalPageCount),
					images: batch.items
				});
				for (const { evidence } of batch.items) {
					const chunks = evidence.pagePlan.descriptionChunks;
					for (let index = 1; index < chunks.length; index++) generated(buildEvidenceMetadata(section, evidence, chunks[index] ?? "", index, chunks.length), "تكملة وصف الشاهد", addPageFrame(pageNumber++, finalPageCount));
					completed++;
					input.onProgress?.(completed, total);
				}
				continue;
			}
			const evidence = batch.evidence;
			if (evidence.kind === "unavailable") {
				generated(buildUnavailablePage(section, evidence), "تنبيه بشأن مرفق", addPageFrame(pageNumber++, finalPageCount));
				warnings.push({
					fileName: evidence.evidence.file_name,
					standardTitle: section.title
				});
			} else {
				const descriptionChunks = splitEvidenceDescription(evidence.evidence.description);
				const metadataPageCount = Math.max(1, descriptionChunks.length);
				for (let page = 0; page < metadataPageCount; page++) generated(buildEvidenceMetadata(section, evidence, descriptionChunks[page] ?? "", page, metadataPageCount), page === 0 ? "بيانات الشاهد" : "تكملة بيانات الشاهد", addPageFrame(pageNumber++, finalPageCount));
				for (const index of evidence.source.getPageIndices()) {
					pages.push({
						kind: "original",
						source: evidence.source,
						bytes: evidence.bytes,
						index,
						title: evidence.evidence.title
					});
					pageNumber++;
				}
			}
			completed++;
			input.onProgress?.(completed, total);
		}
	};
	for (const [index, section] of sections.entries()) {
		generated(buildStandardPage(section, input.progress, index + 1), void 0, addPageFrame(pageNumber++, finalPageCount));
		await appendSectionEvidence(section);
	}
	generated(buildRoyalClosing(), "ختام الملف", addPageFrame(closingPage, finalPageCount));
	if (pages.length !== finalPageCount) throw new Error("Portfolio pagination mismatch.");
	return {
		pages,
		warnings
	};
}
/** Preview and download consume exactly the same measured, numbered page plan. */
async function createPortfolioPdf(input) {
	const plan = await planPortfolioPages(input);
	const documentPdf = await PDFDocument.create();
	documentPdf.setTitle("ملف الإنجاز الوظيفي — إنجازي");
	if (input.profile?.full_name) documentPdf.setAuthor(input.profile.full_name);
	for (let index = 0; index < plan.pages.length; index++) {
		const page = plan.pages[index];
		if (page.kind === "original") {
			const indices = [page.index];
			while (index + 1 < plan.pages.length) {
				const next = plan.pages[index + 1];
				if (next.kind !== "original" || next.source !== page.source) break;
				indices.push(next.index);
				index++;
			}
			const copied = await documentPdf.copyPages(page.source, indices);
			for (const original of copied) documentPdf.addPage(original);
		} else {
			await addRasterPage(documentPdf, await renderPortfolioPage(page.content, page.heading, page.frame));
			await embedEvidenceImages(documentPdf, page.images);
		}
		input.onPageProgress?.(index + 1, plan.pages.length);
	}
	return {
		bytes: await documentPdf.save(),
		warnings: plan.warnings,
		pageCount: documentPdf.getPageCount()
	};
}
var defaultEvidenceLayout = () => ({
	defaultItemsPerPage: 2,
	byStandard: {}
});
var valid = (value) => [
	1,
	2,
	3,
	4
].includes(value);
/** Only layout choices are stored locally, never evidence, teacher information, or file URLs. */
function parseEvidenceLayout(value) {
	try {
		const parsed = JSON.parse(value ?? "null");
		if (!parsed || typeof parsed !== "object") return defaultEvidenceLayout();
		const record = parsed;
		const byStandard = {};
		if (record["byStandard"] && typeof record["byStandard"] === "object") {
			for (const [id, count] of Object.entries(record["byStandard"])) if (valid(count) && ![
				"__proto__",
				"constructor",
				"prototype"
			].includes(id)) byStandard[id] = count;
		}
		return {
			defaultItemsPerPage: valid(record["defaultItemsPerPage"]) ? record["defaultItemsPerPage"] : 2,
			byStandard
		};
	} catch {
		return defaultEvidenceLayout();
	}
}
var LAYOUT_OPTIONS = [
	{
		value: 1,
		label: "عنصر واحد",
		detail: "مساحة أوسع"
	},
	{
		value: 2,
		label: "عنصران",
		detail: "متوازن"
	},
	{
		value: 3,
		label: "ثلاثة عناصر",
		detail: "مكثّف"
	},
	{
		value: 4,
		label: "أربعة عناصر",
		detail: "شبكة ٢ × ٢"
	}
];
function LayoutPreview({ count }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		"aria-hidden": "true",
		className: `grid h-9 w-9 shrink-0 gap-1 rounded-lg border border-primary/15 bg-background p-1 ${count === 4 ? "grid-cols-2" : "grid-cols-1"}`,
		children: Array.from({ length: count }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `rounded-[3px] bg-primary/25 ${count === 1 ? "min-h-0" : ""} ` }, index))
	});
}
function EvidenceLayoutControls({ preferences, onChange, standards, disabled = false }) {
	const overrideCount = Object.keys(preferences.byStandard).length;
	function changeDefault(value) {
		onChange({
			...preferences,
			defaultItemsPerPage: value
		});
	}
	function changeStandard(standardId, value) {
		const byStandard = { ...preferences.byStandard };
		if (value === "inherit") delete byStandard[standardId];
		else byStandard[standardId] = Number(value);
		onChange({
			...preferences,
			byStandard
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		dir: "rtl",
		"aria-labelledby": "evidence-layout-title",
		className: "overflow-hidden rounded-3xl border border-border bg-card shadow-soft",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-b border-border bg-primary-soft/45 px-5 py-5 sm:px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-10 shrink-0 place-items-center rounded-2xl border border-primary/10 bg-card text-primary shadow-sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, {
						className: "size-5",
						"aria-hidden": "true"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-wide text-primary",
							children: "إعدادات العرض والطباعة"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "evidence-layout-title",
							className: "mt-1 text-lg font-bold text-primary-deep",
							children: "تخطيط الشواهد"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 max-w-2xl text-sm leading-relaxed text-muted-foreground",
							children: "حدّد الحد الأقصى للشواهد في الصفحة، ويمكنك تخصيصه لكل معيار عند الحاجة."
						})
					]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-6 p-5 sm:p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
					disabled,
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "text-sm font-semibold text-foreground",
							children: "الحد الأقصى الافتراضي في الصفحة"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs leading-relaxed text-muted-foreground",
							children: "يُطبّق على جميع المعايير ما لم تختر إعدادًا مختلفًا لأحدها."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4",
							children: LAYOUT_OPTIONS.map((option) => {
								const selected = preferences.defaultItemsPerPage === option.value;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"aria-pressed": selected,
									onClick: () => changeDefault(option.value),
									className: `group flex min-h-[76px] items-center gap-2 rounded-2xl border px-3 py-2 text-start transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 ${selected ? "border-primary bg-primary-soft/70 text-primary-deep shadow-sm" : "border-border bg-background text-foreground hover:border-primary/40 hover:bg-primary-soft/25"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutPreview, { count: option.value }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-sm font-semibold leading-snug",
											children: option.label
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-0.5 block text-[11px] text-muted-foreground",
											children: option.detail
										})]
									})]
								}, option.value);
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-2xl border border-[#C5A15B]/35 bg-[#C5A15B]/[0.08] px-4 py-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelsTopLeft, {
							className: "mt-0.5 size-4 shrink-0 text-[#94743B]",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs leading-relaxed text-foreground/80",
							children: "أربعة شواهد تظهر بتنسيق ٢ × ٢. الأعداد المحددة أهداف قصوى وليست إلزامية؛ يبقى عنوان كل شاهد ووصفه مع صورته، وتظل ملفات PDF الأصلية دون أي تغيير."
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-t border-border pt-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-end justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-semibold text-foreground",
							children: "تخصيص حسب المعيار"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs leading-relaxed text-muted-foreground",
							children: [
								"اختر «استخدام الافتراضي» ليرث المعيار الحد العام (",
								preferences.defaultItemsPerPage,
								")."
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-full border border-border bg-secondary/70 px-2.5 py-1 text-[11px] font-medium text-muted-foreground",
							children: [overrideCount, " تخصيص"]
						})]
					}), standards.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 rounded-2xl border border-dashed border-border bg-background px-4 py-5 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-foreground",
							children: "لا توجد معايير متاحة للتخصيص"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted-foreground",
							children: "سيُطبّق الحد الافتراضي على ملف الإنجاز."
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 divide-y divide-border rounded-2xl border border-border bg-background",
						children: standards.map((standard) => {
							const override = preferences.byStandard[standard.id];
							const selectId = `evidence-layout-${standard.id}`;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-2.5 px-3 py-3 sm:flex-row sm:items-center sm:justify-between sm:px-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] font-semibold text-primary",
										dir: "auto",
										children: standard.code
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-0.5 text-sm font-medium leading-snug text-foreground",
										dir: "auto",
										children: standard.title
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex shrink-0 items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										htmlFor: selectId,
										className: "sr-only",
										children: [
											"عدد الشواهد في الصفحة لمعيار ",
											standard.code,
											" ",
											standard.title
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										id: selectId,
										value: override ?? "inherit",
										disabled,
										onChange: (event) => changeStandard(standard.id, event.target.value),
										className: "h-10 w-full min-w-0 rounded-xl border border-input bg-card px-3 text-sm text-foreground outline-none transition focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 sm:w-[210px]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
											value: "inherit",
											children: [
												"استخدام الافتراضي (",
												preferences.defaultItemsPerPage,
												")"
											]
										}), LAYOUT_OPTIONS.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
											value: option.value,
											children: [option.label, " كحد أقصى"]
										}, option.value))]
									})]
								})]
							}, standard.id);
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-2 border-t border-border pt-4 text-xs leading-relaxed text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockKeyhole, {
							className: "mt-0.5 size-4 shrink-0 text-primary",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "تُحفظ هذه التفضيلات في هذا المتصفح فقط، ولا تغيّر ملفات الشواهد الأصلية." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {
							className: "ms-auto mt-0.5 size-4 shrink-0 text-[#94743B]",
							"aria-hidden": "true"
						})
					]
				})
			]
		})]
	});
}
function GeneratedPage({ page }) {
	const ref = (0, import_react.useRef)(null);
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useLayoutEffect)(() => {
		const root = ref.current;
		if (!root) return;
		let cancelled = false;
		setError("");
		const urls = [];
		root.innerHTML = portfolioPageMarkup(page.content, page.heading, page.frame);
		root.querySelectorAll("[data-evidence-image-slot]").forEach((slot, index) => {
			const item = page.images[index];
			if (!item) return;
			const url = URL.createObjectURL(new Blob([item.evidence.bytes.slice().buffer], { type: item.evidence.mimeType }));
			urls.push(url);
			const image = document.createElement("img");
			image.src = url;
			image.alt = item.evidence.evidence.title;
			image.style.cssText = "display:block;width:100%;height:100%;object-fit:contain;outline:.6px solid #C5A46D";
			slot.append(image);
		});
		document.fonts?.ready.then(() => {
			if (!cancelled) try {
				fitStandardCover(root);
			} catch (cause) {
				setError(cause instanceof Error ? cause.message : "تعذر عرض الصفحة.");
			}
		});
		return () => {
			cancelled = true;
			urls.forEach((url) => URL.revokeObjectURL(url));
		};
	}, [page]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: "alert",
		className: "mb-3 text-sm text-destructive",
		children: error
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		lang: "ar",
		dir: "rtl",
		"data-a4-preview-page": true,
		style: {
			position: "relative",
			width: 794,
			height: 1123,
			overflow: "hidden",
			boxSizing: "border-box",
			background: "#F8F5EC",
			color: "#252A28",
			fontFamily: "'IBM Plex Sans Arabic',system-ui,sans-serif",
			fontSize: 18,
			lineHeight: 1.75
		}
	})] });
}
function OriginalPage({ page }) {
	const [image, setImage] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		let pdf;
		setImage(null);
		setError("");
		(async () => {
			try {
				const { openPdf, renderPdfPage } = await import("./pdf-render-aD6tPodn.mjs");
				pdf = await openPdf(page.bytes.slice().buffer);
				if (cancelled) return;
				const result = await renderPdfPage(pdf, page.index + 1, 1100);
				if (!cancelled) setImage({
					...result,
					page
				});
			} catch {
				if (!cancelled) setError("تعذر عرض صفحة المرفق الأصلي. يمكنك إعادة المحاولة؛ لن يُحذف المرفق من التصدير.");
			} finally {
				await pdf?.destroy();
			}
		})();
		return () => {
			cancelled = true;
		};
	}, [page]);
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: "alert",
		className: "p-6 text-destructive",
		children: error
	});
	return image?.page === page ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: image.dataUrl,
		alt: `${page.title} — صفحة ${page.index + 1}`,
		className: "mx-auto max-w-full"
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "p-6",
		children: "جارٍ عرض صفحة المرفق الأصلي…"
	});
}
/** No raster export on each click: both preview and PDF consume the same measured page manifest. */
function PortfolioA4Preview({ input, loading, loadError }) {
	const [result, setResult] = (0, import_react.useState)();
	const [pageIndex, setPageIndex] = (0, import_react.useState)(0);
	const container = (0, import_react.useRef)(null);
	const [width, setWidth] = (0, import_react.useState)(640);
	(0, import_react.useEffect)(() => {
		const node = container.current;
		if (!node) return;
		if (typeof ResizeObserver === "undefined") {
			const resize = () => setWidth(node.clientWidth || 640);
			resize();
			window.addEventListener("resize", resize);
			return () => window.removeEventListener("resize", resize);
		}
		const observer = new ResizeObserver(([entry]) => {
			if (entry) setWidth(entry.contentRect.width);
		});
		observer.observe(node);
		return () => observer.disconnect();
	}, []);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		if (loading || loadError) return;
		planPortfolioPages(input).then((plan) => {
			if (!cancelled) {
				setResult({
					input,
					plan
				});
				setPageIndex((index) => Math.min(index, plan.pages.length - 1));
			}
		}).catch((cause) => {
			if (!cancelled) setResult({
				input,
				error: cause instanceof Error ? cause.message : "تعذر إعداد المعاينة."
			});
		});
		return () => {
			cancelled = true;
		};
	}, [
		input,
		loading,
		loadError
	]);
	const current = result?.input === input && !loading && !loadError;
	const plan = current ? result.plan : void 0;
	const page = plan?.pages[pageIndex];
	const scale = Math.min(1, Math.max(.1, width / 794));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-4 rounded-3xl border border-border bg-card p-4 shadow-soft sm:p-6 print:hidden",
		dir: "rtl",
		"aria-label": "معاينة صفحات PDF",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold text-primary-deep",
					children: "معاينة A4 المباشرة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: "نفس توزيع التصدير وفواصل الصفحات والفهرس. ملفات PDF الأصلية تحتفظ بمقاساتها واتجاهها."
				})] }), plan && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							size: "sm",
							variant: "outline",
							onClick: () => setPageIndex((index) => Math.max(0, index - 1)),
							disabled: pageIndex === 0,
							children: "السابق"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2 text-sm",
							children: [
								"الصفحة",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									"aria-label": "صفحة المعاينة",
									className: "rounded border border-border bg-background p-1",
									value: pageIndex,
									onChange: (event) => setPageIndex(Number(event.target.value)),
									children: plan.pages.map((_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: index,
										children: index + 1
									}, index))
								}),
								" من ",
								plan.pages.length
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							size: "sm",
							variant: "outline",
							onClick: () => setPageIndex((index) => Math.min(plan.pages.length - 1, index + 1)),
							disabled: pageIndex === plan.pages.length - 1,
							children: "التالي"
						})
					]
				})]
			}),
			loadError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "text-sm text-destructive",
				children: "تعذر تحميل بيانات المرفقات للمعاينة."
			}) : !current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "status",
				className: "text-sm text-muted-foreground",
				children: "جارٍ تحديث الصفحات وفق التخطيط المختار…"
			}) : result.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "text-sm text-destructive",
				children: result.error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: container,
				"aria-busy": !current,
				className: "min-w-0 rounded-xl bg-[#102C28]/10 p-0",
				children: [page?.kind === "generated" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: {
						height: 1123 * scale,
						width: "100%",
						overflow: "hidden"
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							width: 794,
							transform: `scale(${scale})`,
							transformOrigin: "top right",
							marginLeft: "auto"
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GeneratedPage, { page })
					})
				}), page?.kind === "original" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OriginalPage, { page }, pageIndex)]
			})
		]
	});
}
var NO_ATTACHMENTS = [];
function Portfolio() {
	const { user } = Route.useRouteContext();
	const { data: standards } = useSuspenseQuery(standardsQuery());
	const { data: allStandards } = useSuspenseQuery(allStandardsQuery());
	const { data: progress } = useSuspenseQuery(progressQuery());
	const { data: evidences } = useSuspenseQuery(evidencesQuery());
	const { data: profile } = useSuspenseQuery(profileQuery(user.id));
	const [showEmpty, setShowEmpty] = (0, import_react.useState)(true);
	const [exporting, setExporting] = (0, import_react.useState)(false);
	const [exportProgress, setExportProgress] = (0, import_react.useState)("");
	const [exportError, setExportError] = (0, import_react.useState)("");
	const [evidenceLayout, setEvidenceLayout] = (0, import_react.useState)(defaultEvidenceLayout);
	const [preferencesLoaded, setPreferencesLoaded] = (0, import_react.useState)("");
	const [preferenceWarning, setPreferenceWarning] = (0, import_react.useState)("");
	const [generatedAt] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	const preferenceKey = `injazi:portfolio-layout:${user.id}`;
	(0, import_react.useEffect)(() => {
		try {
			setEvidenceLayout(parseEvidenceLayout(localStorage.getItem(preferenceKey)));
		} catch {
			setEvidenceLayout(defaultEvidenceLayout());
			setPreferenceWarning("تعذر قراءة التفضيلات المحلية؛ سيُستخدم التخطيط الافتراضي.");
		}
		setPreferencesLoaded(preferenceKey);
	}, [preferenceKey]);
	(0, import_react.useEffect)(() => {
		if (preferencesLoaded !== preferenceKey) return;
		try {
			localStorage.setItem(preferenceKey, JSON.stringify(evidenceLayout));
		} catch {
			setPreferenceWarning("التخطيط يعمل لهذه الجلسة، لكن المتصفح لا يسمح بحفظ التفضيلات.");
		}
	}, [
		evidenceLayout,
		preferenceKey,
		preferencesLoaded
	]);
	const [cover, setCover] = (0, import_react.useState)({
		layout: "royal",
		accent: "gold",
		title: "ملف الإنجاز الوظيفي"
	});
	const summary = computeManualProgress(standards, progress);
	const evidenceCoverage = computeEvidenceCoverage(standards, evidences);
	const imagePaths = evidences.filter((e) => isImage(e.mime_type)).map((e) => e.file_path);
	const { data: urls } = useQuery({
		queryKey: ["signed-urls", imagePaths],
		enabled: imagePaths.length > 0,
		staleTime: 18e5,
		queryFn: async () => {
			const { data, error } = await supabase.storage.from("evidence").createSignedUrls(imagePaths, 3600);
			if (error) throw error;
			const map = {};
			for (const row of data) if (row.path && row.signedUrl) map[row.path] = row.signedUrl;
			return map;
		}
	});
	const today = /* @__PURE__ */ new Date();
	const hijri = today.toLocaleDateString("ar-SA-u-ca-islamic-umalqura", {
		day: "numeric",
		month: "long",
		year: "numeric"
	});
	const greg = today.toLocaleDateString("ar-SA-u-ca-gregory", {
		day: "numeric",
		month: "long",
		year: "numeric"
	});
	const portfolioStandards = (0, import_react.useMemo)(() => {
		const evidenceIds = new Set(evidences.map((e) => e.standard_id));
		const activeIds = new Set(standards.map((s) => s.id));
		return [...standards, ...allStandards.filter((s) => !activeIds.has(s.id) && evidenceIds.has(s.id))].filter((s) => showEmpty || evidenceIds.has(s.id));
	}, [
		standards,
		allStandards,
		evidences,
		showEmpty
	]);
	const visible = portfolioStandards;
	const hasPlaceholders = standards.some((s) => s.is_placeholder);
	const attachmentQuery = useQuery({
		queryKey: [
			"portfolio-preview-attachments",
			user.id,
			evidences
		],
		staleTime: 3e5,
		gcTime: 3e5,
		queryFn: async () => {
			const result = [];
			for (const evidence of [...evidences].sort(compareEvidenceChronological)) try {
				const { data, error } = await supabase.storage.from("evidence").download(evidence.file_path);
				if (error) throw error;
				result.push({
					evidence,
					bytes: new Uint8Array(await data.arrayBuffer())
				});
			} catch {
				result.push({
					evidence,
					error: "تعذر الوصول إلى الملف في مساحة الشواهد الخاصة."
				});
			}
			return result;
		}
	});
	const previewInput = (0, import_react.useMemo)(() => ({
		profile,
		standards: portfolioStandards,
		summaryStandards: standards,
		progress,
		attachments: attachmentQuery.data ?? NO_ATTACHMENTS,
		generatedAt,
		evidenceLayout,
		cover: {
			...cover,
			title: cover.title.trim() || "ملف الإنجاز الوظيفي"
		}
	}), [
		profile,
		portfolioStandards,
		standards,
		progress,
		attachmentQuery.data,
		generatedAt,
		evidenceLayout,
		cover
	]);
	async function exportPortfolio() {
		setExporting(true);
		setExportError("");
		try {
			setExportProgress("جارٍ تجهيز المرفقات…");
			const refreshed = await attachmentQuery.refetch();
			if (!refreshed.data || refreshed.error) throw new Error("Attachment loading failed.");
			const result = await createPortfolioPdf({
				...previewInput,
				attachments: refreshed.data,
				onPageProgress: (completed, total) => {
					setExportProgress(`جارٍ تجهيز الصفحات ${completed} من ${total}`);
				}
			});
			downloadBlob(new Blob([result.bytes.slice().buffer], { type: "application/pdf" }), "ملف-الإنجاز-إنجازي.pdf");
			if (result.warnings.length) {
				const affectedStandards = result.warnings.map((warning) => warning.standardTitle).join("، ");
				toast.warning(`تم تنزيل الملف، لكن تعذر تضمين ${result.warnings.length} مرفق. أُدرج تقرير واضح داخل PDF.`, { description: affectedStandards });
			} else toast.success("تم تنزيل ملف الإنجاز بجميع مرفقاته.");
		} catch {
			setExportError("تعذر إنشاء ملف الإنجاز. تحقق من اتصالك ثم أعد المحاولة.");
			toast.error("تعذر إنشاء ملف الإنجاز. لم يتم تغيير أي بيانات.");
		} finally {
			setExporting(false);
			setExportProgress("");
		}
	}
	const info = [
		["المسمى الوظيفي", profile?.job_title],
		["التخصص", profile?.subject],
		["المرحلة", profile?.stage],
		["المدرسة", profile?.school],
		["إدارة التعليم", profile?.education_office],
		["العام الدراسي", profile?.academic_year],
		["سنوات الخبرة", profile?.years_experience != null ? String(profile.years_experience) : null]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-7 animate-rise",
		dir: "rtl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-5 rounded-3xl border border-border bg-card p-5 shadow-soft sm:flex-row sm:items-center sm:justify-between sm:p-6 print:hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-wide text-primary",
					children: "مساحة إعداد وتصدير"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-2xl font-bold text-primary-deep",
					children: "ملف الإنجاز"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "نزّل ملفًا يجمع المعايير والصور وكل صفحات ملفات PDF المرتبطة بها."
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4 sm:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							id: "show-empty",
							checked: showEmpty,
							onCheckedChange: setShowEmpty
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "show-empty",
							className: "text-sm",
							children: "إظهار المعايير بلا شواهد"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "hero",
						onClick: exportPortfolio,
						disabled: exporting || preferencesLoaded !== preferenceKey,
						"aria-live": "polite",
						children: [exporting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), exporting ? exportProgress || "جارٍ تجهيز PDF…" : "تنزيل ملف PDF"]
					})]
				}), exportError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "alert",
					className: "max-w-sm text-sm text-destructive",
					children: exportError
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-[210mm] space-y-6 print:max-w-none print:space-y-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidenceLayoutControls, {
					preferences: evidenceLayout,
					onChange: setEvidenceLayout,
					standards: portfolioStandards,
					disabled: exporting || preferencesLoaded !== preferenceKey
				}),
				preferenceWarning && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "status",
					className: "text-sm text-muted-foreground",
					children: preferenceWarning
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortfolioA4Preview, {
					input: previewInput,
					loading: attachmentQuery.isPending || preferencesLoaded !== preferenceKey,
					loadError: attachmentQuery.isError
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-3xl border border-border bg-card p-5 shadow-soft sm:p-6 print:hidden",
					"aria-labelledby": "cover-designer-title",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold text-primary",
								children: "قبل التصدير"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: "cover-designer-title",
								className: "mt-1 text-lg font-bold text-primary-deep",
								children: "تصميم الغلاف"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: "اختر تنسيقًا ولونًا، وستظهر النتيجة مباشرة في معاينة الغلاف."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-5 md:grid-cols-[1fr_1fr_1.2fr]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
								className: "mb-2 text-sm font-semibold",
								children: "التنسيق"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2",
								role: "group",
								"aria-label": "تنسيق الغلاف",
								children: [["royal", "ملكي"], ["classic", "كلاسيكي"]].map(([value, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": cover.layout === value,
									onClick: () => setCover((current) => ({
										...current,
										layout: value
									})),
									className: `rounded-xl border px-4 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ${cover.layout === value ? "border-primary bg-primary-soft text-primary-deep" : "border-border bg-background text-foreground hover:border-primary/50"}`,
									children: label
								}, value))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
								className: "mb-2 text-sm font-semibold",
								children: "اللون المميّز"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2",
								role: "group",
								"aria-label": "لون الغلاف",
								children: [["gold", "ذهبي"], ["emerald", "زمردي"]].map(([value, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"aria-pressed": cover.accent === value,
									onClick: () => setCover((current) => ({
										...current,
										accent: value
									})),
									className: `inline-flex items-center gap-2 rounded-xl border px-4 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ${cover.accent === value ? "border-primary bg-primary-soft text-primary-deep" : "border-border bg-background text-foreground hover:border-primary/50"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `size-3 rounded-full border border-foreground/10 ${value === "gold" ? "bg-[#C5A15B]" : "bg-[#07594F]"}`,
										"aria-hidden": "true"
									}), label]
								}, value))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "cover-title",
								className: "mb-2 block text-sm font-semibold",
								children: "عنوان الغلاف"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "cover-title",
								value: cover.title,
								onChange: (event) => setCover((current) => ({
									...current,
									title: event.target.value
								})),
								maxLength: 80,
								className: "h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none transition focus-visible:ring-2 focus-visible:ring-ring",
								dir: "auto"
							})] })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					"aria-label": "معاينة غلاف ملف الإنجاز",
					className: `relative mx-auto aspect-[210/297] w-full overflow-hidden border bg-card p-5 shadow-soft sm:p-10 print:min-h-[265mm] print:aspect-auto print:rounded-none print:border-0 print:shadow-none ${cover.layout === "royal" ? "rounded-[1.75rem]" : "rounded-lg"}`,
					style: { borderColor: cover.accent === "gold" ? "#C5A15B" : "#07594F" },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-0 opacity-40",
							"aria-hidden": "true",
							children: cover.layout === "royal" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pattern-dots h-full w-full" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-x-0 top-0 h-2",
							"aria-hidden": "true",
							style: { backgroundColor: cover.accent === "gold" ? "#C5A15B" : "#07594F" }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative flex h-full flex-col",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "size-11" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-lg font-bold text-primary-deep",
										children: "إنجازي"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `my-auto py-6 sm:py-12 ${cover.layout === "classic" ? "text-center" : ""}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-medium text-primary",
											children: "المملكة العربية السعودية"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "mt-3 font-display text-3xl font-bold leading-tight text-primary-deep sm:text-4xl",
											children: cover.title.trim() || "ملف الإنجاز الوظيفي"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `mt-4 h-1 w-24 rounded-full ${cover.layout === "classic" ? "mx-auto" : ""}`,
											style: { backgroundColor: cover.accent === "gold" ? "#C5A15B" : "#07594F" }
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-8 text-xl font-semibold sm:text-2xl",
											children: profile?.full_name || "—"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
									className: "grid grid-cols-2 gap-x-4 gap-y-3 text-xs sm:gap-x-6 sm:text-sm",
									children: info.filter(([, v]) => v).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "border-b border-border pb-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-xs text-muted-foreground",
											children: k
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "mt-0.5 font-medium",
											children: v
										})]
									}, k))
								}),
								profile?.bio && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-6 text-sm leading-loose text-muted-foreground",
									children: profile.bio
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-8 text-xs text-muted-foreground",
									children: [
										"تاريخ الإصدار: ",
										hijri,
										" — الموافق ",
										greg
									]
								}),
								hasPlaceholders && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 rounded-xl border border-warning/40 bg-warning-soft p-3 text-xs text-warning-foreground",
									children: "تنبيه: المعايير الواردة في هذا الملف تجريبية، وستُستبدل بالمعايير الرسمية المعتمدة."
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "print-break rounded-3xl border border-border bg-card p-6 shadow-soft print:rounded-none print:border-0 print:p-0 print:shadow-none",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-bold text-primary-deep",
							children: "ملخص الإنجاز"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: [
								"الإنجاز الموزون حسب الحالة اليدوية: ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
									className: "text-foreground",
									children: [summary.weightedPercent, "٪"]
								}),
								"— المعايير التي حدّدت اكتمالها: ",
								summary.completed,
								" من ",
								summary.total,
								" — تغطية الشواهد:",
								" ",
								evidenceCoverage.documented,
								" من ",
								evidenceCoverage.total,
								" معيار (",
								evidenceCoverage.percent,
								"٪)"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 overflow-x-auto",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full border-collapse text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "bg-primary-soft text-accent-foreground",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "border border-border p-2 text-start",
											children: "#"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "border border-border p-2 text-start",
											children: "المعيار"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "border border-border p-2 text-start",
											children: "الوزن"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "border border-border p-2 text-start",
											children: "الحالة اليدوية"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "border border-border p-2 text-start",
											children: "الشواهد"
										})
									]
								}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: standards.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "print-avoid",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "border border-border p-2",
											children: s.code
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "border border-border p-2",
											children: s.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "border border-border p-2",
											children: [Number(s.weight), "٪"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "border border-border p-2",
											children: STATUS_LABELS[statusFor(s.id, progress)]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "border border-border p-2",
											children: evidences.filter((e) => e.standard_id === s.id).length
										})
									]
								}, s.id)) })]
							})
						})
					]
				}),
				visible.map((s) => {
					const items = evidences.filter((e) => e.standard_id === s.id);
					const notes = progress.find((p) => p.standard_id === s.id)?.notes;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "print-break rounded-3xl border border-border bg-card p-6 shadow-soft print:rounded-none print:border-0 print:p-0 print:shadow-none",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-3 border-b-2 border-primary pb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold text-primary",
									children: [
										s.code,
										" · الوزن ",
										Number(s.weight),
										"٪",
										s.is_placeholder ? " · معيار تجريبي" : ""
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-1 text-lg font-bold text-primary-deep",
									children: s.title
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 rounded-full bg-primary-soft px-3 py-1 text-xs font-medium text-accent-foreground",
									children: STATUS_LABELS[statusFor(s.id, progress)]
								})]
							}),
							s.indicators.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-3 list-disc space-y-1 ps-5 text-sm text-muted-foreground",
								children: s.indicators.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: i }, i))
							}),
							notes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 rounded-xl bg-secondary p-3 text-sm leading-relaxed",
								children: notes
							}),
							items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-6 text-sm text-muted-foreground",
								children: "لا توجد شواهد مرفقة لهذا المعيار."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 print:grid-cols-2",
								children: items.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
									className: "print-avoid overflow-hidden rounded-2xl border border-border",
									children: [isImage(e.mime_type) ? urls?.[e.file_path] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: urls[e.file_path],
										alt: e.title,
										className: "max-h-72 w-full bg-secondary object-contain"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid h-40 place-items-center bg-secondary text-xs text-muted-foreground",
										children: "جارٍ تحميل الصورة…"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3 bg-secondary p-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {
											className: "size-8 text-primary",
											"aria-hidden": "true"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground",
												children: "مرفق PDF"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "truncate text-sm font-medium",
												children: e.title
											})]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
										className: "p-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-semibold",
											children: e.title
										}), e.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-xs leading-relaxed text-muted-foreground",
											children: e.description
										})]
									})]
								}, e.id))
							})
						]
					}, s.id);
				})
			]
		})]
	});
}
//#endregion
export { Portfolio as component };
