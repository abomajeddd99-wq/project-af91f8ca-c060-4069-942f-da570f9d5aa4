import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D6YTns3_.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime, a as Overlay2, c as Title2, d as DialogClose, f as DialogContent$1, g as DialogTitle$1, h as DialogPortal$1, i as Description2, l as Trigger2, m as DialogOverlay$1, n as Cancel, o as Portal2, p as DialogDescription$1, r as Content2, s as Root2, t as Action, u as Dialog$1 } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as useQueryClient, n as useSuspenseQuery, r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as progressQuery, n as evidencesQuery, o as signedUrlQuery, s as standardsQuery, t as allStandardsQuery } from "./queries-DI_WVmjo.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { n as buttonVariants, t as Button } from "./button-B4IWnrg7.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { C as Eye, E as CloudUpload, M as CalendarDays, P as ArrowRight, b as FileText, c as Pencil, i as Trash2, j as Check, o as RefreshCw, p as LoaderCircle, t as X, v as Image, w as ExternalLink } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as statusFor, n as STATUS_ORDER, t as STATUS_LABELS } from "./progress-e08EdBAa.mjs";
import { t as PlaceholderBadge } from "./StatusBadge-C7e1k-7U.mjs";
import { a as formatBytes, c as isPdf, d as titleFromFileName, f as todayISO, l as normalizeEvidenceFields, n as MAX_DESCRIPTION_LENGTH, o as formatEvidenceDate, p as validateEvidenceFile, r as buildEvidencePath, s as isImage, t as EVIDENCE_ACCEPT, u as splitEvidenceFiles } from "./evidence-files-BLvMoTwE.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { t as Route } from "./standards._standardId-B3mg8JYq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/standards._standardId-CynL3zC-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EVIDENCE_OPERATION_MESSAGES = {
	upload: "تعذر رفع الملف.",
	save: "تعذر حفظ بيانات الشاهد.",
	save_cleanup: "تعذر حفظ بيانات الشاهد وتعذر حذف نسخة الرفع المؤقتة. يرجى مراجعة الدعم.",
	replace_upload: "تعذر رفع الملف البديل.",
	replace_upload_cleanup: "تعذر رفع الملف البديل وتنظيف النسخة المؤقتة. بقي الملف الأصلي دون تغيير.",
	replace_save: "تعذر حفظ التعديلات. بقي الملف الأصلي دون تغيير.",
	replace_save_cleanup: "تعذر حفظ التعديلات وتعذر تنظيف الملف البديل. يرجى مراجعة الدعم.",
	delete_backup: "تعذر تأمين نسخة احتياطية للملف؛ لم يتم حذف الشاهد.",
	delete_storage: "تعذر حذف الملف؛ بقي الشاهد دون تغيير.",
	delete_record_restored: "تعذر حذف سجل الشاهد؛ تمت استعادة الملف الأصلي.",
	delete_record_restore_failed: "تعذر حذف سجل الشاهد واستعادة الملف. لا تكرر العملية وراجع الدعم."
};
var EvidenceOperationError = class extends Error {
	stage;
	constructor(stage) {
		super(EVIDENCE_OPERATION_MESSAGES[stage]);
		this.stage = stage;
		this.name = "EvidenceOperationError";
	}
};
async function capture(action) {
	try {
		return await action();
	} catch (error) {
		return { error };
	}
}
async function saveEvidenceWithFile(actions) {
	if ((await capture(actions.upload)).error) throw new EvidenceOperationError("upload");
	if (!(await capture(actions.save)).error) return;
	throw new EvidenceOperationError((await capture(actions.removeNewFile)).error ? "save_cleanup" : "save");
}
async function replaceEvidenceFileSafely(actions) {
	if ((await capture(actions.uploadNewFile)).error) throw new EvidenceOperationError((await capture(actions.removeNewFile)).error ? "replace_upload_cleanup" : "replace_upload");
	if ((await capture(actions.saveChanges)).error) throw new EvidenceOperationError((await capture(actions.removeNewFile)).error ? "replace_save_cleanup" : "replace_save");
	const cleanup = await capture(actions.removeOldFile);
	return { oldFileCleanupFailed: Boolean(cleanup.error) };
}
async function deleteEvidenceSafely(actions) {
	const backup = await capture(actions.downloadBackup);
	if (backup.error || !backup.data) throw new EvidenceOperationError("delete_backup");
	if ((await capture(actions.removeStoredFile)).error) throw new EvidenceOperationError("delete_storage");
	const deleted = await capture(actions.deleteRecord);
	if (deleted.error || !deleted.data) throw new EvidenceOperationError((await capture(() => actions.restoreStoredFile(backup.data))).error ? "delete_record_restore_failed" : "delete_record_restored");
}
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
var DialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
	...props
});
DialogHeader.displayName = "DialogHeader";
var DialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
DialogFooter.displayName = "DialogFooter";
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold leading-none tracking-tight", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
var AlertDialog = Root2;
var AlertDialogTrigger = Trigger2;
var AlertDialogPortal = Portal2;
var AlertDialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay2, {
	className: cn("fixed inset-0 z-50 bg-black/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
AlertDialogOverlay.displayName = Overlay2.displayName;
var AlertDialogContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props
})] }));
AlertDialogContent.displayName = Content2.displayName;
var AlertDialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
AlertDialogHeader.displayName = "AlertDialogHeader";
var AlertDialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
AlertDialogFooter.displayName = "AlertDialogFooter";
var AlertDialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title2, {
	ref,
	className: cn("text-lg font-semibold", className),
	...props
}));
AlertDialogTitle.displayName = Title2.displayName;
var AlertDialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Description2, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
AlertDialogDescription.displayName = Description2.displayName;
var AlertDialogAction = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
	ref,
	className: cn(buttonVariants(), className),
	...props
}));
AlertDialogAction.displayName = Action.displayName;
var AlertDialogCancel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cancel, {
	ref,
	className: cn(buttonVariants({ variant: "outline" }), "mt-2 sm:mt-0", className),
	...props
}));
AlertDialogCancel.displayName = Cancel.displayName;
var BUCKET = "evidence";
var MAX_PREVIEW_PAGES = 30;
async function uploadOne(userId, standardId, item) {
	const check = validateEvidenceFile(item.file);
	if (!check.ok) throw new Error(check.error);
	const fields = normalizeEvidenceFields(item);
	if (!fields.ok) throw new Error(fields.error);
	const path = buildEvidencePath(userId, check.ext);
	await saveEvidenceWithFile({
		upload: () => supabase.storage.from(BUCKET).upload(path, item.file, {
			contentType: check.mimeType,
			upsert: false
		}),
		save: () => supabase.from("evidences").insert({
			user_id: userId,
			standard_id: standardId,
			...fields.value,
			file_path: path,
			file_name: item.file.name.slice(0, 255),
			mime_type: check.mimeType,
			file_size: item.file.size
		}),
		removeNewFile: () => supabase.storage.from(BUCKET).remove([path])
	});
}
function EvidenceUploader({ userId, standardId }) {
	const queryClient = useQueryClient();
	const inputRef = (0, import_react.useRef)(null);
	const [queue, setQueue] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(null);
	function add(list) {
		if (!list?.length) return;
		const { accepted, rejected } = splitEvidenceFiles(Array.from(list), queue.length);
		rejected.forEach((r) => toast.error(`${r.name}: ${r.error}`));
		const today = todayISO();
		setQueue((q) => [...q, ...accepted.map((file) => ({
			key: crypto.randomUUID(),
			file,
			title: titleFromFileName(file.name),
			description: "",
			date: today
		}))]);
		if (inputRef.current) inputRef.current.value = "";
	}
	function patch(key, change) {
		setQueue((q) => q.map((it) => it.key === key ? {
			...it,
			...change,
			error: void 0
		} : it));
	}
	async function onSubmit(e) {
		e.preventDefault();
		if (!queue.length) return;
		for (const it of queue) {
			const r = normalizeEvidenceFields(it);
			if (!r.ok) {
				toast.error(`${it.file.name}: ${r.error}`);
				return;
			}
		}
		setBusy({
			done: 0,
			total: queue.length
		});
		const failed = [];
		let ok = 0;
		for (const [i, it] of queue.entries()) {
			try {
				await uploadOne(userId, standardId, it);
				ok++;
			} catch (err) {
				failed.push({
					...it,
					error: err.message
				});
			}
			setBusy({
				done: i + 1,
				total: queue.length
			});
		}
		setQueue(failed);
		setBusy(null);
		if (ok) toast.success(ok === 1 ? "تمت إضافة الشاهد." : `تمت إضافة ${ok} شواهد.`);
		if (failed.length) toast.error(`تعذر رفع ${failed.length} من الملفات. راجع القائمة وحاول مرة أخرى.`);
		await queryClient.invalidateQueries({ queryKey: ["evidences"] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "space-y-4 rounded-2xl border border-border bg-card p-4 shadow-soft sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-base font-semibold",
				children: "إضافة شواهد جديدة"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				htmlFor: `file-${standardId}`,
				className: "flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-primary/30 bg-primary-soft/40 px-4 py-6 text-center transition-colors hover:bg-primary-soft/70",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, {
						className: "size-7 text-primary",
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-medium",
						children: "اضغط لاختيار صور أو ملفات PDF (يمكن اختيار أكثر من ملف)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted-foreground",
						children: [
							"JPG، PNG، WEBP، PDF — حتى 10 ميجابايت للملف، و",
							10,
							" ملفات في كل دفعة"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: inputRef,
						id: `file-${standardId}`,
						type: "file",
						multiple: true,
						accept: EVIDENCE_ACCEPT,
						className: "sr-only",
						disabled: busy !== null,
						onChange: (e) => add(e.target.files)
					})
				]
			}),
			queue.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-3",
				"aria-label": "الملفات المختارة",
				children: queue.map((it, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "space-y-3 rounded-xl border border-border bg-background p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								isImage(it.file.type) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, {
									className: "size-4 shrink-0 text-primary",
									"aria-hidden": "true"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {
									className: "size-4 shrink-0 text-primary",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-0 flex-1 truncate text-sm font-medium",
									dir: "auto",
									children: it.file.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted-foreground",
									children: formatBytes(it.file.size)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									size: "icon",
									variant: "ghost",
									className: "size-8",
									disabled: busy !== null,
									"aria-label": `إزالة ${it.file.name}`,
									onClick: () => setQueue((q) => q.filter((x) => x.key !== it.key)),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
								})
							]
						}),
						it.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-destructive",
							children: it.error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-[1fr_11rem]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
									htmlFor: `t-${it.key}`,
									children: ["عنوان الشاهد ", i + 1]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: `t-${it.key}`,
									value: it.title,
									maxLength: 200,
									onChange: (e) => patch(it.key, { title: e.target.value }),
									className: "h-10"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: `d-${it.key}`,
									children: "تاريخ الشاهد"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: `d-${it.key}`,
									type: "date",
									value: it.date,
									onChange: (e) => patch(it.key, { date: e.target.value }),
									className: "h-10"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: `s-${it.key}`,
								children: "وصف مختصر (اختياري)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								id: `s-${it.key}`,
								rows: 2,
								maxLength: 2e3,
								value: it.description,
								onChange: (e) => patch(it.key, { description: e.target.value })
							})]
						})
					]
				}, it.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "submit",
				className: "w-full sm:w-auto",
				disabled: busy !== null || queue.length === 0,
				children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, {}), busy ? `جارٍ الرفع ${busy.done} من ${busy.total}` : queue.length > 1 ? `رفع ${queue.length} شواهد` : "رفع الشاهد"]
			})
		]
	});
}
var pdfThumbQuery = (path) => ({
	queryKey: ["pdf-thumb", path],
	queryFn: async () => {
		const { data, error } = await supabase.storage.from(BUCKET).download(path);
		if (error) throw error;
		const { openPdf, renderPdfPage } = await import("./pdf-render-aD6tPodn.mjs");
		const doc = await openPdf(await data.arrayBuffer());
		try {
			return (await renderPdfPage(doc, 1, 480)).dataUrl;
		} finally {
			await doc.destroy();
		}
	},
	staleTime: Infinity,
	retry: 1
});
function EvidenceThumb({ evidence, className }) {
	const image = isImage(evidence.mime_type);
	const pdf = isPdf(evidence.mime_type);
	const { data: url } = useQuery({
		...signedUrlQuery(evidence.file_path),
		enabled: image
	});
	const { data: pdfThumb } = useQuery({
		...pdfThumbQuery(evidence.file_path),
		enabled: pdf
	});
	const src = image ? url : pdfThumb;
	if (src) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt: evidence.title,
		className: `bg-secondary ${className ?? ""}`,
		loading: "lazy"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `grid place-items-center bg-secondary text-primary ${className ?? ""}`,
		children: image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, {
			className: "size-8",
			"aria-hidden": "true"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {
			className: "size-8",
			"aria-hidden": "true"
		})
	});
}
function PdfPages({ path, title }) {
	const [pages, setPages] = (0, import_react.useState)([]);
	const [total, setTotal] = (0, import_react.useState)(null);
	const [failed, setFailed] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		let destroy = null;
		(async () => {
			try {
				const { data, error } = await supabase.storage.from(BUCKET).download(path);
				if (error) throw error;
				const { openPdf, renderPdfPage } = await import("./pdf-render-aD6tPodn.mjs");
				const doc = await openPdf(await data.arrayBuffer());
				destroy = () => doc.destroy();
				if (cancelled) return;
				setTotal(doc.numPages);
				const width = Math.min(1400, Math.round(Math.min(window.innerWidth, 900) * (window.devicePixelRatio || 1)));
				for (let p = 1; p <= Math.min(doc.numPages, MAX_PREVIEW_PAGES); p++) {
					const img = await renderPdfPage(doc, p, width);
					if (cancelled) return;
					setPages((prev) => [...prev, img.dataUrl]);
				}
			} catch (e) {
				console.error(e);
				if (!cancelled) setFailed(true);
			} finally {
				if (destroy) await destroy().catch(() => {});
			}
		})();
		return () => {
			cancelled = true;
		};
	}, [path]);
	if (failed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-8 text-center text-sm text-destructive",
		children: "تعذر عرض ملف PDF."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			pages.map((src, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
				className: "space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src,
					alt: `${title} — صفحة ${i + 1}`,
					className: "w-full rounded-lg border border-border bg-background"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
					className: "text-center text-xs text-muted-foreground",
					children: [
						"صفحة ",
						i + 1,
						" من ",
						total
					]
				})]
			}, i)),
			(total === null || pages.length < Math.min(total, MAX_PREVIEW_PAGES)) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-center gap-2 py-8 text-sm text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), " جارٍ تجهيز الصفحات…"]
			}),
			total !== null && total > MAX_PREVIEW_PAGES && pages.length === MAX_PREVIEW_PAGES && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-center text-xs text-muted-foreground",
				children: [
					"تُعرض أول ",
					MAX_PREVIEW_PAGES,
					" صفحة فقط. افتح الملف الأصلي لعرض الباقي."
				]
			})
		]
	});
}
function EvidencePreview({ evidence, onClose }) {
	const queryClient = useQueryClient();
	const image = isImage(evidence.mime_type);
	const { data: url, isError } = useQuery({
		...signedUrlQuery(evidence.file_path),
		enabled: image
	});
	async function openOriginal() {
		const win = window.open("", "_blank");
		try {
			const signed = await queryClient.fetchQuery(signedUrlQuery(evidence.file_path));
			if (win) win.location.href = signed;
			else window.location.href = signed;
		} catch {
			win?.close();
			toast.error("تعذر فتح الملف.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			dir: "rtl",
			className: "max-h-[92vh] max-w-3xl overflow-y-auto p-4 sm:p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "leading-relaxed",
						children: evidence.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
						formatEvidenceDate(evidence.evidence_date ?? evidence.created_at),
						" · ",
						formatBytes(evidence.file_size)
					] })]
				}),
				evidence.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "whitespace-pre-line text-sm leading-relaxed text-muted-foreground",
					children: evidence.description
				}),
				image ? url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: url,
					alt: evidence.title,
					className: "mx-auto max-h-[70vh] w-auto rounded-lg border border-border"
				}) : isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-8 text-center text-sm text-destructive",
					children: "تعذر عرض الصورة."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-center py-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin text-muted-foreground" })
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PdfPages, {
					path: evidence.file_path,
					title: evidence.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "outline",
					onClick: openOriginal,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, {}), " فتح الملف الأصلي"]
				}) })
			]
		})
	});
}
function EvidenceEditor({ evidence, standards, currentStandard, onClose }) {
	const queryClient = useQueryClient();
	const fileRef = (0, import_react.useRef)(null);
	const [title, setTitle] = (0, import_react.useState)(evidence.title);
	const [description, setDescription] = (0, import_react.useState)(evidence.description ?? "");
	const [date, setDate] = (0, import_react.useState)(evidence.evidence_date ?? evidence.created_at.slice(0, 10));
	const [standardId, setStandardId] = (0, import_react.useState)(evidence.standard_id);
	const [replacement, setReplacement] = (0, import_react.useState)(null);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const standardOptions = standards.some((standard) => standard.id === currentStandard.id) ? standards : [currentStandard, ...standards];
	function pick(f) {
		if (!f) return;
		const check = validateEvidenceFile(f);
		if (!check.ok) {
			toast.error(check.error);
			if (fileRef.current) fileRef.current.value = "";
			return;
		}
		setReplacement(f);
	}
	async function onSubmit(e) {
		e.preventDefault();
		const fields = normalizeEvidenceFields({
			title,
			description,
			date
		});
		if (!fields.ok) {
			toast.error(fields.error);
			return;
		}
		setSaving(true);
		try {
			if (replacement) {
				const check = validateEvidenceFile(replacement);
				if (!check.ok) throw new Error(check.error);
				const newPath = buildEvidencePath(evidence.user_id, check.ext);
				const fileFields = {
					file_path: newPath,
					file_name: replacement.name.slice(0, 255),
					mime_type: check.mimeType,
					file_size: replacement.size
				};
				const result = await replaceEvidenceFileSafely({
					uploadNewFile: () => supabase.storage.from(BUCKET).upload(newPath, replacement, {
						contentType: check.mimeType,
						upsert: false
					}),
					saveChanges: async () => {
						const { data, error } = await supabase.from("evidences").update({
							...fields.value,
							standard_id: standardId,
							...fileFields
						}).eq("id", evidence.id).eq("user_id", evidence.user_id).select("id").maybeSingle();
						return {
							data,
							error: error ?? (data ? null : /* @__PURE__ */ new Error("Evidence row was not updated"))
						};
					},
					removeNewFile: () => supabase.storage.from(BUCKET).remove([newPath]),
					removeOldFile: () => supabase.storage.from(BUCKET).remove([evidence.file_path])
				});
				queryClient.removeQueries({ queryKey: ["signed-url", evidence.file_path] });
				queryClient.removeQueries({ queryKey: ["pdf-thumb", evidence.file_path] });
				if (result.oldFileCleanupFailed) toast.warning("تم حفظ التعديل والملف الجديد، لكن تعذر تنظيف النسخة السابقة.");
				else toast.success("تم استبدال الملف وحفظ التعديلات.");
			} else {
				const { data, error } = await supabase.from("evidences").update({
					...fields.value,
					standard_id: standardId
				}).eq("id", evidence.id).eq("user_id", evidence.user_id).select("id").maybeSingle();
				if (error || !data) throw new Error("تعذر حفظ التعديلات.");
				toast.success("تم حفظ التعديلات.");
			}
			await queryClient.invalidateQueries({ queryKey: ["evidences"] });
			onClose();
		} catch (err) {
			toast.error(err.message);
		} finally {
			setSaving(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && !saving && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			dir: "rtl",
			className: "max-h-[92vh] max-w-lg overflow-y-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
				className: "text-right",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "تعديل الشاهد" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "عدّل البيانات أو استبدل الملف المرفق." })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "edit-title",
							children: "عنوان الشاهد"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "edit-title",
							value: title,
							maxLength: 200,
							onChange: (e) => setTitle(e.target.value),
							className: "h-10"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "edit-date",
							children: "تاريخ الشاهد"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "edit-date",
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value),
							className: "h-10"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "edit-standard",
							children: "المعيار المرتبط بالشاهد"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: "edit-standard",
							value: standardId,
							onChange: (event) => setStandardId(event.target.value),
							className: "h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm",
							children: standardOptions.map((standard) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: standard.id,
								children: [
									standard.code,
									" · ",
									standard.title
								]
							}, standard.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "edit-desc",
							children: "وصف مختصر (اختياري)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "edit-desc",
							rows: 3,
							maxLength: MAX_DESCRIPTION_LENGTH,
							value: description,
							onChange: (e) => setDescription(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 rounded-xl border border-border bg-background p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: "الملف المرفق"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-xs text-muted-foreground",
								dir: "auto",
								children: replacement ? `الملف الجديد: ${replacement.name} (${formatBytes(replacement.size)})` : evidence.file_name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2 pt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									size: "sm",
									variant: "soft",
									onClick: () => fileRef.current?.click(),
									disabled: saving,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {}), " استبدال الملف"]
								}), replacement && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									size: "sm",
									variant: "ghost",
									disabled: saving,
									onClick: () => {
										setReplacement(null);
										if (fileRef.current) fileRef.current.value = "";
									},
									children: "تراجع عن الاستبدال"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: fileRef,
								type: "file",
								accept: EVIDENCE_ACCEPT,
								className: "sr-only",
								"aria-label": "اختيار ملف بديل",
								onChange: (e) => pick(e.target.files?.[0])
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "submit",
							disabled: saving,
							children: [saving && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }), "حفظ"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							onClick: onClose,
							disabled: saving,
							children: "إلغاء"
						})]
					})
				]
			})]
		})
	});
}
function EvidenceCard({ evidence, standards, currentStandard }) {
	const queryClient = useQueryClient();
	const [mode, setMode] = (0, import_react.useState)(null);
	const [deleting, setDeleting] = (0, import_react.useState)(false);
	async function remove() {
		setDeleting(true);
		try {
			await deleteEvidenceSafely({
				downloadBackup: async () => {
					const { data, error } = await supabase.storage.from(BUCKET).download(evidence.file_path);
					return {
						data,
						error
					};
				},
				removeStoredFile: () => supabase.storage.from(BUCKET).remove([evidence.file_path]),
				deleteRecord: async () => {
					const { data, error } = await supabase.from("evidences").delete().eq("id", evidence.id).eq("user_id", evidence.user_id).select("id").maybeSingle();
					return {
						data,
						error: error ?? (data ? null : /* @__PURE__ */ new Error("Evidence row was not deleted"))
					};
				},
				restoreStoredFile: (backup) => supabase.storage.from(BUCKET).upload(evidence.file_path, backup, {
					contentType: evidence.mime_type,
					upsert: true
				})
			});
			queryClient.removeQueries({ queryKey: ["signed-url", evidence.file_path] });
			queryClient.removeQueries({ queryKey: ["pdf-thumb", evidence.file_path] });
			toast.success("تم حذف الشاهد وملفه.");
			await queryClient.invalidateQueries({ queryKey: ["evidences"] });
		} catch (err) {
			toast.error(err.message);
		} finally {
			setDeleting(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "overflow-hidden rounded-2xl border border-border bg-card shadow-soft",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "block w-full",
				onClick: () => setMode("preview"),
				"aria-label": `معاينة ${evidence.title}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidenceThumb, {
					evidence,
					className: "aspect-[4/3] w-full object-cover object-top"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "line-clamp-2 font-semibold",
						children: evidence.title
					}),
					evidence.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "line-clamp-3 text-sm leading-relaxed text-muted-foreground",
						children: evidence.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-1 text-xs text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, {
								className: "size-3.5",
								"aria-hidden": "true"
							}),
							formatEvidenceDate(evidence.evidence_date ?? evidence.created_at),
							" ·",
							" ",
							isPdf(evidence.mime_type) ? "PDF" : "صورة",
							" · ",
							formatBytes(evidence.file_size)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-1.5 pt-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "soft",
								onClick: () => setMode("preview"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, {}), " معاينة"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: () => setMode("edit"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {}), " تعديل"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialog, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTrigger, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "ghost",
									disabled: deleting,
									"aria-label": "حذف الشاهد",
									children: [deleting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), "حذف"]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, {
								dir: "rtl",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "حذف الشاهد؟" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: "سيتم حذف الشاهد وملفه نهائيًا ولا يمكن التراجع." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, {
									className: "gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "إلغاء" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
										onClick: remove,
										children: "حذف"
									})]
								})]
							})] })
						]
					})
				]
			}),
			mode === "preview" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidencePreview, {
				evidence,
				onClose: () => setMode(null)
			}),
			mode === "edit" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidenceEditor, {
				evidence,
				standards,
				currentStandard,
				onClose: () => setMode(null)
			})
		]
	});
}
function StandardDetail() {
	const { standardId } = Route.useParams();
	const { user } = Route.useRouteContext();
	const queryClient = useQueryClient();
	const { data: standards } = useSuspenseQuery(standardsQuery());
	const { data: progress } = useSuspenseQuery(progressQuery());
	const { data: evidences } = useSuspenseQuery(evidencesQuery());
	const { data: historical } = useSuspenseQuery(allStandardsQuery());
	const standard = historical.find((s) => s.id === standardId);
	const canAdd = standards.some((s) => s.id === standardId);
	const status = statusFor(standardId, progress);
	const savedNotes = progress.find((p) => p.standard_id === standardId)?.notes ?? "";
	const [notes, setNotes] = (0, import_react.useState)(savedNotes);
	const [saving, setSaving] = (0, import_react.useState)(null);
	const mine = evidences.filter((e) => e.standard_id === standardId);
	(0, import_react.useEffect)(() => setNotes(savedNotes), [savedNotes]);
	if (!standard) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "المعيار غير موجود." });
	async function save(next, key) {
		setSaving(key);
		try {
			const { error } = await supabase.from("standard_progress").upsert({
				user_id: user.id,
				standard_id: standardId,
				status: next.status ?? status,
				notes: next.notes !== void 0 ? next.notes.trim() || null : savedNotes || null
			}, { onConflict: "user_id,standard_id" });
			if (error) throw error;
			toast.success("تم الحفظ.");
			await queryClient.invalidateQueries({ queryKey: ["progress"] });
		} catch {
			toast.error("تعذر الحفظ.");
		} finally {
			setSaving(null);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 animate-rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/standards",
				className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
					className: "size-4",
					"aria-hidden": "true"
				}), " المعايير"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "rounded-3xl border border-border bg-card p-5 shadow-soft sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-lg bg-secondary px-2 py-0.5 font-display text-xs font-semibold",
								children: standard.code
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground",
								children: [
									"الوزن ",
									Number(standard.weight),
									"٪"
								]
							}),
							standard.is_placeholder && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlaceholderBadge, {}),
							!standard.is_placeholder && standard.owner_id === null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-success",
								children: "معيار رسمي معتمد"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 text-xl font-bold leading-relaxed text-primary-deep sm:text-2xl",
						children: standard.title
					}),
					standard.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted-foreground",
						children: standard.description
					}),
					standard.indicators.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-semibold",
							children: "المؤشرات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 space-y-1.5",
							children: standard.indicators.map((ind) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-2 text-sm leading-relaxed",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
									className: "mt-0.5 size-4 shrink-0 text-primary",
									"aria-hidden": "true"
								}), ind]
							}, ind))
						})]
					})
				]
			}),
			canAdd && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-border bg-card p-5 shadow-soft sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-semibold",
						children: "حالة الإنجاز"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: "حالة تختارها بنفسك، ولا تتغير تلقائيًا عند إضافة الشواهد أو حذفها."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid grid-cols-3 gap-2",
						role: "radiogroup",
						"aria-label": "حالة الإنجاز",
						children: STATUS_ORDER.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							role: "radio",
							"aria-checked": status === s,
							disabled: saving !== null,
							onClick: () => s !== status && save({ status: s }, s),
							className: cn("flex items-center justify-center gap-1.5 rounded-xl border px-2 py-2.5 text-sm transition-colors", status === s ? s === "completed" ? "border-success bg-success-soft font-semibold text-success" : s === "in_progress" ? "border-warning bg-warning-soft font-semibold text-warning-foreground" : "border-primary bg-primary-soft font-semibold text-accent-foreground" : "border-border text-muted-foreground hover:bg-muted"),
							children: [saving === s && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }), STATUS_LABELS[s]]
						}, s))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "notes",
								className: "text-sm font-medium",
								children: "ملاحظاتي على المعيار"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								id: "notes",
								rows: 3,
								maxLength: 2e3,
								value: notes,
								onChange: (e) => setNotes(e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "soft",
								disabled: saving !== null || notes === savedNotes,
								onClick: () => save({ notes }, "notes"),
								children: [saving === "notes" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }), "حفظ الملاحظات"]
							})
						]
					})
				]
			}),
			canAdd && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidenceUploader, {
				userId: user.id,
				standardId
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "mb-3 text-base font-semibold",
				children: [
					"الشواهد المرفقة (",
					mine.length,
					")"
				]
			}), mine.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-2xl border border-dashed border-border p-6 text-center text-sm text-muted-foreground",
				children: "لم تضف أي شاهد لهذا المعيار بعد."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
				children: mine.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidenceCard, {
					evidence: e,
					standards,
					currentStandard: standard
				}, e.id))
			})] })
		]
	});
}
//#endregion
export { StandardDetail as component };
