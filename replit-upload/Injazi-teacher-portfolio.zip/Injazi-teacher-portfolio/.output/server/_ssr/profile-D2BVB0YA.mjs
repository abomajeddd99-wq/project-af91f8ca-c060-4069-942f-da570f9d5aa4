import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D6YTns3_.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as useQueryClient, n as useSuspenseQuery } from "../_libs/tanstack__react-query.mjs";
import { i as profileQuery } from "./queries-DI_WVmjo.mjs";
import { t as Button } from "./button-B4IWnrg7.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { p as LoaderCircle } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Route } from "./profile-3V_MAwfE.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-D2BVB0YA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var fields = [
	{
		key: "full_name",
		label: "الاسم الكامل"
	},
	{
		key: "job_title",
		label: "المسمى الوظيفي",
		placeholder: "معلم / معلمة"
	},
	{
		key: "subject",
		label: "التخصص / المادة",
		placeholder: "مثال: الرياضيات"
	},
	{
		key: "stage",
		label: "المرحلة الدراسية",
		placeholder: "مثال: المتوسطة"
	},
	{
		key: "school",
		label: "المدرسة"
	},
	{
		key: "education_office",
		label: "إدارة / مكتب التعليم",
		placeholder: "مثال: إدارة تعليم الرياض"
	},
	{
		key: "academic_year",
		label: "العام الدراسي",
		placeholder: "مثال: 1448هـ"
	},
	{
		key: "years_experience",
		label: "سنوات الخبرة",
		type: "number"
	},
	{
		key: "phone",
		label: "رقم الجوال",
		type: "tel",
		dir: "ltr",
		placeholder: "05xxxxxxxx"
	}
];
function ProfilePage() {
	const { user } = Route.useRouteContext();
	const queryClient = useQueryClient();
	const { data: profile } = useSuspenseQuery(profileQuery(user.id));
	const [values, setValues] = (0, import_react.useState)(() => {
		const v = {};
		for (const f of fields) v[f.key] = profile?.[f.key] != null ? String(profile[f.key]) : "";
		v["bio"] = profile?.bio ?? "";
		return v;
	});
	const [saving, setSaving] = (0, import_react.useState)(false);
	const get = (k) => values[k] ?? "";
	async function onSubmit(e) {
		e.preventDefault();
		const years = get("years_experience").trim() === "" ? null : Number(get("years_experience"));
		if (years !== null && (!Number.isInteger(years) || years < 0 || years > 60)) {
			toast.error("سنوات الخبرة يجب أن تكون رقمًا بين 0 و 60.");
			return;
		}
		if (get("full_name").trim().length < 3) {
			toast.error("يرجى كتابة الاسم الكامل.");
			return;
		}
		setSaving(true);
		const clean = (k) => get(k).trim().slice(0, 200) || null;
		const { error } = await supabase.from("profiles").upsert({
			id: user.id,
			email: user.email ?? null,
			full_name: get("full_name").trim().slice(0, 200),
			job_title: clean("job_title"),
			subject: clean("subject"),
			stage: clean("stage"),
			school: clean("school"),
			education_office: clean("education_office"),
			academic_year: clean("academic_year"),
			years_experience: years,
			phone: clean("phone"),
			bio: get("bio").trim().slice(0, 2e3) || null
		});
		setSaving(false);
		if (error) {
			toast.error("تعذر حفظ البيانات.");
			return;
		}
		toast.success("تم حفظ بياناتك.");
		queryClient.invalidateQueries({ queryKey: ["profile", user.id] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl space-y-5 animate-rise",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold text-primary-deep",
				children: "ملفي الشخصي"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "تظهر هذه البيانات في غلاف ملف الإنجاز المطبوع."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "outline",
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/onboarding",
					children: "اختيار / تغيير المسار الوظيفي"
				})
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "space-y-5 rounded-3xl border border-border bg-card p-5 shadow-soft sm:p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "البريد الإلكتروني" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: user.email ?? "",
						disabled: true,
						dir: "ltr",
						className: "h-11 text-left"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: fields.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: f.key,
							children: f.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: f.key,
							type: f.type ?? "text",
							dir: f.dir,
							inputMode: f.type === "number" ? "numeric" : void 0,
							placeholder: f.placeholder,
							value: get(f.key),
							onChange: (e) => setValues((v) => ({
								...v,
								[f.key]: e.target.value
							})),
							maxLength: 200,
							className: f.dir === "ltr" ? "h-11 text-left" : "h-11"
						})]
					}, f.key))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "bio",
						children: "نبذة مهنية"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						id: "bio",
						rows: 4,
						maxLength: 2e3,
						value: get("bio"),
						onChange: (e) => setValues((v) => ({
							...v,
							bio: e.target.value
						}))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "submit",
					variant: "hero",
					size: "lg",
					className: "w-full sm:w-auto",
					disabled: saving,
					children: [saving && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }), "حفظ البيانات"]
				})
			]
		})]
	});
}
//#endregion
export { ProfilePage as component };
