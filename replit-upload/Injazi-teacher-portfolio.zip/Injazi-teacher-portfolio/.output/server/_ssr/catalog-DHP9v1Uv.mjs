import { t as supabase } from "./client-D6YTns3_.mjs";
import { t as queryOptions } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalog-DHP9v1Uv.js
var careerPathsQuery = () => queryOptions({
	queryKey: ["career-paths"],
	queryFn: async () => {
		const { data, error } = await supabase.from("professional_roles").select("*").order("sort_order");
		if (error) throw error;
		return data;
	}
});
var criteriaVersionsQuery = () => queryOptions({
	queryKey: ["criteria-versions"],
	queryFn: async () => {
		const { data, error } = await supabase.from("criteria_versions").select("*").order("created_at", { ascending: false });
		if (error) throw error;
		return data;
	}
});
var categoriesQuery = () => queryOptions({
	queryKey: ["criteria-categories"],
	queryFn: async () => {
		const { data, error } = await supabase.from("criteria_categories").select("*").order("sort_order");
		if (error) throw error;
		return data;
	}
});
//#endregion
export { categoriesQuery as n, criteriaVersionsQuery as r, careerPathsQuery as t };
