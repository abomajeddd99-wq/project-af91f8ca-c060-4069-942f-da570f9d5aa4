import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useSuspenseQuery, r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as progressQuery, i as profileQuery, n as evidencesQuery, s as standardsQuery } from "./queries-DI_WVmjo.mjs";
import { t as Button } from "./button-B4IWnrg7.mjs";
import { D as Clock, F as ArrowLeft, O as CircleCheck, n as UserRound, s as Printer, x as FileStack } from "../_libs/lucide-react.mjs";
import { t as Route } from "./dashboard-CVKkQgP1.mjs";
import { a as statusFor, i as computeManualProgress, r as computeEvidenceCoverage } from "./progress-e08EdBAa.mjs";
import { n as StatusBadge, t as PlaceholderBadge } from "./StatusBadge-C7e1k-7U.mjs";
import { t as PlaceholderNotice } from "./PlaceholderNotice-29OvyTzi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-267qdHJr.js
var import_jsx_runtime = require_jsx_runtime();
function ProgressRing({ value, size = 132, label }) {
	const stroke = 10;
	const r = (size - stroke) / 2;
	const c = 2 * Math.PI * r;
	const offset = c - Math.min(100, Math.max(0, value)) / 100 * c;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative inline-grid place-items-center",
		style: {
			width: size,
			height: size
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			width: size,
			height: size,
			className: "-rotate-90",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: size / 2,
				cy: size / 2,
				r,
				strokeWidth: stroke,
				fill: "none",
				className: "stroke-primary-soft"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: size / 2,
				cy: size / 2,
				r,
				strokeWidth: stroke,
				fill: "none",
				strokeLinecap: "round",
				strokeDasharray: c,
				strokeDashoffset: offset,
				className: "stroke-primary transition-[stroke-dashoffset] duration-700"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "font-display text-3xl font-bold text-primary-deep",
				children: [value, "٪"]
			}), label && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs text-muted-foreground",
				children: label
			})]
		})]
	});
}
function Dashboard() {
	const { user } = Route.useRouteContext();
	const { data: standards } = useSuspenseQuery(standardsQuery());
	const { data: progress } = useSuspenseQuery(progressQuery());
	const { data: evidences } = useSuspenseQuery(evidencesQuery());
	const { data: profile } = useQuery(profileQuery(user.id));
	const summary = computeManualProgress(standards, progress);
	const evidenceCoverage = computeEvidenceCoverage(standards, evidences);
	const hasPlaceholders = standards.some((s) => s.is_placeholder);
	const profileIncomplete = !profile?.school || !profile?.subject;
	const firstName = (profile?.full_name || "").split(" ")[0];
	const next = standards.filter((s) => statusFor(s.id, progress) !== "completed").slice(0, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 animate-rise",
		dir: "rtl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-3xl border border-border bg-card px-5 py-6 shadow-soft sm:px-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: ["أهلًا", firstName ? `، ${firstName}` : ""]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-2xl font-bold text-primary-deep md:text-3xl",
						children: "ملف إنجازك"
					}),
					profile?.job_title && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: profile.job_title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-2xl border-s-2 border-[#C5A15B] ps-3 text-sm leading-relaxed text-muted-foreground",
						children: "مساحة موثوقة لتنظيم معاييرك المهنية وشواهدك، ومتابعة تقدمك اليدوي."
					})
				]
			}),
			!profile?.onboarding_completed_at && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "outline",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/onboarding",
					children: "استكمال الحساب واختيار المسار الوظيفي"
				})
			}),
			hasPlaceholders && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlaceholderNotice, {}),
			profileIncomplete && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/profile",
				className: "flex items-center gap-3 rounded-2xl border border-primary/25 bg-primary-soft/60 p-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, {
						className: "size-5 text-primary",
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex-1",
						children: "أكمل بياناتك المهنية لتظهر في غلاف ملف الإنجاز."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
						className: "size-4 text-primary",
						"aria-hidden": "true"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 md:grid-cols-[1.2fr_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-start gap-5 rounded-3xl border border-border bg-card p-5 shadow-soft sm:flex-row sm:items-center sm:gap-6 sm:p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressRing, {
						value: summary.weightedPercent,
						label: "إنجاز يدوي"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 space-y-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "المعايير التي حدّدت اكتمالها"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-display text-3xl font-bold",
								children: [summary.completed, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-lg text-muted-foreground",
									children: [" / ", summary.total]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									"تغطية الشواهد: ",
									evidenceCoverage.documented,
									" من ",
									evidenceCoverage.total,
									" معيار (",
									evidenceCoverage.percent,
									"٪)"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "هذه التغطية مستقلة عن الحالة التي تختارها."
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 gap-3 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							icon: FileStack,
							label: "الشواهد",
							value: evidences.length
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							icon: Clock,
							label: "قيد الإنجاز يدويًا",
							value: summary.inProgress
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							icon: CircleCheck,
							label: "مكتمل يدويًا",
							value: summary.completed
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "hero",
					size: "lg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/standards",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileStack, {}), " إضافة شاهد"]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "outline",
					size: "lg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/portfolio",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {}), " طباعة ملف الإنجاز"]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "التالي في قائمتك"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/standards",
					className: "text-sm text-primary hover:underline",
					children: "كل المعايير"
				})]
			}), next.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl border border-border bg-card p-6 text-center text-sm text-muted-foreground",
				children: standards.length === 0 ? "لا توجد معايير بعد." : "أحسنت، أكملت جميع المعايير."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: next.map((s) => {
					const count = evidences.filter((e) => e.standard_id === s.id).length;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/standards/$standardId",
						params: { standardId: s.id },
						className: "flex items-center gap-3 rounded-2xl border border-border bg-card p-4 shadow-soft transition-colors hover:border-primary/40",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-10 shrink-0 place-items-center rounded-xl bg-primary-soft font-display text-sm font-semibold text-accent-foreground",
								children: s.sort_order
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-medium",
									children: s.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: statusFor(s.id, progress) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [count, " شاهد"] }),
										s.is_placeholder && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlaceholderBadge, {})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
								className: "size-4 shrink-0 text-muted-foreground",
								"aria-hidden": "true"
							})
						]
					}) }, s.id);
				})
			})] })
		]
	});
}
function Stat({ icon: Icon, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col justify-between rounded-2xl border border-border bg-card p-4 shadow-soft",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-5 text-primary",
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl font-bold",
				children: value
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: label
			})]
		})]
	});
}
//#endregion
export { Dashboard as component };
