import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as profileQuery } from "./queries-DI_WVmjo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-3V_MAwfE.js
var $$splitComponentImporter = () => import("./profile-D2BVB0YA.mjs");
var Route = createFileRoute("/_authenticated/profile")({
	head: () => ({ meta: [
		{ title: "ملفي الشخصي — إنجازي" },
		{
			name: "description",
			content: "بياناتك المهنية التي تظهر في ملف الإنجاز."
		},
		{
			property: "og:title",
			content: "ملفي الشخصي — إنجازي"
		},
		{
			property: "og:description",
			content: "بياناتك المهنية التي تظهر في ملف الإنجاز."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	loader: ({ context }) => context.queryClient.ensureQueryData(profileQuery(context.user.id)),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
