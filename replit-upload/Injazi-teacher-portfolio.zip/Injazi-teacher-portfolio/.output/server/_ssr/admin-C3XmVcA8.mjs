import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as TSS_SERVER_FUNCTION, l as createServerFn } from "./createServerFn-BhqelEmK.mjs";
import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-GzKCgEqg.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CMevzYJH.mjs";
import { t as queryOptions } from "../_libs/tanstack__react-query.mjs";
import { n as categoriesQuery, r as criteriaVersionsQuery, t as careerPathsQuery } from "./catalog-DHP9v1Uv.mjs";
import { r as isAdminQuery, t as allStandardsQuery } from "./queries-DI_WVmjo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-C3XmVcA8.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getAdminAccounts = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("2bb7aff7342fd60fd4f7943caed2156ded7116efab646ed8df1ba4e005ebe62b"));
var accountsQuery = () => queryOptions({
	queryKey: ["admin-accounts"],
	queryFn: () => getAdminAccounts()
});
var $$splitComponentImporter = () => import("./admin-Dcueyt9Y.mjs");
var Route = createFileRoute("/_authenticated/admin")({
	head: () => ({ meta: [
		{ title: "إدارة المنصة — إنجازي" },
		{
			name: "description",
			content: "إدارة المسارات الوظيفية والمعايير والإصدارات والحسابات الشخصية."
		},
		{
			property: "og:title",
			content: "إدارة المنصة — إنجازي"
		},
		{
			property: "og:description",
			content: "إدارة آمنة منفصلة عن المسارات الوظيفية."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		},
		{
			name: "robots",
			content: "noindex"
		}
	] }),
	loader: async ({ context }) => {
		if (!await context.queryClient.fetchQuery(isAdminQuery())) return { allowed: false };
		await Promise.all([
			context.queryClient.ensureQueryData(accountsQuery()),
			context.queryClient.ensureQueryData(careerPathsQuery()),
			context.queryClient.ensureQueryData(criteriaVersionsQuery()),
			context.queryClient.ensureQueryData(categoriesQuery()),
			context.queryClient.ensureQueryData(allStandardsQuery())
		]);
		return { allowed: true };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { accountsQuery as n, Route as t };
