import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { _ as Info } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/PlaceholderNotice-29OvyTzi.js
var import_jsx_runtime = require_jsx_runtime();
function PlaceholderNotice() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex gap-3 rounded-2xl border border-warning/40 bg-warning-soft p-4 text-sm text-warning-foreground print:hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
			className: "mt-0.5 size-5 shrink-0",
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "leading-relaxed",
			children: [
				"المعايير المعروضة حاليًا ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "تجريبية" }),
				" لأغراض العرض فقط، وسيتم استبدالها بالمعايير الرسمية المعتمدة فور توفرها."
			]
		})]
	});
}
//#endregion
export { PlaceholderNotice as t };
