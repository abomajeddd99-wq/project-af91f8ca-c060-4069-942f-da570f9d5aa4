import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as progressQuery, i as profileQuery, n as evidencesQuery, s as standardsQuery, t as allStandardsQuery } from "./queries-DI_WVmjo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/portfolio-WryRiM5y.js
var $$splitComponentImporter = () => import("./portfolio-DtzK8ePP.mjs");
var Route = createFileRoute("/_authenticated/portfolio")({
	head: () => ({ meta: [
		{ title: "ملف الإنجاز للطباعة — إنجازي" },
		{
			name: "description",
			content: "معاينة ملف الإنجاز وطباعته أو حفظه بصيغة PDF."
		},
		{
			property: "og:title",
			content: "ملف الإنجاز للطباعة — إنجازي"
		},
		{
			property: "og:description",
			content: "معاينة ملف الإنجاز وطباعته أو حفظه بصيغة PDF."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	loader: ({ context }) => Promise.all([
		context.queryClient.ensureQueryData(standardsQuery()),
		context.queryClient.ensureQueryData(allStandardsQuery()),
		context.queryClient.ensureQueryData(progressQuery()),
		context.queryClient.ensureQueryData(evidencesQuery()),
		context.queryClient.ensureQueryData(profileQuery(context.user.id))
	]),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
