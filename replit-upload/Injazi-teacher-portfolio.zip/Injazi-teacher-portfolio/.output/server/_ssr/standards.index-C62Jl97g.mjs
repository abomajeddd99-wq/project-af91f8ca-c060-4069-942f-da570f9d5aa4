import { i as __toESM } from "../_runtime.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useSuspenseQuery } from "../_libs/tanstack__react-query.mjs";
import { a as progressQuery, n as evidencesQuery, s as standardsQuery, t as allStandardsQuery } from "./queries-DI_WVmjo.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { F as ArrowLeft } from "../_libs/lucide-react.mjs";
import { a as statusFor, t as STATUS_LABELS } from "./progress-e08EdBAa.mjs";
import { n as StatusBadge, t as PlaceholderBadge } from "./StatusBadge-C7e1k-7U.mjs";
import { t as PlaceholderNotice } from "./PlaceholderNotice-29OvyTzi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/standards.index-C62Jl97g.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StandardsList() {
	const { data: standards } = useSuspenseQuery(standardsQuery());
	const { data: progress } = useSuspenseQuery(progressQuery());
	const { data: evidences } = useSuspenseQuery(evidencesQuery());
	const { data: historical } = useSuspenseQuery(allStandardsQuery());
	const previous = historical.filter((s) => !standards.some((current) => current.id === s.id) && evidences.some((e) => e.standard_id === s.id));
	const [filter, setFilter] = (0, import_react.useState)("all");
	const rows = standards.filter((s) => filter === "all" || statusFor(s.id, progress) === filter);
	const filters = [
		{
			key: "all",
			label: "الكل"
		},
		{
			key: "not_started",
			label: STATUS_LABELS.not_started
		},
		{
			key: "in_progress",
			label: STATUS_LABELS.in_progress
		},
		{
			key: "completed",
			label: STATUS_LABELS.completed
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5 animate-rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold text-primary-deep",
				children: "معايير الأداء"
			}),
			standards.some((s) => s.is_placeholder) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlaceholderNotice, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "-mx-4 flex gap-2 overflow-x-auto px-4 pb-1",
				role: "tablist",
				children: filters.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					role: "tab",
					"aria-selected": filter === f.key,
					onClick: () => setFilter(f.key),
					className: cn("shrink-0 rounded-full border px-4 py-1.5 text-sm transition-colors", filter === f.key ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-muted-foreground hover:text-foreground"),
					children: f.label
				}, f.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "grid gap-3 md:grid-cols-2",
				children: [rows.map((s) => {
					const count = evidences.filter((e) => e.standard_id === s.id).length;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/standards/$standardId",
						params: { standardId: s.id },
						className: "flex h-full flex-col gap-3 rounded-2xl border border-border bg-card p-5 shadow-soft transition-colors hover:border-primary/40",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-lg bg-secondary px-2 py-0.5 font-display text-xs font-semibold text-secondary-foreground",
									children: s.code
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted-foreground",
									children: [
										"الوزن ",
										Number(s.weight),
										"٪"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-base font-semibold leading-relaxed",
								children: s.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-auto flex flex-wrap items-center gap-2 text-xs text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "حالة يدوية:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: statusFor(s.id, progress) })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [count, " شواهد"] }),
									s.is_placeholder && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlaceholderBadge, {}),
									!s.is_placeholder && s.owner_id === null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-success",
										children: "معيار رسمي معتمد"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
										className: "ms-auto size-4",
										"aria-hidden": "true"
									})
								]
							})
						]
					}) }, s.id);
				}), rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "rounded-2xl border border-border bg-card p-6 text-center text-sm text-muted-foreground md:col-span-2",
					children: "لا توجد معايير في هذا التصنيف."
				})]
			}),
			previous.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-3 text-lg font-semibold",
				children: "معايير شواهدي السابقة"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: previous.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/standards/$standardId",
					params: { standardId: s.id },
					className: "block border-b border-border py-3 text-primary",
					children: s.title
				}) }, s.id))
			})] })
		]
	});
}
//#endregion
export { StandardsList as component };
