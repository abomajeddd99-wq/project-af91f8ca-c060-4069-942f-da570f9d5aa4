import { a as TSS_SERVER_FUNCTION, l as createServerFn } from "./createServerFn-BhqelEmK.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CMevzYJH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.functions-DLBdpm4K.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getAdminAccounts_createServerFn_handler = createServerRpc({
	id: "2bb7aff7342fd60fd4f7943caed2156ded7116efab646ed8df1ba4e005ebe62b",
	name: "getAdminAccounts",
	filename: "src/lib/admin.functions.ts"
}, (opts) => getAdminAccounts.__executeServer(opts));
var getAdminAccounts = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(getAdminAccounts_createServerFn_handler, async ({ context }) => {
	const { data: allowed, error: roleError } = await context.supabase.rpc("is_admin");
	if (roleError || allowed !== true) throw new Error("غير مصرح بالدخول إلى الإدارة");
	const { data, error } = await context.supabase.rpc("admin_list_personal_accounts");
	if (error) throw new Error("تعذر تحميل الحسابات");
	return data;
});
//#endregion
export { getAdminAccounts_createServerFn_handler };
