import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D6YTns3_.mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Button } from "./button-B4IWnrg7.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { p as LoaderCircle, u as MailCheck } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Route } from "./auth-9iMJhyvk.mjs";
import { t as Logo } from "./Logo-B61h93Nc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-CiOoxS0A.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Only allow same-origin relative paths; anything else falls back to the dashboard. */
function sanitizeRedirect(value, fallback = "/dashboard") {
	if (typeof value !== "string") return fallback;
	if (!value.startsWith("/") || value.startsWith("//") || value.startsWith("/\\")) return fallback;
	if (value.startsWith("/auth")) return fallback;
	return value;
}
function translateAuthError(message) {
	const m = message.toLowerCase();
	if (m.includes("invalid login")) return "البريد الإلكتروني أو كلمة المرور غير صحيحة.";
	if (m.includes("email not confirmed")) return "يرجى تأكيد بريدك الإلكتروني أولًا من الرسالة المرسلة إليك.";
	if (m.includes("already registered") || m.includes("already been registered")) return "هذا البريد مسجّل مسبقًا. جرّب تسجيل الدخول.";
	if (m.includes("password") && (m.includes("weak") || m.includes("pwned") || m.includes("known"))) return "كلمة المرور ضعيفة أو مسرّبة سابقًا. اختر كلمة مرور أقوى.";
	if (m.includes("at least")) return "كلمة المرور يجب ألا تقل عن 8 أحرف.";
	if (m.includes("rate limit")) return "محاولات كثيرة. حاول بعد قليل.";
	return "تعذر إتمام العملية. حاول مرة أخرى.";
}
function AuthPage() {
	const search = Route.useSearch();
	const navigate = useNavigate();
	const [mode, setMode] = (0, import_react.useState)(search.mode ?? "login");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [sentTo, setSentTo] = (0, import_react.useState)(null);
	const [fullName, setFullName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const target = sanitizeRedirect(search.redirect);
	(0, import_react.useEffect)(() => {
		if (search.mode) setMode(search.mode);
	}, [search.mode]);
	(0, import_react.useEffect)(() => {
		supabase.auth.getUser().then(({ data }) => {
			if (data.user) navigate({
				to: target,
				replace: true
			});
		});
	}, []);
	async function onSubmit(e) {
		e.preventDefault();
		setLoading(true);
		try {
			if (mode === "login") {
				const { error } = await supabase.auth.signInWithPassword({
					email: email.trim(),
					password
				});
				if (error) throw error;
				toast.success("أهلًا بعودتك!");
				navigate({
					to: target,
					replace: true
				});
			} else if (mode === "signup") {
				if (fullName.trim().length < 3) {
					toast.error("يرجى كتابة الاسم الكامل.");
					return;
				}
				if (password.length < 8) {
					toast.error("كلمة المرور يجب ألا تقل عن 8 أحرف.");
					return;
				}
				const { data, error } = await supabase.auth.signUp({
					email: email.trim(),
					password,
					options: {
						emailRedirectTo: window.location.origin,
						data: { full_name: fullName.trim() }
					}
				});
				if (error) throw error;
				if (data.session) navigate({
					to: "/onboarding",
					replace: true
				});
				else setSentTo(email.trim());
			} else {
				const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), { redirectTo: `${window.location.origin}/reset-password` });
				if (error) throw error;
				setSentTo(email.trim());
			}
		} catch (err) {
			toast.error(translateAuthError(err instanceof Error ? err.message : String(err)));
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-hero",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-screen max-w-md flex-col px-4 py-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "my-auto py-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-3xl border border-border bg-card p-6 shadow-lift sm:p-8",
					children: sentTo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mx-auto grid size-14 place-items-center rounded-2xl bg-primary-soft text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MailCheck, {
									className: "size-7",
									"aria-hidden": "true"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "mt-4 text-xl font-bold",
								children: "تحقق من بريدك"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted-foreground",
								children: [
									mode === "signup" ? "أرسلنا رابط تأكيد الحساب إلى" : "أرسلنا رابط إعادة تعيين كلمة المرور إلى",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-foreground",
										dir: "ltr",
										children: sentTo
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "soft",
								className: "mt-6 w-full",
								onClick: () => {
									setSentTo(null);
									setMode("login");
								},
								children: "العودة لتسجيل الدخول"
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						mode !== "forgot" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-6 grid grid-cols-2 rounded-xl bg-muted p-1",
							role: "tablist",
							children: ["login", "signup"].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								role: "tab",
								"aria-selected": mode === m,
								onClick: () => setMode(m),
								className: cn("rounded-lg py-2 text-sm font-medium transition-colors", mode === m ? "bg-card text-primary-deep shadow-soft" : "text-muted-foreground"),
								children: m === "login" ? "تسجيل الدخول" : "حساب جديد"
							}, m))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-xl font-bold",
							children: mode === "login" ? "مرحبًا بعودتك" : mode === "signup" ? "أنشئ حسابك" : "استعادة كلمة المرور"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: mode === "forgot" ? "أدخل بريدك وسنرسل لك رابط إعادة التعيين." : "ملف إنجازك الخاص بانتظارك."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit,
							className: "mt-6 space-y-4",
							children: [
								mode === "signup" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "fullName",
										children: "الاسم الكامل"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "fullName",
										value: fullName,
										onChange: (e) => setFullName(e.target.value),
										autoComplete: "name",
										required: true,
										className: "h-11"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "email",
										children: "البريد الإلكتروني"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "email",
										type: "email",
										dir: "ltr",
										value: email,
										onChange: (e) => setEmail(e.target.value),
										autoComplete: "email",
										required: true,
										className: "h-11 text-left"
									})]
								}),
								mode !== "forgot" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "password",
											children: "كلمة المرور"
										}), mode === "login" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setMode("forgot"),
											className: "text-xs text-primary hover:underline",
											children: "نسيت كلمة المرور؟"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "password",
										type: "password",
										dir: "ltr",
										value: password,
										onChange: (e) => setPassword(e.target.value),
										autoComplete: mode === "login" ? "current-password" : "new-password",
										minLength: 8,
										required: true,
										className: "h-11 text-left"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "submit",
									variant: "hero",
									size: "lg",
									className: "w-full",
									disabled: loading,
									children: [loading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }), mode === "login" ? "دخول" : mode === "signup" ? "إنشاء الحساب" : "إرسال الرابط"]
								}),
								mode === "forgot" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setMode("login"),
									className: "w-full text-center text-sm text-muted-foreground hover:text-foreground",
									children: "العودة لتسجيل الدخول"
								})
							]
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-center text-xs text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "hover:text-foreground",
						children: "العودة للصفحة الرئيسية"
					})
				})]
			})]
		})
	});
}
//#endregion
export { AuthPage as component };
