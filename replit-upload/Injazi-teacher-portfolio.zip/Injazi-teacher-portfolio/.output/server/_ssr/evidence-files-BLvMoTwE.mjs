//#region node_modules/.nitro/vite/services/ssr/assets/evidence-files-BLvMoTwE.js
var ALLOWED_EVIDENCE_TYPES = {
	"image/jpeg": ["jpg", "jpeg"],
	"image/png": ["png"],
	"image/webp": ["webp"],
	"application/pdf": ["pdf"]
};
var EVIDENCE_ACCEPT = "image/jpeg,image/png,image/webp,application/pdf";
function fileExtension(name) {
	const i = name.lastIndexOf(".");
	return i === -1 ? "" : name.slice(i + 1).toLowerCase();
}
function validateEvidenceFile(file) {
	const ext = fileExtension(file.name);
	const allowedExts = ALLOWED_EVIDENCE_TYPES[file.type];
	if (!allowedExts || !allowedExts.includes(ext)) return {
		ok: false,
		error: "نوع الملف غير مدعوم. المسموح: صور (JPG، PNG، WEBP) أو ملفات PDF."
	};
	if (file.size <= 0) return {
		ok: false,
		error: "الملف فارغ."
	};
	if (file.size > 10485760) return {
		ok: false,
		error: "حجم الملف يتجاوز 10 ميجابايت."
	};
	return {
		ok: true,
		ext,
		mimeType: file.type
	};
}
/** Storage path: the first folder must be the owner's user id (enforced by storage policies). */
function buildEvidencePath(userId, ext, id = crypto.randomUUID()) {
	return `${userId}/${id}.${ext}`;
}
function isImage(mime) {
	return mime.startsWith("image/");
}
function isPdf(mime) {
	return mime === "application/pdf";
}
function formatBytes(bytes) {
	if (bytes < 1024) return `${bytes} بايت`;
	if (bytes < 1048576) return `${(bytes / 1024).toFixed(0)} ك.ب`;
	return `${(bytes / 1048576).toFixed(1)} م.ب`;
}
/** Default evidence title from a file name: drop the extension, tidy separators, cap at 120 chars. */
function titleFromFileName(name) {
	return (name.replace(/\.[^.]+$/, "").replace(/[_]+/g, " ").replace(/\s+/g, " ").trim() || "شاهد").slice(0, 120);
}
/** Today's date in the user's local time zone as YYYY-MM-DD. */
function todayISO(now = /* @__PURE__ */ new Date()) {
	return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
}
/** Parse YYYY-MM-DD as a local date (avoids the UTC off-by-one of `new Date("2026-01-15")`). */
function parseISODate(iso) {
	if (!iso) return null;
	const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
	if (!m) return null;
	return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
}
function formatEvidenceDate(iso) {
	const d = parseISODate(iso);
	if (!d) return "";
	return d.toLocaleDateString("ar-SA-u-ca-gregory", {
		day: "numeric",
		month: "long",
		year: "numeric"
	});
}
/** Chronological order for the printed portfolio: evidence date, then upload time. */
function compareEvidenceChronological(a, b) {
	const da = a.evidence_date ?? a.created_at.slice(0, 10);
	const db = b.evidence_date ?? b.created_at.slice(0, 10);
	if (da !== db) return da < db ? -1 : 1;
	return a.created_at < b.created_at ? -1 : a.created_at > b.created_at ? 1 : 0;
}
/** Split a picked batch into files we can upload and files we must reject (type/size/batch cap). */
function splitEvidenceFiles(files, alreadyQueued = 0) {
	const accepted = [];
	const rejected = [];
	for (const f of files) {
		const check = validateEvidenceFile(f);
		if (!check.ok) rejected.push({
			name: f.name,
			error: check.error
		});
		else if (alreadyQueued + accepted.length >= 10) rejected.push({
			name: f.name,
			error: `الحد الأقصى 10 ملفات في كل دفعة.`
		});
		else accepted.push(f);
	}
	return {
		accepted,
		rejected
	};
}
var MAX_DESCRIPTION_LENGTH = 2e3;
/** Validate and normalise the editable fields of an evidence item. */
function normalizeEvidenceFields(input) {
	const title = input.title.trim();
	if (!title) return {
		ok: false,
		error: "اكتب عنوانًا للشاهد."
	};
	if (title.length > 200) return {
		ok: false,
		error: "العنوان طويل جدًا (200 حرف كحد أقصى)."
	};
	const description = input.description.trim();
	if (description.length > 2e3) return {
		ok: false,
		error: "الوصف طويل جدًا (2000 حرف كحد أقصى)."
	};
	const d = parseISODate(input.date);
	if (!d || todayISO(d) !== input.date) return {
		ok: false,
		error: "اختر تاريخًا صحيحًا للشاهد."
	};
	return {
		ok: true,
		value: {
			title,
			description: description || null,
			evidence_date: input.date
		}
	};
}
//#endregion
export { formatBytes as a, isPdf as c, titleFromFileName as d, todayISO as f, compareEvidenceChronological as i, normalizeEvidenceFields as l, MAX_DESCRIPTION_LENGTH as n, formatEvidenceDate as o, validateEvidenceFile as p, buildEvidencePath as r, isImage as s, EVIDENCE_ACCEPT as t, splitEvidenceFiles as u };
