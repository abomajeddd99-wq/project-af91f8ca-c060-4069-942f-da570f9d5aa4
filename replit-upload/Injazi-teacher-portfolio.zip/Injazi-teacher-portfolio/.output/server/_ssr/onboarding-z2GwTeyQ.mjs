import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as careerPathsQuery } from "./catalog-DHP9v1Uv.mjs";
import { i as profileQuery } from "./queries-DI_WVmjo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/onboarding-z2GwTeyQ.js
var $$splitComponentImporter = () => import("./onboarding-CppCBmFE.mjs");
var Route = createFileRoute("/_authenticated/onboarding")({
	head: () => ({ meta: [
		{ title: "استكمال الحساب الشخصي — إنجازي" },
		{
			name: "description",
			content: "اختيار المسار الوظيفي وبيانات حسابك الشخصي المستقل."
		},
		{
			property: "og:title",
			content: "استكمال الحساب الشخصي — إنجازي"
		},
		{
			property: "og:description",
			content: "اختيار المسار الوظيفي وبياناتك المهنية."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	loader: ({ context }) => Promise.all([context.queryClient.ensureQueryData(careerPathsQuery()), context.queryClient.ensureQueryData(profileQuery(context.user.id))]),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
