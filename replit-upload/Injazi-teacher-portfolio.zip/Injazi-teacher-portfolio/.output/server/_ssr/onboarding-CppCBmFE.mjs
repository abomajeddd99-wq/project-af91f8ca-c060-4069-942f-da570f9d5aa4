import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D6YTns3_.mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as useQueryClient, n as useSuspenseQuery } from "../_libs/tanstack__react-query.mjs";
import { t as careerPathsQuery } from "./catalog-DHP9v1Uv.mjs";
import { c as validateCareerSelection, i as profileQuery } from "./queries-DI_WVmjo.mjs";
import { t as Button } from "./button-B4IWnrg7.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-CYB-gyWu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Route } from "./onboarding-z2GwTeyQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/onboarding-CppCBmFE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CareerProfile({ userId }) {
	const { data: roles } = useSuspenseQuery(careerPathsQuery());
	const { data: profile } = useSuspenseQuery(profileQuery(userId));
	const [roleId, setRoleId] = (0, import_react.useState)(profile?.professional_role_id ?? "");
	const [name, setName] = (0, import_react.useState)(profile?.full_name ?? "");
	const [school, setSchool] = (0, import_react.useState)(profile?.school ?? "");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const queryClient = useQueryClient();
	const navigate = useNavigate();
	async function save(event) {
		event.preventDefault();
		if (!validateCareerSelection(roleId, roles) || name.trim().length < 3) {
			toast.error("أكمل الاسم واختر مسارك الوظيفي.");
			return;
		}
		setSaving(true);
		try {
			const { error } = await supabase.from("profiles").update({
				full_name: name.trim(),
				school: school.trim() || null,
				professional_role_id: roleId,
				job_title: roles.find((r) => r.id === roleId)?.title ?? null,
				onboarding_completed_at: (/* @__PURE__ */ new Date()).toISOString()
			}).eq("id", userId);
			if (error) throw error;
			await queryClient.invalidateQueries();
			toast.success("تم حفظ المسار الوظيفي.");
			await navigate({ to: "/dashboard" });
		} catch {
			toast.error("تعذر حفظ المسار الوظيفي.");
		} finally {
			setSaving(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: save,
		className: "mx-auto max-w-xl space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold text-primary-deep",
				children: "استكمال الحساب الشخصي"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "career-name",
					children: "الاسم الكامل"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "career-name",
					value: name,
					onChange: (e) => setName(e.target.value),
					maxLength: 200,
					required: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "career-role",
					children: "المسار الوظيفي"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: roleId,
					onValueChange: setRoleId,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						id: "career-role",
						className: "w-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "اختر المسار الوظيفي" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: roles.filter((r) => r.is_active).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: r.id,
						children: r.title
					}, r.id)) })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "career-school",
					children: "المدرسة / جهة العمل"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "career-school",
					value: school,
					onChange: (e) => setSchool(e.target.value),
					maxLength: 200
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				disabled: saving,
				children: saving ? "جارٍ الحفظ…" : "حفظ المسار والمتابعة"
			})
		]
	});
}
var SplitComponent = () => {
	const { user } = Route.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CareerProfile, { userId: user.id });
};
//#endregion
export { SplitComponent as component };
