import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-9iMJhyvk.js
var $$splitComponentImporter = () => import("./auth-CiOoxS0A.mjs");
var Route = createFileRoute("/auth")({
	validateSearch: (search) => {
		const m = search["mode"];
		const r = search["redirect"];
		return {
			mode: m === "signup" || m === "forgot" || m === "login" ? m : void 0,
			redirect: typeof r === "string" ? r : void 0
		};
	},
	head: () => ({ meta: [
		{ title: "تسجيل الدخول — إنجازي" },
		{
			name: "description",
			content: "سجّل دخولك أو أنشئ حسابًا جديدًا في منصة إنجازي للمعلمين."
		},
		{
			property: "og:title",
			content: "تسجيل الدخول — إنجازي"
		},
		{
			property: "og:description",
			content: "الدخول إلى ملف إنجازك الخاص."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
