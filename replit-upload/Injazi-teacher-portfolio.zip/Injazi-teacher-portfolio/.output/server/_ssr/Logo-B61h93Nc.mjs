import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Logo-B61h93Nc.js
var import_jsx_runtime = require_jsx_runtime();
function LogoMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 40 40",
		"aria-hidden": "true",
		className: cn("size-9", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "40",
				height: "40",
				rx: "12",
				className: "fill-primary"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M20 7.5l3.4 5.9 6.6-1.5-1.5 6.6 5.9 3.4-5.9 3.4 1.5 6.6-6.6-1.5L20 36.3l-3.4-5.9-6.6 1.5 1.5-6.6-5.9-3.4 5.9-3.4-1.5-6.6 6.6 1.5z",
				className: "fill-primary-foreground/15"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M14 20.5l4.2 4.2L26.5 16",
				fill: "none",
				strokeWidth: "3",
				strokeLinecap: "round",
				strokeLinejoin: "round",
				className: "stroke-primary-foreground"
			})
		]
	});
}
function Logo({ to = "/", className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: cn("flex items-center gap-2.5", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-xl font-bold text-primary-deep",
			children: "إنجازي"
		})]
	});
}
//#endregion
export { LogoMark as n, Logo as t };
