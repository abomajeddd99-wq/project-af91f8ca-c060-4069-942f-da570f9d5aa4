import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/standards._standardId-BimnVASk.js
var import_jsx_runtime = require_jsx_runtime();
var SplitNotFoundComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
	className: "py-16 text-center",
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted-foreground",
		children: "المعيار غير موجود."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/standards",
		className: "mt-4 inline-block text-primary hover:underline",
		children: "العودة للمعايير"
	})]
});
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
