import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D6YTns3_.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as useQueryClient, n as useSuspenseQuery } from "../_libs/tanstack__react-query.mjs";
import { n as categoriesQuery, r as criteriaVersionsQuery, t as careerPathsQuery } from "./catalog-DHP9v1Uv.mjs";
import { t as allStandardsQuery } from "./queries-DI_WVmjo.mjs";
import { n as accountsQuery, t as Route } from "./admin-C3XmVcA8.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Button } from "./button-B4IWnrg7.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { n as CheckboxIndicator, t as Checkbox$1 } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { j as Check } from "../_libs/lucide-react.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-CYB-gyWu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-Dcueyt9Y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Checkbox = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox$1, {
	ref,
	className: cn("grid place-content-center peer h-4 w-4 shrink-0 rounded-sm border border-primary shadow cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckboxIndicator, {
		className: cn("grid place-content-center text-current"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" })
	})
}));
Checkbox.displayName = Checkbox$1.displayName;
var Tabs = Root2;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
	ref,
	className: cn("inline-flex h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground", className),
	...props
}));
TabsList.displayName = List.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
	ref,
	className: cn("inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background cursor-pointer transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow", className),
	...props
}));
TabsTrigger.displayName = Trigger.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
	ref,
	className: cn("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
	...props
}));
TabsContent.displayName = Content.displayName;
function AdminPanel() {
	const { data: roles } = useSuspenseQuery(careerPathsQuery());
	const { data: versions } = useSuspenseQuery(criteriaVersionsQuery());
	const { data: categories } = useSuspenseQuery(categoriesQuery());
	const { data: standards } = useSuspenseQuery(allStandardsQuery());
	const { data: accounts } = useSuspenseQuery(accountsQuery());
	const qc = useQueryClient();
	const [kind, setKind] = (0, import_react.useState)("roles");
	const [editing, setEditing] = (0, import_react.useState)("");
	const [title, setTitle] = (0, import_react.useState)("");
	const [code, setCode] = (0, import_react.useState)("");
	const [parent, setParent] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("");
	const [source, setSource] = (0, import_react.useState)("");
	const [official, setOfficial] = (0, import_react.useState)(false);
	const [description, setDescription] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	function reset(next = kind) {
		setKind(next);
		setEditing("");
		setTitle("");
		setCode("");
		setParent("");
		setCategory("");
		setSource("");
		setOfficial(false);
		setDescription("");
	}
	async function save(event) {
		event.preventDefault();
		setSaving(true);
		try {
			if (kind === "roles") {
				const value = {
					title: title.trim(),
					code: code.trim()
				};
				const { error } = editing ? await supabase.from("professional_roles").update(value).eq("id", editing) : await supabase.from("professional_roles").insert(value);
				if (error) throw error;
			} else if (kind === "versions") {
				if (!parent || official && !source.trim()) throw new Error();
				const value = {
					title: title.trim(),
					professional_role_id: parent,
					is_official: official,
					source_reference: source.trim() || null
				};
				const { error } = editing ? await supabase.from("criteria_versions").update(value).eq("id", editing) : await supabase.from("criteria_versions").insert(value);
				if (error) throw error;
			} else if (kind === "categories") {
				if (!parent) throw new Error();
				const value = {
					title: title.trim(),
					version_id: parent
				};
				const { error } = editing ? await supabase.from("criteria_categories").update(value).eq("id", editing) : await supabase.from("criteria_categories").insert(value);
				if (error) throw error;
			} else {
				if (!parent) throw new Error();
				const value = {
					title: title.trim(),
					code: code.trim(),
					description: description.trim() || null,
					criteria_version_id: parent,
					category_id: category || null,
					is_placeholder: !versions.find((v) => v.id === parent)?.is_official
				};
				const { error } = editing ? await supabase.from("standards").update(value).eq("id", editing) : await supabase.from("standards").insert(value);
				if (error) throw error;
			}
			await qc.invalidateQueries();
			reset();
			toast.success("تم الحفظ.");
		} catch {
			toast.error("تعذر الحفظ. تحقق من الحقول والرمز والمصدر المعتمد.");
		} finally {
			setSaving(false);
		}
	}
	async function toggle(id, active) {
		if (!window.confirm("تأكيد تغيير حالة العنصر؟ لن تُحذف البيانات.")) return;
		if ((kind === "roles" ? await supabase.from("professional_roles").update({ is_active: !active }).eq("id", id) : kind === "versions" ? await supabase.from("criteria_versions").update({ status: active ? "archived" : "published" }).eq("id", id) : kind === "categories" ? await supabase.from("criteria_categories").update({ is_active: !active }).eq("id", id) : await supabase.from("standards").update({ is_active: !active }).eq("id", id)).error) toast.error("تعذر تغيير الحالة.");
		else {
			await qc.invalidateQueries();
			toast.success("تم تحديث الحالة.");
		}
	}
	const rows = kind === "roles" ? roles : kind === "versions" ? versions : kind === "categories" ? categories : standards.filter((s) => s.owner_id === null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold text-primary-deep",
				children: "إدارة المنصة"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				value: kind,
				onValueChange: reset,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
					className: "h-auto w-full flex-wrap",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "roles",
							children: "المسارات"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "versions",
							children: "الإصدارات"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "categories",
							children: "التصنيفات"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "standards",
							children: "المعايير"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "users",
							children: "المستخدمون"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "users",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-right text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "الاسم"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "البريد"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "المسار"
								})
							] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: accounts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t border-border",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3",
										children: a.full_name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3",
										dir: "ltr",
										children: a.email
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3",
										children: a.career_path || "لم يُحدد"
									})
								]
							}, a.id)) })]
						})
					})
				})]
			}),
			kind !== "users" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: save,
				className: "grid gap-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "catalog-title",
							children: "العنوان"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "catalog-title",
							value: title,
							onChange: (e) => setTitle(e.target.value),
							required: true,
							maxLength: 200
						})]
					}),
					(kind === "roles" || kind === "standards") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "catalog-code",
							children: "الرمز الفريد"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "catalog-code",
							value: code,
							onChange: (e) => setCode(e.target.value),
							required: true,
							maxLength: 80
						})]
					}),
					kind !== "roles" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "catalog-parent",
							children: kind === "versions" ? "المسار الوظيفي" : "الإصدار"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: parent,
							onValueChange: (v) => {
								setParent(v);
								setCategory("");
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								id: "catalog-parent",
								className: "w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "اختر" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (kind === "versions" ? roles : versions).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: r.id,
								children: r.title
							}, r.id)) })]
						})]
					}),
					kind === "versions" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
							checked: official,
							onCheckedChange: (v) => setOfficial(v === true)
						}), " إصدار رسمي معتمد"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "catalog-source",
							children: "مرجع الاعتماد الرسمي"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "catalog-source",
							value: source,
							onChange: (e) => setSource(e.target.value),
							required: official
						})]
					})] }),
					kind === "standards" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "catalog-category",
							children: "التصنيف"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: category || "none",
							onValueChange: (v) => setCategory(v === "none" ? "" : v),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								id: "catalog-category",
								className: "w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "none",
								children: "بدون تصنيف"
							}), categories.filter((c) => c.version_id === parent).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: c.id,
								children: c.title
							}, c.id))] })]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "catalog-description",
							children: "الوصف"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "catalog-description",
							value: description,
							onChange: (e) => setDescription(e.target.value)
						})]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2 sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: saving,
							children: saving ? "جارٍ الحفظ…" : editing ? "حفظ التعديل" : "إضافة"
						}), editing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => reset(),
							children: "إلغاء"
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-border",
				children: rows.map((r) => {
					const active = "status" in r ? r.status === "published" : r.is_active;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-center justify-between gap-3 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: r.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "status" in r ? `${r.status === "published" ? "منشور" : r.status === "draft" ? "مسودة" : "مؤرشف"} · ${r.is_official ? "رسمي معتمد" : "تجريبي"}` : active ? "نشط" : "مؤرشف"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => {
									setEditing(r.id);
									setTitle(r.title);
									setCode("code" in r && typeof r.code === "string" ? r.code : "");
									setParent("professional_role_id" in r && typeof r.professional_role_id === "string" ? r.professional_role_id : "version_id" in r && typeof r.version_id === "string" ? r.version_id : "criteria_version_id" in r && typeof r.criteria_version_id === "string" ? r.criteria_version_id : "");
									setOfficial("is_official" in r && r.is_official === true);
									setSource("source_reference" in r && typeof r.source_reference === "string" ? r.source_reference : "");
									setCategory("category_id" in r && typeof r.category_id === "string" ? r.category_id : "");
									setDescription("description" in r && typeof r.description === "string" ? r.description : "");
								},
								children: "تعديل"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "soft",
								size: "sm",
								onClick: () => toggle(r.id, active),
								children: active ? "أرشفة" : kind === "versions" ? "نشر داخل المنصة" : "تفعيل"
							})]
						})]
					}, r.id);
				})
			})] })
		]
	});
}
var SplitComponent = () => Route.useLoaderData().allowed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminPanel, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: "py-12 text-center",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "text-xl font-bold",
		children: "غير مصرح بالدخول إلى الإدارة"
	})
});
//#endregion
export { SplitComponent as component };
