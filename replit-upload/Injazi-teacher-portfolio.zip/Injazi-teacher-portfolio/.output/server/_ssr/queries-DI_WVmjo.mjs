import { t as supabase } from "./client-D6YTns3_.mjs";
import { t as queryOptions } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/queries-DI_WVmjo.js
function validateCareerSelection(roleId, roles) {
	return roles.some((role) => role.id === roleId && role.is_active);
}
function assignedStandards(standards, versions) {
	const published = new Set(versions.filter((v) => v.status === "published").map((v) => v.id));
	return standards.filter((s) => s.owner_id !== null || s.criteria_version_id !== null && published.has(s.criteria_version_id));
}
var standardsQuery = () => queryOptions({
	queryKey: ["standards", "active"],
	queryFn: async () => {
		const { data, error } = await supabase.from("standards").select("*").eq("is_active", true).order("sort_order", { ascending: true });
		if (error) throw error;
		const { data: versions, error: versionError } = await supabase.from("criteria_versions").select("id,status");
		if (versionError) throw versionError;
		return assignedStandards(data, versions);
	}
});
var allStandardsQuery = () => queryOptions({
	queryKey: ["standards", "all"],
	queryFn: async () => {
		const { data, error } = await supabase.from("standards").select("*").order("sort_order", { ascending: true });
		if (error) throw error;
		return data;
	}
});
var progressQuery = () => queryOptions({
	queryKey: ["progress"],
	queryFn: async () => {
		const { data, error } = await supabase.from("standard_progress").select("*");
		if (error) throw error;
		return data;
	}
});
var evidencesQuery = () => queryOptions({
	queryKey: ["evidences"],
	queryFn: async () => {
		const { data, error } = await supabase.from("evidences").select("*").order("created_at", { ascending: false });
		if (error) throw error;
		return data;
	}
});
var profileQuery = (userId) => queryOptions({
	queryKey: ["profile", userId],
	queryFn: async () => {
		const { data, error } = await supabase.from("profiles").select("*").eq("id", userId).maybeSingle();
		if (error) throw error;
		return data;
	}
});
var isAdminQuery = () => queryOptions({
	queryKey: ["is-admin"],
	queryFn: async () => {
		const { data, error } = await supabase.rpc("is_admin");
		if (error) return false;
		return data === true;
	},
	staleTime: 6e4
});
var signedUrlQuery = (path) => queryOptions({
	queryKey: ["signed-url", path],
	queryFn: async () => {
		const { data, error } = await supabase.storage.from("evidence").createSignedUrl(path, 600);
		if (error) throw error;
		return data.signedUrl;
	},
	staleTime: 48e4
});
//#endregion
export { progressQuery as a, validateCareerSelection as c, profileQuery as i, evidencesQuery as n, signedUrlQuery as o, isAdminQuery as r, standardsQuery as s, allStandardsQuery as t };
