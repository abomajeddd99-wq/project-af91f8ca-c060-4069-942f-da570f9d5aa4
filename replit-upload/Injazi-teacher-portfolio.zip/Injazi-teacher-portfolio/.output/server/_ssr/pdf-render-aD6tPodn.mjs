//#region node_modules/.nitro/vite/services/ssr/assets/pdf-render-aD6tPodn.js
var pdfjsPromise = null;
function ensurePolyfills() {
	if (typeof Promise.withResolvers !== "function") Promise.withResolvers = function withResolvers() {
		let resolve;
		let reject;
		return {
			promise: new Promise((res, rej) => {
				resolve = res;
				reject = rej;
			}),
			resolve,
			reject
		};
	};
}
function loadPdfjs() {
	if (!pdfjsPromise) pdfjsPromise = (async () => {
		ensurePolyfills();
		const [pdfjs, worker] = await Promise.all([import("../_libs/pdfjs-dist.mjs").then((n) => n.t), import("./pdf.worker.min-rIC0noZo.mjs")]);
		pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
		return pdfjs;
	})().catch((e) => {
		pdfjsPromise = null;
		throw e;
	});
	return pdfjsPromise;
}
async function openPdf(data) {
	return (await loadPdfjs()).getDocument({
		data: new Uint8Array(data),
		cMapUrl: "/pdfjs/cmaps/",
		cMapPacked: true,
		standardFontDataUrl: "/pdfjs/standard_fonts/"
	}).promise;
}
/** Render one PDF page (1-based) to a JPEG data URL, `targetWidth` pixels wide, on a white background. */
async function renderPdfPage(doc, pageNumber, targetWidth) {
	const page = await doc.getPage(pageNumber);
	const base = page.getViewport({ scale: 1 });
	const scale = Math.min(4, targetWidth / base.width);
	const viewport = page.getViewport({ scale });
	const canvas = document.createElement("canvas");
	canvas.width = Math.ceil(viewport.width);
	canvas.height = Math.ceil(viewport.height);
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Canvas unavailable");
	ctx.fillStyle = "#ffffff";
	ctx.fillRect(0, 0, canvas.width, canvas.height);
	await page.render({
		canvasContext: ctx,
		viewport
	}).promise;
	const out = {
		dataUrl: canvas.toDataURL("image/jpeg", .86),
		width: canvas.width,
		height: canvas.height
	};
	page.cleanup();
	canvas.width = 0;
	canvas.height = 0;
	return out;
}
//#endregion
export { openPdf, renderPdfPage };
