import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as progressQuery, n as evidencesQuery, s as standardsQuery } from "./queries-DI_WVmjo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-CVKkQgP1.js
var $$splitComponentImporter = () => import("./dashboard-267qdHJr.mjs");
var Route = createFileRoute("/_authenticated/dashboard")({
	head: () => ({ meta: [
		{ title: "لوحة التحكم — إنجازي" },
		{
			name: "description",
			content: "متابعة نسبة إنجاز ملفك وشواهدك."
		},
		{
			property: "og:title",
			content: "لوحة التحكم — إنجازي"
		},
		{
			property: "og:description",
			content: "متابعة نسبة إنجاز ملفك وشواهدك."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	loader: ({ context }) => Promise.all([
		context.queryClient.ensureQueryData(standardsQuery()),
		context.queryClient.ensureQueryData(progressQuery()),
		context.queryClient.ensureQueryData(evidencesQuery())
	]),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
