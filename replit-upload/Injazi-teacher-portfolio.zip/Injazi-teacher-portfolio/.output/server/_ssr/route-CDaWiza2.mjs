import { t as supabase } from "./client-D6YTns3_.mjs";
import { b as useNavigate, h as Outlet, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as useQueryClient, r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { r as isAdminQuery } from "./queries-DI_WVmjo.mjs";
import { t as Button } from "./button-B4IWnrg7.mjs";
import { N as BookOpenCheck, d as LogOut, g as LayoutDashboard, m as ListChecks, n as UserRound } from "../_libs/lucide-react.mjs";
import { t as Logo } from "./Logo-B61h93Nc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/route-CDaWiza2.js
var import_jsx_runtime = require_jsx_runtime();
var baseNav = [
	{
		to: "/dashboard",
		label: "الرئيسية",
		icon: LayoutDashboard
	},
	{
		to: "/standards",
		label: "المعايير",
		icon: ListChecks
	},
	{
		to: "/portfolio",
		label: "ملف الإنجاز",
		icon: BookOpenCheck
	},
	{
		to: "/profile",
		label: "حسابي",
		icon: UserRound
	}
];
function AppShell({ children }) {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const nav = baseNav;
	const { data: isAdmin } = useQuery(isAdminQuery());
	async function signOut() {
		await queryClient.cancelQueries();
		queryClient.clear();
		await supabase.auth.signOut();
		navigate({
			to: "/auth",
			search: { mode: "login" },
			replace: true
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-[100dvh] bg-background",
		dir: "rtl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-30 border-b border-border/70 bg-background/95 backdrop-blur print:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { to: "/dashboard" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "hidden items-center gap-1 md:flex",
							"aria-label": "التنقل الرئيسي",
							children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								className: "flex items-center gap-2 rounded-xl px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
								activeProps: {
									className: "bg-primary-soft !text-accent-foreground font-medium",
									"aria-current": "page"
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
									className: "size-4",
									"aria-hidden": "true"
								}), item.label]
							}, item.to))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "ghost",
							size: "sm",
							onClick: signOut,
							"aria-label": "تسجيل الخروج",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { "aria-hidden": "true" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "خروج"
							})]
						}),
						isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							size: "sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/admin",
								children: "الإدارة"
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto max-w-6xl px-4 pb-28 pt-6 md:pb-12 print:max-w-none print:p-0",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 border-t border-border bg-card/95 backdrop-blur safe-bottom md:hidden print:hidden",
				"aria-label": "التنقل السفلي",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mx-auto flex max-w-lg items-stretch justify-around px-2 pt-1.5",
					children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "flex-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: "flex flex-col items-center gap-1 rounded-xl py-1.5 text-[11px] text-muted-foreground transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
							activeProps: {
								className: "!text-primary font-semibold",
								"aria-current": "page"
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
								className: "size-5",
								"aria-hidden": "true"
							}), item.label]
						})
					}, item.to))
				})
			})
		]
	});
}
function AuthenticatedLayout() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) });
}
//#endregion
export { AuthenticatedLayout as component };
