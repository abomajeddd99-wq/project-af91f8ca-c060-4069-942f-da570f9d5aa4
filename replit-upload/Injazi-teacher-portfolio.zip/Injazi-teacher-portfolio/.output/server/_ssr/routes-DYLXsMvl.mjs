import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-B4IWnrg7.mjs";
import { S as FileCheckCorner, a as ShieldCheck, m as ListChecks, n as UserRound, r as Upload, s as Printer, y as FolderLock } from "../_libs/lucide-react.mjs";
import { t as Logo } from "./Logo-B61h93Nc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DYLXsMvl.js
var import_jsx_runtime = require_jsx_runtime();
var hero_portfolio_default = "/assets/hero-portfolio-BhzkMCrd.jpg";
var features = [
	{
		icon: ListChecks,
		title: "معايير الأداء",
		body: "استعرض معايير الأداء ومؤشراتها في مكان واحد منظّم."
	},
	{
		icon: Upload,
		title: "رفع الشواهد",
		body: "أرفق الصور وملفات PDF لكل معيار مباشرة من جوالك."
	},
	{
		icon: FileCheckCorner,
		title: "متابعة الإنجاز",
		body: "اعرف نسبة اكتمال ملفك وما تبقّى عليك بنظرة واحدة."
	},
	{
		icon: Printer,
		title: "ملف PDF جاهز",
		body: "اطبع ملف إنجازك بتنسيق عربي أنيق أو احفظه PDF."
	}
];
var steps = [
	{
		icon: UserRound,
		title: "أنشئ حسابك",
		body: "سجّل ببريدك الإلكتروني وأكمل بياناتك المهنية."
	},
	{
		icon: Upload,
		title: "أضف شواهدك",
		body: "اختر المعيار وارفع الشاهد مع وصف مختصر."
	},
	{
		icon: Printer,
		title: "اطبع ملفك",
		body: "ولّد ملف الإنجاز كاملًا بضغطة زر."
	}
];
function Landing() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-30 border-b border-border/60 bg-background/85 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-16 max-w-6xl items-center justify-between px-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "ghost",
							size: "sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/auth",
								search: { mode: "login" },
								children: "دخول"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/auth",
								search: { mode: "signup" },
								children: "إنشاء حساب"
							})
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "relative overflow-hidden bg-hero",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto grid max-w-6xl gap-10 px-4 pb-14 pt-10 md:grid-cols-2 md:items-center md:pb-24 md:pt-16",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "animate-rise",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-2 rounded-full bg-primary-soft px-3 py-1 text-xs font-medium text-accent-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
										className: "size-3.5",
										"aria-hidden": "true"
									}), "خاص وآمن — ملفاتك لك وحدك"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "mt-5 text-4xl font-bold leading-[1.25] text-primary-deep md:text-5xl",
									children: [
										"ملف إنجازك،",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-primary",
											children: "منظّم وجاهز للطباعة."
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 max-w-md text-base leading-loose text-muted-foreground md:text-lg",
									children: "إنجازي يساعدك على توثيق شواهد أدائك الوظيفي وفق المعايير، ومتابعة اكتمالها، ثم طباعة ملف إنجاز عربي احترافي."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 flex flex-col gap-3 sm:flex-row",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										variant: "hero",
										size: "lg",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/auth",
											search: { mode: "signup" },
											children: "ابدأ مجانًا"
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										variant: "outline",
										size: "lg",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/auth",
											search: { mode: "login" },
											children: "لدي حساب"
										})
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "animate-rise [animation-delay:120ms]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-hidden rounded-3xl border border-border bg-card shadow-lift",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: hero_portfolio_default,
									alt: "ملف إنجاز معلم منظّم بشهادات وأوراق",
									width: 1280,
									height: 1024,
									className: "h-auto w-full"
								})
							})
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mx-auto max-w-6xl px-4 py-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl font-bold text-primary-deep md:text-3xl",
						children: "كل ما تحتاجه لملف إنجازك"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
						children: features.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-border bg-card p-5 shadow-soft",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid size-11 place-items-center rounded-xl bg-primary-soft text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(f.icon, {
										className: "size-5",
										"aria-hidden": "true"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-4 text-lg font-semibold",
									children: f.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1.5 text-sm leading-relaxed text-muted-foreground",
									children: f.body
								})
							]
						}, f.title))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "bg-secondary/60",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-6xl px-4 py-16",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl font-bold text-primary-deep md:text-3xl",
							children: "ثلاث خطوات فقط"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mt-8 grid gap-4 md:grid-cols-3",
							children: steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "relative rounded-2xl bg-card p-5 shadow-soft",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-5xl font-bold text-primary-soft",
										children: i + 1
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(s.icon, {
											className: "size-5 text-primary",
											"aria-hidden": "true"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-lg font-semibold",
											children: s.title
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1.5 text-sm leading-relaxed text-muted-foreground",
										children: s.body
									})
								]
							}, s.title))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "mx-auto max-w-6xl px-4 py-16",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-6 rounded-3xl bg-brand-gradient p-8 text-primary-foreground md:grid-cols-[auto_1fr] md:items-center md:p-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid size-14 place-items-center rounded-2xl bg-primary-foreground/15",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderLock, {
								className: "size-7",
								"aria-hidden": "true"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl font-bold",
							children: "خصوصيتك أولًا"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 leading-loose text-primary-foreground/85",
							children: "كل معلم يرى سجلاته وملفاته فقط. الملفات محفوظة في مساحة خاصة مشفّرة، ولا يستطيع حتى مشرفو المنصة الاطلاع على شواهدك."
						})] })]
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-4 py-8 text-sm text-muted-foreground sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"© ",
						(/* @__PURE__ */ new Date()).getFullYear(),
						" إنجازي — للمعلمين والمعلمات في المملكة العربية السعودية"
					] })]
				})
			})
		]
	});
}
//#endregion
export { Landing as component };
