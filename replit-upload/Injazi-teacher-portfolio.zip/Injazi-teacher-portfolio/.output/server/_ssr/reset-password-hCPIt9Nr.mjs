import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-D6YTns3_.mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-B4IWnrg7.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { p as LoaderCircle } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Logo } from "./Logo-B61h93Nc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reset-password-hCPIt9Nr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ResetPassword() {
	const navigate = useNavigate();
	const [ready, setReady] = (0, import_react.useState)(false);
	const [password, setPassword] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const isRecovery = window.location.hash.includes("type=recovery");
		const { data } = supabase.auth.onAuthStateChange((event) => {
			if (event === "PASSWORD_RECOVERY") setReady(true);
		});
		supabase.auth.getSession().then(({ data: s }) => {
			if (s.session && isRecovery) setReady(true);
		});
		if (isRecovery) setReady(true);
		return () => data.subscription.unsubscribe();
	}, []);
	async function onSubmit(e) {
		e.preventDefault();
		if (password.length < 8) {
			toast.error("كلمة المرور يجب ألا تقل عن 8 أحرف.");
			return;
		}
		setLoading(true);
		const { error } = await supabase.auth.updateUser({ password });
		setLoading(false);
		if (error) {
			toast.error("تعذر تحديث كلمة المرور. اطلب رابطًا جديدًا.");
			return;
		}
		toast.success("تم تحديث كلمة المرور.");
		navigate({
			to: "/dashboard",
			replace: true
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-hero",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-screen max-w-md flex-col px-4 py-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "my-auto rounded-3xl border border-border bg-card p-6 shadow-lift sm:p-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-bold",
					children: "كلمة مرور جديدة"
				}), ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					className: "mt-6 space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "new-password",
							children: "كلمة المرور الجديدة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "new-password",
							type: "password",
							dir: "ltr",
							minLength: 8,
							required: true,
							value: password,
							onChange: (e) => setPassword(e.target.value),
							autoComplete: "new-password",
							className: "h-11 text-left"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						variant: "hero",
						size: "lg",
						className: "w-full",
						disabled: loading,
						children: [loading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }), "حفظ كلمة المرور"]
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-muted-foreground",
					children: "افتح هذه الصفحة من الرابط المرسل إلى بريدك الإلكتروني لإعادة تعيين كلمة المرور."
				})]
			})]
		})
	});
}
//#endregion
export { ResetPassword as component };
