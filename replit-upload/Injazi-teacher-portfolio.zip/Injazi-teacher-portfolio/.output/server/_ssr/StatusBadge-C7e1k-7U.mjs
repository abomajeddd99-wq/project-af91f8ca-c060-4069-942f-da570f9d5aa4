import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as STATUS_LABELS } from "./progress-e08EdBAa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/StatusBadge-C7e1k-7U.js
var import_jsx_runtime = require_jsx_runtime();
var styles = {
	not_started: "bg-muted text-muted-foreground",
	in_progress: "bg-warning-soft text-warning-foreground",
	completed: "bg-success-soft text-success"
};
function StatusBadge({ status, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium", styles[status], className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-current" }), STATUS_LABELS[status]]
	});
}
function PlaceholderBadge({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full border border-warning/40 bg-warning-soft px-2 py-0.5 text-[11px] font-medium text-warning-foreground", className),
		children: "معيار تجريبي"
	});
}
//#endregion
export { StatusBadge as n, PlaceholderBadge as t };
