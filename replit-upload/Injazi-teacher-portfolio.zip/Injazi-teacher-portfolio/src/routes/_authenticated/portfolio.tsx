import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useSuspenseQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { Download, FileText, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { allStandardsQuery, evidencesQuery, profileQuery, progressQuery, standardsQuery } from "@/lib/queries";
import { computeEvidenceCoverage, computeManualProgress, statusFor, STATUS_LABELS } from "@/lib/progress";
import { compareEvidenceChronological, isImage } from "@/lib/evidence-files";
import { LogoMark } from "@/components/app/Logo";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { downloadBlob } from "@/lib/download";
import { createPortfolioPdf, type PortfolioCoverOptions, type DownloadedEvidence } from "@/lib/portfolio-export";
import { defaultEvidenceLayout, parseEvidenceLayout } from "@/lib/portfolio-layout-preferences";
import { EvidenceLayoutControls } from "@/components/portfolio/EvidenceLayoutControls";
import { PortfolioA4Preview } from "@/components/portfolio/PortfolioA4Preview";

const NO_ATTACHMENTS: DownloadedEvidence[] = [];

export const Route = createFileRoute("/_authenticated/portfolio")({
  head: () => ({
    meta: [
      { title: "ملف الإنجاز للطباعة — إنجازي" },
      { name: "description", content: "معاينة ملف الإنجاز وطباعته أو حفظه بصيغة PDF." },
      { property: "og:title", content: "ملف الإنجاز للطباعة — إنجازي" },
      { property: "og:description", content: "معاينة ملف الإنجاز وطباعته أو حفظه بصيغة PDF." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  loader: ({ context }) =>
    Promise.all([
      context.queryClient.ensureQueryData(standardsQuery()),
      context.queryClient.ensureQueryData(allStandardsQuery()),
      context.queryClient.ensureQueryData(progressQuery()),
      context.queryClient.ensureQueryData(evidencesQuery()),
      context.queryClient.ensureQueryData(profileQuery(context.user.id)),
    ]),
  component: Portfolio,
});

function Portfolio() {
  const { user } = Route.useRouteContext();
  const { data: standards } = useSuspenseQuery(standardsQuery());
  const { data: allStandards } = useSuspenseQuery(allStandardsQuery());
  const { data: progress } = useSuspenseQuery(progressQuery());
  const { data: evidences } = useSuspenseQuery(evidencesQuery());
  const { data: profile } = useSuspenseQuery(profileQuery(user.id));
  const [showEmpty, setShowEmpty] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState("");
  const [exportError, setExportError] = useState("");
  const [evidenceLayout, setEvidenceLayout] = useState(defaultEvidenceLayout);
  const [preferencesLoaded, setPreferencesLoaded] = useState("");
  const [preferenceWarning, setPreferenceWarning] = useState("");
  const [generatedAt] = useState(() => new Date());
  const preferenceKey = `injazi:portfolio-layout:${user.id}`;
  useEffect(() => {
    try {
      setEvidenceLayout(parseEvidenceLayout(localStorage.getItem(preferenceKey)));
    } catch {
      setEvidenceLayout(defaultEvidenceLayout());
      setPreferenceWarning("تعذر قراءة التفضيلات المحلية؛ سيُستخدم التخطيط الافتراضي.");
    }
    setPreferencesLoaded(preferenceKey);
  }, [preferenceKey]);
  useEffect(() => {
    if (preferencesLoaded !== preferenceKey) return;
    try { localStorage.setItem(preferenceKey, JSON.stringify(evidenceLayout)); }
    catch { setPreferenceWarning("التخطيط يعمل لهذه الجلسة، لكن المتصفح لا يسمح بحفظ التفضيلات."); }
  }, [evidenceLayout, preferenceKey, preferencesLoaded]);
  const [cover, setCover] = useState<PortfolioCoverOptions>({
    layout: "royal",
    accent: "gold",
    title: "ملف الإنجاز الوظيفي",
  });
  const summary = computeManualProgress(standards, progress);
  const evidenceCoverage = computeEvidenceCoverage(standards, evidences);

  const imagePaths = evidences.filter((e) => isImage(e.mime_type)).map((e) => e.file_path);
  const { data: urls } = useQuery({
    queryKey: ["signed-urls", imagePaths],
    enabled: imagePaths.length > 0,
    staleTime: 30 * 60_000,
    queryFn: async () => {
      const { data, error } = await supabase.storage.from("evidence").createSignedUrls(imagePaths, 3600);
      if (error) throw error;
      const map: Record<string, string> = {};
      for (const row of data) if (row.path && row.signedUrl) map[row.path] = row.signedUrl;
      return map;
    },
  });

  const today = new Date();
  const hijri = today.toLocaleDateString("ar-SA-u-ca-islamic-umalqura", { day: "numeric", month: "long", year: "numeric" });
  const greg = today.toLocaleDateString("ar-SA-u-ca-gregory", { day: "numeric", month: "long", year: "numeric" });
  const portfolioStandards = useMemo(() => {
    const evidenceIds = new Set(evidences.map((e) => e.standard_id));
    const activeIds = new Set(standards.map((s) => s.id));
    return [...standards, ...allStandards.filter((s) => !activeIds.has(s.id) && evidenceIds.has(s.id))]
      .filter((s) => showEmpty || evidenceIds.has(s.id));
  }, [standards, allStandards, evidences, showEmpty]);
  const visible = portfolioStandards;
  const hasPlaceholders = standards.some((s) => s.is_placeholder);
  const attachmentQuery = useQuery({
    queryKey: ["portfolio-preview-attachments", user.id, evidences],
    staleTime: 5 * 60_000,
    gcTime: 5 * 60_000,
    queryFn: async (): Promise<DownloadedEvidence[]> => {
      const result: DownloadedEvidence[] = [];
      for (const evidence of [...evidences].sort(compareEvidenceChronological)) {
        try {
          const { data, error } = await supabase.storage.from("evidence").download(evidence.file_path);
          if (error) throw error;
          result.push({ evidence, bytes: new Uint8Array(await data.arrayBuffer()) });
        } catch {
          result.push({ evidence, error: "تعذر الوصول إلى الملف في مساحة الشواهد الخاصة." });
        }
      }
      return result;
    },
  });
  const previewInput = useMemo(() => ({
    profile, standards: portfolioStandards, summaryStandards: standards, progress,
    attachments: attachmentQuery.data ?? NO_ATTACHMENTS, generatedAt, evidenceLayout,
    cover: { ...cover, title: cover.title.trim() || "ملف الإنجاز الوظيفي" },
  }), [profile, portfolioStandards, standards, progress, attachmentQuery.data, generatedAt, evidenceLayout, cover]);

  async function exportPortfolio() {
    setExporting(true);
    setExportError("");
    try {
      setExportProgress("جارٍ تجهيز المرفقات…");
      const refreshed = await attachmentQuery.refetch();
      if (!refreshed.data || refreshed.error) throw new Error("Attachment loading failed.");

      const result = await createPortfolioPdf({
        ...previewInput,
        attachments: refreshed.data,
        onPageProgress: (completed, total) => {
          setExportProgress(`جارٍ تجهيز الصفحات ${completed} من ${total}`);
        },
      });
      const blob = new Blob([result.bytes.slice().buffer as ArrayBuffer], { type: "application/pdf" });
      downloadBlob(blob, "ملف-الإنجاز-إنجازي.pdf");
      if (result.warnings.length) {
        const affectedStandards = result.warnings.map((warning) => warning.standardTitle).join("، ");
        toast.warning(
          `تم تنزيل الملف، لكن تعذر تضمين ${result.warnings.length} مرفق. أُدرج تقرير واضح داخل PDF.`,
          { description: affectedStandards },
        );
      } else {
        toast.success("تم تنزيل ملف الإنجاز بجميع مرفقاته.");
      }
    } catch {
      setExportError("تعذر إنشاء ملف الإنجاز. تحقق من اتصالك ثم أعد المحاولة.");
      toast.error("تعذر إنشاء ملف الإنجاز. لم يتم تغيير أي بيانات.");
    } finally {
      setExporting(false);
      setExportProgress("");
    }
  }

  const info: [string, string | null | undefined][] = [
    ["المسمى الوظيفي", profile?.job_title],
    ["التخصص", profile?.subject],
    ["المرحلة", profile?.stage],
    ["المدرسة", profile?.school],
    ["إدارة التعليم", profile?.education_office],
    ["العام الدراسي", profile?.academic_year],
    ["سنوات الخبرة", profile?.years_experience != null ? String(profile.years_experience) : null],
  ];

  return (
    <div className="space-y-7 animate-rise" dir="rtl">
      <div className="flex flex-col gap-5 rounded-3xl border border-border bg-card p-5 shadow-soft sm:flex-row sm:items-center sm:justify-between sm:p-6 print:hidden">
        <div>
          <p className="text-xs font-semibold tracking-wide text-primary">مساحة إعداد وتصدير</p>
          <h1 className="mt-1 text-2xl font-bold text-primary-deep">ملف الإنجاز</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            نزّل ملفًا يجمع المعايير والصور وكل صفحات ملفات PDF المرتبطة بها.
          </p>
        </div>
        <div className="flex flex-col gap-4 sm:items-end">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <Switch id="show-empty" checked={showEmpty} onCheckedChange={setShowEmpty} />
              <Label htmlFor="show-empty" className="text-sm">إظهار المعايير بلا شواهد</Label>
            </div>
            <Button variant="hero" onClick={exportPortfolio} disabled={exporting || preferencesLoaded !== preferenceKey} aria-live="polite">
              {exporting ? <Loader2 className="animate-spin" /> : <Download />}
              {exporting ? exportProgress || "جارٍ تجهيز PDF…" : "تنزيل ملف PDF"}
            </Button>
          </div>
          {exportError && (
            <p role="alert" className="max-w-sm text-sm text-destructive">{exportError}</p>
          )}
        </div>
      </div>

      <div className="mx-auto max-w-[210mm] space-y-6 print:max-w-none print:space-y-0">
        <EvidenceLayoutControls preferences={evidenceLayout} onChange={setEvidenceLayout} standards={portfolioStandards} disabled={exporting || preferencesLoaded !== preferenceKey} />
        {preferenceWarning && <p role="status" className="text-sm text-muted-foreground">{preferenceWarning}</p>}
        <PortfolioA4Preview input={previewInput} loading={attachmentQuery.isPending || preferencesLoaded !== preferenceKey} loadError={attachmentQuery.isError} />
        <section className="rounded-3xl border border-border bg-card p-5 shadow-soft sm:p-6 print:hidden" aria-labelledby="cover-designer-title">
          <div className="mb-4">
            <p className="text-xs font-semibold text-primary">قبل التصدير</p>
            <h2 id="cover-designer-title" className="mt-1 text-lg font-bold text-primary-deep">تصميم الغلاف</h2>
            <p className="mt-1 text-sm text-muted-foreground">اختر تنسيقًا ولونًا، وستظهر النتيجة مباشرة في معاينة الغلاف.</p>
          </div>
          <div className="grid gap-5 md:grid-cols-[1fr_1fr_1.2fr]">
            <fieldset>
              <legend className="mb-2 text-sm font-semibold">التنسيق</legend>
              <div className="flex flex-wrap gap-2" role="group" aria-label="تنسيق الغلاف">
                {([
                  ["royal", "ملكي"],
                  ["classic", "كلاسيكي"],
                ] as const).map(([value, label]) => (
                  <button
                    key={value}
                    type="button"
                    aria-pressed={cover.layout === value}
                    onClick={() => setCover((current) => ({ ...current, layout: value }))}
                    className={`rounded-xl border px-4 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ${
                      cover.layout === value
                        ? "border-primary bg-primary-soft text-primary-deep"
                        : "border-border bg-background text-foreground hover:border-primary/50"
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </fieldset>
            <fieldset>
              <legend className="mb-2 text-sm font-semibold">اللون المميّز</legend>
              <div className="flex flex-wrap gap-2" role="group" aria-label="لون الغلاف">
                {([
                  ["gold", "ذهبي"],
                  ["emerald", "زمردي"],
                ] as const).map(([value, label]) => (
                  <button
                    key={value}
                    type="button"
                    aria-pressed={cover.accent === value}
                    onClick={() => setCover((current) => ({ ...current, accent: value }))}
                    className={`inline-flex items-center gap-2 rounded-xl border px-4 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ${
                      cover.accent === value
                        ? "border-primary bg-primary-soft text-primary-deep"
                        : "border-border bg-background text-foreground hover:border-primary/50"
                    }`}
                  >
                    <span
                      className={`size-3 rounded-full border border-foreground/10 ${value === "gold" ? "bg-[#C5A15B]" : "bg-[#07594F]"}`}
                      aria-hidden="true"
                    />
                    {label}
                  </button>
                ))}
              </div>
            </fieldset>
            <div>
              <Label htmlFor="cover-title" className="mb-2 block text-sm font-semibold">عنوان الغلاف</Label>
              <input
                id="cover-title"
                value={cover.title}
                onChange={(event) => setCover((current) => ({ ...current, title: event.target.value }))}
                maxLength={80}
                className="h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none transition focus-visible:ring-2 focus-visible:ring-ring"
                dir="auto"
              />
            </div>
          </div>
        </section>
        {/* Cover */}
        <section
          aria-label="معاينة غلاف ملف الإنجاز"
          className={`relative mx-auto aspect-[210/297] w-full overflow-hidden border bg-card p-5 shadow-soft sm:p-10 print:min-h-[265mm] print:aspect-auto print:rounded-none print:border-0 print:shadow-none ${
            cover.layout === "royal" ? "rounded-[1.75rem]" : "rounded-lg"
          }`}
          style={{ borderColor: cover.accent === "gold" ? "#C5A15B" : "#07594F" }}
        >
          <div className="absolute inset-0 opacity-40" aria-hidden="true">
            {cover.layout === "royal" && <div className="pattern-dots h-full w-full" />}
          </div>
          <div
            className="absolute inset-x-0 top-0 h-2"
            aria-hidden="true"
            style={{ backgroundColor: cover.accent === "gold" ? "#C5A15B" : "#07594F" }}
          />
          <div className="relative flex h-full flex-col">
            <div className="flex items-center gap-3">
              <LogoMark className="size-11" />
              <span className="font-display text-lg font-bold text-primary-deep">إنجازي</span>
            </div>
            <div className={`my-auto py-6 sm:py-12 ${cover.layout === "classic" ? "text-center" : ""}`}>
              <p className="text-sm font-medium text-primary">المملكة العربية السعودية</p>
              <h2 className="mt-3 font-display text-3xl font-bold leading-tight text-primary-deep sm:text-4xl">
                {cover.title.trim() || "ملف الإنجاز الوظيفي"}
              </h2>
              <div
                className={`mt-4 h-1 w-24 rounded-full ${cover.layout === "classic" ? "mx-auto" : ""}`}
                style={{ backgroundColor: cover.accent === "gold" ? "#C5A15B" : "#07594F" }}
              />
              <p className="mt-8 text-xl font-semibold sm:text-2xl">{profile?.full_name || "—"}</p>
            </div>
            <dl className="grid grid-cols-2 gap-x-4 gap-y-3 text-xs sm:gap-x-6 sm:text-sm">
              {info
                .filter(([, v]) => v)
                .map(([k, v]) => (
                  <div key={k} className="border-b border-border pb-2">
                    <dt className="text-xs text-muted-foreground">{k}</dt>
                    <dd className="mt-0.5 font-medium">{v}</dd>
                  </div>
                ))}
            </dl>
            {profile?.bio && <p className="mt-6 text-sm leading-loose text-muted-foreground">{profile.bio}</p>}
            <p className="mt-8 text-xs text-muted-foreground">
              تاريخ الإصدار: {hijri} — الموافق {greg}
            </p>
            {hasPlaceholders && (
              <p className="mt-3 rounded-xl border border-warning/40 bg-warning-soft p-3 text-xs text-warning-foreground">
                تنبيه: المعايير الواردة في هذا الملف تجريبية، وستُستبدل بالمعايير الرسمية المعتمدة.
              </p>
            )}
          </div>
        </section>

        {/* Summary */}
        <section className="print-break rounded-3xl border border-border bg-card p-6 shadow-soft print:rounded-none print:border-0 print:p-0 print:shadow-none">
          <h2 className="text-xl font-bold text-primary-deep">ملخص الإنجاز</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            الإنجاز الموزون حسب الحالة اليدوية: <strong className="text-foreground">{summary.weightedPercent}٪</strong>
            — المعايير التي حدّدت اكتمالها: {summary.completed} من {summary.total} — تغطية الشواهد:
            {" "}{evidenceCoverage.documented} من {evidenceCoverage.total} معيار ({evidenceCoverage.percent}٪)
          </p>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr className="bg-primary-soft text-accent-foreground">
                  <th className="border border-border p-2 text-start">#</th>
                  <th className="border border-border p-2 text-start">المعيار</th>
                  <th className="border border-border p-2 text-start">الوزن</th>
                  <th className="border border-border p-2 text-start">الحالة اليدوية</th>
                  <th className="border border-border p-2 text-start">الشواهد</th>
                </tr>
              </thead>
              <tbody>
                {standards.map((s) => (
                  <tr key={s.id} className="print-avoid">
                    <td className="border border-border p-2">{s.code}</td>
                    <td className="border border-border p-2">{s.title}</td>
                    <td className="border border-border p-2">{Number(s.weight)}٪</td>
                    <td className="border border-border p-2">{STATUS_LABELS[statusFor(s.id, progress)]}</td>
                    <td className="border border-border p-2">
                      {evidences.filter((e) => e.standard_id === s.id).length}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Standards with evidence */}
        {visible.map((s) => {
          const items = evidences.filter((e) => e.standard_id === s.id);
          const notes = progress.find((p) => p.standard_id === s.id)?.notes;
          return (
            <section
              key={s.id}
              className="print-break rounded-3xl border border-border bg-card p-6 shadow-soft print:rounded-none print:border-0 print:p-0 print:shadow-none"
            >
              <div className="flex items-center justify-between gap-3 border-b-2 border-primary pb-3">
                <div>
                  <p className="text-xs font-semibold text-primary">
                    {s.code} · الوزن {Number(s.weight)}٪{s.is_placeholder ? " · معيار تجريبي" : ""}
                  </p>
                  <h2 className="mt-1 text-lg font-bold text-primary-deep">{s.title}</h2>
                </div>
                <span className="shrink-0 rounded-full bg-primary-soft px-3 py-1 text-xs font-medium text-accent-foreground">
                  {STATUS_LABELS[statusFor(s.id, progress)]}
                </span>
              </div>
              {s.indicators.length > 0 && (
                <ul className="mt-3 list-disc space-y-1 ps-5 text-sm text-muted-foreground">
                  {s.indicators.map((i) => (
                    <li key={i}>{i}</li>
                  ))}
                </ul>
              )}
              {notes && <p className="mt-3 rounded-xl bg-secondary p-3 text-sm leading-relaxed">{notes}</p>}
              {items.length === 0 ? (
                <p className="mt-6 text-sm text-muted-foreground">لا توجد شواهد مرفقة لهذا المعيار.</p>
              ) : (
                <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 print:grid-cols-2">
                  {items.map((e) => (
                    <figure key={e.id} className="print-avoid overflow-hidden rounded-2xl border border-border">
                      {isImage(e.mime_type) ? (
                        urls?.[e.file_path] ? (
                          <img src={urls[e.file_path]} alt={e.title} className="max-h-72 w-full bg-secondary object-contain" />
                        ) : (
                          <div className="grid h-40 place-items-center bg-secondary text-xs text-muted-foreground">
                            جارٍ تحميل الصورة…
                          </div>
                        )
                      ) : (
                        <div className="flex items-center gap-3 bg-secondary p-4">
                          <FileText className="size-8 text-primary" aria-hidden="true" />
                          <div className="min-w-0">
                            <p className="text-xs text-muted-foreground">مرفق PDF</p>
                            <p className="truncate text-sm font-medium">{e.title}</p>
                          </div>
                        </div>
                      )}
                      <figcaption className="p-3">
                        <p className="text-sm font-semibold">{e.title}</p>
                        {e.description && (
                          <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{e.description}</p>
                        )}
                      </figcaption>
                    </figure>
                  ))}
                </div>
              )}
            </section>
          );
        })}
      </div>
    </div>
  );
}
