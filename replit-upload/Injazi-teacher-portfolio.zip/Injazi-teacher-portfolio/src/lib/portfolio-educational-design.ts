export interface EducationalCoverInput {
  name: string;
  school?: string;
  year?: string;
  educationOffice?: string;
  subject?: string;
  jobTitle?: string;
  subtitle: string;
  date: string;
  layout: "royal" | "classic";
  accent: "gold" | "emerald";
}

export interface EducationalCvInput {
  profile: {
    full_name?: string | null;
    job_title?: string | null;
    subject?: string | null;
    stage?: string | null;
    school?: string | null;
    education_office?: string | null;
    academic_year?: string | null;
    years_experience?: number | null;
  } | null;
  bio?: string;
  pageIndex: number;
  pageCount: number;
}

const EMERALD = "#07584F";
const DEEP_EMERALD = "#06463F";
const GOLD = "#C5A46D";
const INK = "#293531";
const MUTED = "#65716B";
const IVORY = "#F8F5EC";
const PALE = "#F0ECE2";

function escapeHtml(value: unknown): string {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function coverRow(label: string, value: string | undefined): string {
  if (!value) return "";
  return `
    <div style="display:grid;grid-template-columns:136px minmax(0,1fr);align-items:start;gap:16px;padding:10px 0;border-bottom:1px solid rgba(7,88,79,.12);">
      <div style="color:${EMERALD};font-size:13px;line-height:1.7;font-weight:600">${label}</div>
      <div style="min-width:0;color:${INK};font-size:16px;line-height:1.65;overflow-wrap:anywhere;word-break:break-word">${escapeHtml(value)}</div>
    </div>`;
}

function bookMotif(): string {
  return `
    <g aria-hidden="true" transform="translate(0 0)">
      <path d="M0 22C20 9 42 8 66 17V67C41 58 20 59 0 72Z" fill="${IVORY}" stroke="${GOLD}" stroke-width="2"/>
      <path d="M0 22C20 9 42 8 66 17V67C41 58 20 59 0 72Z" fill="none" stroke="${EMERALD}" stroke-width="1"/>
      <path d="M132 22C112 9 90 8 66 17V67C91 58 112 59 132 72Z" fill="${IVORY}" stroke="${GOLD}" stroke-width="2"/>
      <path d="M132 22C112 9 90 8 66 17V67C91 58 112 59 132 72Z" fill="none" stroke="${EMERALD}" stroke-width="1"/>
      <path d="M66 17V69M12 29C29 23 43 24 55 29M12 40C28 35 42 36 55 40M120 29C103 23 89 24 77 29M120 40C104 35 90 36 77 40" fill="none" stroke="${GOLD}" stroke-width="1.2" opacity=".9"/>
      <path d="M-3 74C20 67 43 66 66 73C89 66 112 67 135 74" fill="none" stroke="${EMERALD}" stroke-width="2"/>
    </g>`;
}

export function buildEducationalCover(input: EducationalCoverInput): string {
  const isClassic = input.layout === "classic";
  const accent = input.accent === "emerald" ? EMERALD : GOLD;
  const rows = [
    coverRow("اسم المعلم", input.name),
    coverRow("المسمى الوظيفي", input.jobTitle),
    coverRow("التخصص", input.subject),
    coverRow("المدرسة", input.school),
    coverRow("إدارة التعليم", input.educationOffice),
    coverRow("العام الدراسي", input.year),
  ].filter(Boolean).join("");

  return `
    <section data-royal-page="true" data-royal-layout="${escapeHtml(input.layout)}" data-royal-accent="${escapeHtml(input.accent)}" style="position:absolute;inset:0;box-sizing:border-box;width:794px;height:1123px;overflow:hidden;background:${IVORY};color:${INK};direction:rtl;text-align:right;font-family:'IBM Plex Sans Arabic','Readex Pro',system-ui,sans-serif">
      <svg aria-hidden="true" width="794" height="1123" viewBox="0 0 794 1123" style="position:absolute;inset:0;width:794px;height:1123px;pointer-events:none">
        <defs>
          <pattern id="educational-cover-pattern" width="42" height="42" patternUnits="userSpaceOnUse">
            <path d="M21 2 40 21 21 40 2 21Z" fill="none" stroke="${EMERALD}" stroke-width=".7" opacity=".11"/>
            <circle cx="21" cy="21" r="1.4" fill="${GOLD}" opacity=".35"/>
          </pattern>
          <linearGradient id="educational-gold-line" x1="0" x2="1">
            <stop offset="0" stop-color="${GOLD}" stop-opacity=".18"/>
            <stop offset=".5" stop-color="${GOLD}" stop-opacity=".95"/>
            <stop offset="1" stop-color="${GOLD}" stop-opacity=".18"/>
          </linearGradient>
        </defs>
        <path d="M0 0H794V265H0Z" fill="url(#educational-cover-pattern)" opacity=".68"/>
        ${isClassic
          ? `<path d="M27 27H767V1096H27Z" fill="none" stroke="${accent}" stroke-width="1.3"/>
             <path d="M37 37H757V1086H37Z" fill="none" stroke="${EMERALD}" stroke-width=".65" opacity=".48"/>
             <path d="M27 27h34M27 27v34M767 27h-34M767 27v34M27 1096h34M27 1096v-34M767 1096h-34M767 1096v-34" fill="none" stroke="${GOLD}" stroke-width="2.2"/>
             <path d="M0 0C66 7 115 37 151 86C111 59 69 52 0 66Z" fill="${EMERALD}" opacity=".93"/>
             <path d="M0 76C74 62 118 77 163 111" fill="none" stroke="${GOLD}" stroke-width="3"/>
             <path d="M0 1007C166 977 264 1026 404 1002C544 978 658 994 794 964V1123H0Z" fill="${EMERALD}" opacity=".96"/>
             <path d="M0 998C164 968 264 1017 404 993C545 969 659 985 794 955" fill="none" stroke="${GOLD}" stroke-width="3"/>`
          : `<path d="M0 0C98 8 161 49 202 119C150 79 91 65 0 85Z" fill="${DEEP_EMERALD}"/>
             <path d="M0 94C92 74 158 95 214 143" fill="none" stroke="${GOLD}" stroke-width="4"/>
             <path d="M0 0C80 11 130 44 164 96" fill="none" stroke="${IVORY}" stroke-width="7" opacity=".92"/>
             <path d="M0 0C101 17 148 58 188 119" fill="none" stroke="${GOLD}" stroke-width="2" opacity=".92"/>
             <path d="M0 997C147 970 259 1011 396 989C544 964 660 985 794 952V1123H0Z" fill="${DEEP_EMERALD}"/>
             <path d="M0 987C148 960 259 1001 396 979C545 954 660 975 794 942" fill="none" stroke="url(#educational-gold-line)" stroke-width="3.2"/>
             <path d="M0 1011C155 988 265 1030 402 1007C547 983 663 1004 794 974" fill="none" stroke="${IVORY}" stroke-width="1" opacity=".42"/>`}
      </svg>

      <div aria-hidden="true" style="position:absolute;top:50px;left:64px;right:64px;display:flex;align-items:center;justify-content:space-between;gap:18px">
        <div style="display:flex;align-items:center;gap:10px;color:${EMERALD};visibility:${isClassic ? "visible" : "hidden"}">
          <span style="width:22px;height:22px;border:1px solid ${GOLD};transform:rotate(45deg);box-sizing:border-box"></span>
          <span style="margin-right:-21px;width:6px;height:6px;border-radius:50%;background:${EMERALD};border:1px solid ${IVORY};box-sizing:border-box"></span>
          <span style="margin-right:5px;font-family:Georgia,serif;font-size:11px;letter-spacing:.16em;color:#8C7146">ENJAZI</span>
        </div>
        <span style="font-size:12px;line-height:1.6;color:#796642">ملف الإنجاز الوظيفي</span>
      </div>

      <main style="position:absolute;top:111px;left:64px;right:64px;box-sizing:border-box;text-align:center">
        <div style="width:132px;height:77px;margin:0 auto 10px">
          <svg aria-hidden="true" width="132" height="77" viewBox="0 0 132 77" style="display:block;width:132px;height:77px">${bookMotif()}</svg>
        </div>
        <div style="color:#8C7146;font-size:11px;line-height:1.6;letter-spacing:.035em">ملف مهني للتوثيق والمراجعة</div>
        <h1 style="max-width:666px;margin:6px auto 0;color:${EMERALD};font-size:39px;font-weight:700;line-height:1.45;letter-spacing:-.02em;overflow-wrap:anywhere;word-break:break-word">ملف شواهد الأداء الوظيفي</h1>
        <div style="width:56px;height:2px;margin:9px auto 0;background:${accent}"></div>
        <div style="display:inline-block;max-width:100%;box-sizing:border-box;margin:11px auto 0;padding:6px 22px;border:1px solid rgba(197,164,109,.72);border-radius:24px;background:#F1E8D5;color:#796642;font-size:15px;font-weight:600;line-height:1.6">إنجازي للمعلم</div>
        <p style="max-width:610px;max-height:66px;margin:9px auto 0;overflow:hidden;color:#53615B;font-size:14px;line-height:1.65;overflow-wrap:anywhere;word-break:break-word;white-space:pre-wrap">${escapeHtml(input.subtitle)}</p>

        <div style="margin-top:17px;padding:7px 21px 9px;border:1px solid rgba(7,88,79,.28);border-right:3px solid ${accent};border-radius:2px;background:rgba(255,255,255,.68);box-sizing:border-box;text-align:right">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:14px;padding:7px 0 9px;border-bottom:1px solid rgba(197,164,109,.52)">
            <span style="color:#8C7146;font-size:11px;letter-spacing:.035em">بيانات المعلم</span>
            <span style="color:${EMERALD};font-size:11px;line-height:1.5">هوية مهنية</span>
          </div>
          ${rows || `<div style="padding:12px 0;color:${MUTED};font-size:13px">بيانات الملف</div>`}
        </div>
      </main>

      <div aria-hidden="true" style="position:absolute;bottom:82px;left:64px;right:64px;display:flex;align-items:center;justify-content:space-between;gap:20px;color:${isClassic ? IVORY : "#EDE4D1"};font-size:11px;line-height:1.7">
        <span style="letter-spacing:.1em">ENJAZI · TEACHER PORTFOLIO</span>
        <span style="text-align:left;overflow-wrap:anywhere">${escapeHtml(input.date)}</span>
      </div>
    </section>`;
}

function cvSectionHeading(title: string, index: string): string {
  return `
    <div style="display:flex;align-items:center;gap:10px;margin:18px 0 9px;padding-bottom:7px;border-bottom:1px solid #D9CFBA">
      <span style="display:inline-flex;align-items:center;justify-content:center;width:21px;height:21px;border:1px solid ${GOLD};border-radius:50%;color:#846C40;font-family:Georgia,serif;font-size:10px">${index}</span>
      <h2 style="margin:0;color:${EMERALD};font-size:14px;line-height:1.5;font-weight:700">${title}</h2>
    </div>`;
}

function cvRow(label: string, value: string | number | null | undefined): string {
  if (value === null || value === undefined || value === "") return "";
  return `
    <div style="min-width:0;padding:9px 12px;border-right:2px solid ${GOLD};background:${IVORY};box-sizing:border-box">
      <div style="color:${MUTED};font-size:10px;line-height:1.5">${label}</div>
      <div style="margin-top:3px;color:${INK};font-size:13px;font-weight:600;line-height:1.6;overflow-wrap:anywhere;word-break:break-word;white-space:pre-wrap">${escapeHtml(value)}</div>
    </div>`;
}

export function buildEducationalCv(input: EducationalCvInput): string {
  const profile = input.profile;
  const pageIndex = Math.max(0, Math.floor(input.pageIndex));
  const bio = input.bio ?? "";

  if (pageIndex > 0) {
    return `
      <div dir="rtl" style="margin-top:5px;color:${INK};font-family:'IBM Plex Sans Arabic','Readex Pro',system-ui,sans-serif">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;border-bottom:1px solid #D9CFBA;padding:0 0 10px">
          <div style="color:${EMERALD};font-size:17px;font-weight:700;line-height:1.6">السيرة المهنية</div>
          <div style="color:#8C7146;font-size:11px">تكملة ${escapeHtml(pageIndex + 1)} من ${escapeHtml(input.pageCount)}</div>
        </div>
        ${bio ? `<section style="margin-top:19px;padding:17px 18px;background:${PALE};border-right:3px solid ${GOLD};box-sizing:border-box">
          <div style="color:#765F35;font-size:11px;font-weight:700;line-height:1.6">نبذة مهنية · متابعة</div>
          <div style="margin-top:8px;color:#40514E;font-size:14px;line-height:1.9;white-space:pre-wrap;overflow-wrap:anywhere;word-break:break-word">${escapeHtml(bio)}</div>
        </section>` : ""}
      </div>`;
  }

  const hasIdentity = Boolean(profile?.full_name || profile?.subject || profile?.stage);
  const nameBlock = profile?.full_name
    ? `<div style="padding:1px 0 13px;border-bottom:1px solid #D9CFBA">
        <div style="color:#8C7146;font-size:10px;line-height:1.5;letter-spacing:.025em">البيانات الشخصية والمهنية</div>
        <h1 style="margin:4px 0 0;color:${EMERALD};font-size:24px;line-height:1.5;font-weight:700;overflow-wrap:anywhere;word-break:break-word">${escapeHtml(profile.full_name)}</h1>
      </div>`
    : `<div style="padding:1px 0 13px;border-bottom:1px solid #D9CFBA;color:${EMERALD};font-size:17px;font-weight:700">البيانات الشخصية والمهنية</div>`;
  const specialization = [
    cvRow("التخصص", profile?.subject),
    cvRow("المرحلة الدراسية", profile?.stage),
  ].filter(Boolean).join("");
  const career = [
    cvRow("المسمى الوظيفي", profile?.job_title),
    cvRow("جهة العمل · المدرسة", profile?.school),
    cvRow("إدارة التعليم", profile?.education_office),
    cvRow("العام الدراسي", profile?.academic_year),
    profile?.years_experience !== null && profile?.years_experience !== undefined
      ? cvRow("سنوات الخبرة", `${profile.years_experience} سنة`)
      : "",
  ].filter(Boolean).join("");

  return `
    <div dir="rtl" style="margin-top:5px;color:${INK};font-family:'IBM Plex Sans Arabic','Readex Pro',system-ui,sans-serif">
      ${nameBlock}
      ${specialization ? `${cvSectionHeading("التخصص والمرحلة", "١")}<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">${specialization}</div>` : ""}
      ${career ? `${cvSectionHeading("المسار المهني", "٢")}<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">${career}</div>` : ""}
      ${bio ? `${cvSectionHeading("نبذة مهنية", career || specialization ? "٣" : "١")}<div style="padding:13px 15px;background:${PALE};border-right:2px solid ${GOLD};color:#40514E;font-size:13px;line-height:1.8;white-space:pre-wrap;overflow-wrap:anywhere;word-break:break-word">${escapeHtml(bio)}</div>` : ""}
      ${!hasIdentity && !career && !bio ? `<div style="margin-top:16px;padding:13px 15px;background:${IVORY};border-right:2px solid ${GOLD};color:${MUTED};font-size:12px;line-height:1.7">لا تتوفر بيانات شخصية أو مهنية في الملف الشخصي.</div>` : ""}
    </div>`;
}
