import { Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import type { ReactNode } from "react";
import { LayoutDashboard, ListChecks, LogOut, BookOpenCheck, UserRound } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "@/components/app/Logo";
import { Button } from "@/components/ui/button";
import { isAdminQuery } from "@/lib/queries";

const baseNav = [
  { to: "/dashboard", label: "الرئيسية", icon: LayoutDashboard },
  { to: "/standards", label: "المعايير", icon: ListChecks },
  { to: "/portfolio", label: "ملف الإنجاز", icon: BookOpenCheck },
  { to: "/profile", label: "حسابي", icon: UserRound },
] as const;


export function AppShell({ children }: { children: ReactNode }) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const nav = baseNav;
  const { data: isAdmin } = useQuery(isAdminQuery());

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", search: { mode: "login" }, replace: true });
  }

  return (
    <div className="min-h-[100dvh] bg-background" dir="rtl">
      <header className="sticky top-0 z-30 border-b border-border/70 bg-background/95 backdrop-blur print:hidden">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4">
          <Logo to="/dashboard" />
          <nav className="hidden items-center gap-1 md:flex" aria-label="التنقل الرئيسي">
            {nav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                activeProps={{ className: "bg-primary-soft !text-accent-foreground font-medium", "aria-current": "page" }}
              >
                <item.icon className="size-4" aria-hidden="true" />
                {item.label}
              </Link>
            ))}
          </nav>
          <Button variant="ghost" size="sm" onClick={signOut} aria-label="تسجيل الخروج">
            <LogOut aria-hidden="true" />
            <span className="hidden sm:inline">خروج</span>
          </Button>
          {isAdmin && <Button asChild variant="outline" size="sm"><Link to="/admin">الإدارة</Link></Button>}
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 pb-28 pt-6 md:pb-12 print:max-w-none print:p-0">{children}</main>

      <nav
        className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-card/95 backdrop-blur safe-bottom md:hidden print:hidden"
        aria-label="التنقل السفلي"
      >
        <ul className="mx-auto flex max-w-lg items-stretch justify-around px-2 pt-1.5">
          {nav.map((item) => (
            <li key={item.to} className="flex-1">
              <Link
                to={item.to}
                className="flex flex-col items-center gap-1 rounded-xl py-1.5 text-[11px] text-muted-foreground transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                activeProps={{ className: "!text-primary font-semibold", "aria-current": "page" }}
              >
                <item.icon className="size-5" aria-hidden="true" />
                {item.label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
}
